import Foundation
import SpriteKit
import UIKit

// MARK: - Procedural Texture Factory (Crisp 2x Vector Art for 120 FPS)

private final class OceanTextureFactory {
    static let shared = OceanTextureFactory()

    private var cache: [String: SKTexture] = [:]

    func backgroundTexture(for map: MapTheme, size: CGSize) -> SKTexture {
        let key = "bg_\(map.rawValue)"
        if let tex = cache[key] { return tex }

        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let colors: [CGColor]
            if map == .lagoon {
                colors = [
                    UIColor(red: 0.25, green: 0.84, blue: 0.98, alpha: 1.0).cgColor,
                    UIColor(red: 0.08, green: 0.62, blue: 0.87, alpha: 1.0).cgColor,
                    UIColor(red: 0.04, green: 0.36, blue: 0.62, alpha: 1.0).cgColor
                ]
            } else {
                colors = [
                    UIColor(red: 0.05, green: 0.26, blue: 0.48, alpha: 1.0).cgColor,
                    UIColor(red: 0.03, green: 0.14, blue: 0.30, alpha: 1.0).cgColor,
                    UIColor(red: 0.01, green: 0.06, blue: 0.15, alpha: 1.0).cgColor
                ]
            }

            let space = CGColorSpaceCreateDeviceRGB()
            if let grad = CGGradient(colorsSpace: space, colors: colors as CFArray, locations: [0.0, 0.55, 1.0]) {
                cg.drawLinearGradient(
                    grad,
                    start: CGPoint(x: size.width * 0.5, y: 0),
                    end: CGPoint(x: size.width * 0.5, y: size.height),
                    options: []
                )
            }

            // Diagonal sunlit rays (bright in Lagoon, misty moonbeams in Deep)
            let rayAlpha: CGFloat = map == .lagoon ? 0.13 : 0.05
            cg.saveGState()
            let rayPositions: [(CGFloat, CGFloat)] = [(160, 140), (440, 180), (760, 150), (1020, 130)]
            for (rx, rw) in rayPositions {
                let path = UIBezierPath()
                path.move(to: CGPoint(x: rx, y: 0))
                path.addLine(to: CGPoint(x: rx + rw, y: 0))
                path.addLine(to: CGPoint(x: rx + rw + 190, y: size.height))
                path.addLine(to: CGPoint(x: rx + 60, y: size.height))
                path.close()
                UIColor(red: 0.82, green: 0.98, blue: 1.0, alpha: rayAlpha).setFill()
                path.fill()
            }
            cg.restoreGState()

            // Seabed hill contour
            let floorPath = UIBezierPath()
            floorPath.move(to: CGPoint(x: 0, y: size.height))
            floorPath.addLine(to: CGPoint(x: 0, y: size.height - 56))
            floorPath.addCurve(
                to: CGPoint(x: size.width * 0.5, y: size.height - 44),
                controlPoint1: CGPoint(x: size.width * 0.2, y: size.height - 84),
                controlPoint2: CGPoint(x: size.width * 0.35, y: size.height - 28)
            )
            floorPath.addCurve(
                to: CGPoint(x: size.width, y: size.height - 58),
                controlPoint1: CGPoint(x: size.width * 0.68, y: size.height - 62),
                controlPoint2: CGPoint(x: size.width * 0.85, y: size.height - 86)
            )
            floorPath.addLine(to: CGPoint(x: size.width, y: size.height))
            floorPath.close()

            if map == .lagoon {
                UIColor(red: 0.86, green: 0.78, blue: 0.54, alpha: 0.92).setFill()
                floorPath.fill()
                // Decorative reef corals on sand
                let corals: [(CGFloat, CGFloat, UIColor)] = [
                    (190, size.height - 52, UIColor(red: 0.96, green: 0.45, blue: 0.52, alpha: 0.85)),
                    (520, size.height - 44, UIColor(red: 0.98, green: 0.65, blue: 0.30, alpha: 0.85)),
                    (890, size.height - 54, UIColor(red: 0.76, green: 0.48, blue: 0.94, alpha: 0.85))
                ]
                for (cx, cy, col) in corals {
                    col.setFill()
                    for angle in stride(from: -0.7, through: 0.7, by: 0.35) {
                        let branch = UIBezierPath(roundedRect: CGRect(x: cx - 5 + CGFloat(angle * 22), y: cy - 36, width: 11, height: 38), cornerRadius: 5.5)
                        branch.fill()
                    }
                }
            } else {
                UIColor(red: 0.03, green: 0.10, blue: 0.22, alpha: 0.96).setFill()
                floorPath.fill()
                // Bioluminescent anemones
                let glows: [(CGFloat, CGFloat, UIColor)] = [
                    (210, size.height - 50, UIColor(red: 0.16, green: 0.88, blue: 0.92, alpha: 0.55)),
                    (610, size.height - 44, UIColor(red: 0.38, green: 0.95, blue: 0.65, alpha: 0.50)),
                    (960, size.height - 56, UIColor(red: 0.52, green: 0.46, blue: 1.0, alpha: 0.55))
                ]
                for (gx, gy, col) in glows {
                    col.setFill()
                    UIBezierPath(ovalIn: CGRect(x: gx - 26, y: gy - 16, width: 52, height: 22)).fill()
                }
            }
        }
        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func playerFishTexture(isP1: Bool) -> SKTexture {
        let key = isP1 ? "player_gold" : "player_pink"
        if let tex = cache[key] { return tex }

        let size = CGSize(width: 128, height: 96)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let cx = size.width * 0.54
            let cy = size.height * 0.50

            let glowColor = isP1
                ? UIColor(red: 1.0, green: 0.84, blue: 0.22, alpha: 0.50)
                : UIColor(red: 1.0, green: 0.32, blue: 0.68, alpha: 0.50)
            let bodyMain = isP1
                ? UIColor(red: 1.0, green: 0.83, blue: 0.20, alpha: 1.0)
                : UIColor(red: 1.0, green: 0.38, blue: 0.66, alpha: 1.0)
            let bodyAccent = isP1
                ? UIColor(red: 1.0, green: 0.58, blue: 0.08, alpha: 1.0)
                : UIColor(red: 0.90, green: 0.16, blue: 0.52, alpha: 1.0)
            let highlight = isP1
                ? UIColor(red: 1.0, green: 0.97, blue: 0.72, alpha: 0.75)
                : UIColor(red: 1.0, green: 0.82, blue: 0.92, alpha: 0.75)

            // Outer neon halo
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 16, color: glowColor.cgColor)
            glowColor.withAlphaComponent(0.28).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx - 36, y: cy - 26, width: 72, height: 52)).fill()
            cg.restoreGState()

            // Forked tail
            let tail = UIBezierPath()
            tail.move(to: CGPoint(x: cx - 22, y: cy))
            tail.addLine(to: CGPoint(x: cx - 48, y: cy - 20))
            tail.addQuadCurve(to: CGPoint(x: cx - 40, y: cy), controlPoint: CGPoint(x: cx - 38, y: cy - 8))
            tail.addQuadCurve(to: CGPoint(x: cx - 48, y: cy + 20), controlPoint: CGPoint(x: cx - 38, y: cy + 8))
            tail.close()
            bodyAccent.setFill()
            tail.fill()

            // Dorsal fin
            let dorsal = UIBezierPath()
            dorsal.move(to: CGPoint(x: cx - 14, y: cy - 17))
            dorsal.addQuadCurve(to: CGPoint(x: cx + 14, y: cy - 16), controlPoint: CGPoint(x: cx - 2, y: cy - 34))
            dorsal.close()
            bodyAccent.withAlphaComponent(0.92).setFill()
            dorsal.fill()

            // Pelvic fin
            let pelvic = UIBezierPath()
            pelvic.move(to: CGPoint(x: cx - 8, y: cy + 16))
            pelvic.addQuadCurve(to: CGPoint(x: cx + 12, y: cy + 16), controlPoint: CGPoint(x: cx, y: cy + 29))
            pelvic.close()
            bodyAccent.withAlphaComponent(0.88).setFill()
            pelvic.fill()

            // Main plump body
            let bodyRect = CGRect(x: cx - 28, y: cy - 20, width: 62, height: 40)
            let bodyPath = UIBezierPath(ovalIn: bodyRect)
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 10, color: glowColor.cgColor)
            bodyMain.setFill()
            bodyPath.fill()
            cg.restoreGState()

            // Bright crisp rim stroke
            UIColor.white.withAlphaComponent(0.82).setStroke()
            bodyPath.lineWidth = 2.0
            bodyPath.stroke()

            // Glossy top shine
            highlight.setFill()
            UIBezierPath(ovalIn: CGRect(x: cx - 16, y: cy - 16, width: 34, height: 13)).fill()

            // Eye
            UIColor.white.setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + 12, y: cy - 10, width: 12, height: 12)).fill()
            UIColor(red: 0.06, green: 0.10, blue: 0.20, alpha: 1.0).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + 16, y: cy - 8, width: 7, height: 7)).fill()
            UIColor.white.setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + 17, y: cy - 7, width: 2.5, height: 2.5)).fill()

            // Cheerful smile
            let smile = UIBezierPath()
            smile.move(to: CGPoint(x: cx + 22, y: cy + 5))
            smile.addQuadCurve(to: CGPoint(x: cx + 31, y: cy + 3), controlPoint: CGPoint(x: cx + 27, y: cy + 9))
            UIColor(red: 0.35, green: 0.12, blue: 0.08, alpha: 0.85).setStroke()
            smile.lineWidth = 2.0
            smile.lineCapStyle = .round
            smile.stroke()
        }

        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func ambientFishTexture(kind: UInt8) -> SKTexture {
        let key = "ambient_\(kind)"
        if let tex = cache[key] { return tex }

        let size = CGSize(width: 96, height: 68)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { _ in
            let cx = size.width * 0.54
            let cy = size.height * 0.50

            // Muted oceanic palettes so player neon fish always pop immediately
            let bodyColor: UIColor
            let finColor: UIColor
            let stripeColor: UIColor
            switch kind % 3 {
            case 0: // Seafoam reef fish
                bodyColor = UIColor(red: 0.44, green: 0.76, blue: 0.74, alpha: 0.94)
                finColor = UIColor(red: 0.30, green: 0.60, blue: 0.62, alpha: 0.92)
                stripeColor = UIColor(red: 0.24, green: 0.48, blue: 0.52, alpha: 0.45)
            case 1: // Muted lavender angelfish
                bodyColor = UIColor(red: 0.64, green: 0.66, blue: 0.84, alpha: 0.94)
                finColor = UIColor(red: 0.46, green: 0.48, blue: 0.70, alpha: 0.92)
                stripeColor = UIColor(red: 0.34, green: 0.36, blue: 0.56, alpha: 0.45)
            default: // Silver-slate dart fish
                bodyColor = UIColor(red: 0.66, green: 0.78, blue: 0.86, alpha: 0.94)
                finColor = UIColor(red: 0.44, green: 0.58, blue: 0.68, alpha: 0.92)
                stripeColor = UIColor(red: 0.32, green: 0.45, blue: 0.55, alpha: 0.42)
            }

            // Tail
            let tail = UIBezierPath()
            tail.move(to: CGPoint(x: cx - 16, y: cy))
            tail.addLine(to: CGPoint(x: cx - 34, y: cy - 13))
            tail.addLine(to: CGPoint(x: cx - 28, y: cy))
            tail.addLine(to: CGPoint(x: cx - 34, y: cy + 13))
            tail.close()
            finColor.setFill()
            tail.fill()

            // Top fin
            let topFin = UIBezierPath()
            topFin.move(to: CGPoint(x: cx - 10, y: cy - 12))
            topFin.addQuadCurve(to: CGPoint(x: cx + 8, y: cy - 12), controlPoint: CGPoint(x: cx - 1, y: cy - 24))
            topFin.close()
            finColor.setFill()
            topFin.fill()

            // Body
            let bodyH: CGFloat = (kind % 3 == 1) ? 32 : 26
            let bodyW: CGFloat = (kind % 3 == 2) ? 48 : 42
            let body = UIBezierPath(ovalIn: CGRect(x: cx - bodyW * 0.5, y: cy - bodyH * 0.5, width: bodyW, height: bodyH))
            bodyColor.setFill()
            body.fill()

            // Subtle vertical stripes
            stripeColor.setFill()
            UIBezierPath(roundedRect: CGRect(x: cx - 8, y: cy - bodyH * 0.42, width: 5, height: bodyH * 0.84), cornerRadius: 2.5).fill()
            UIBezierPath(roundedRect: CGRect(x: cx + 2, y: cy - bodyH * 0.38, width: 4, height: bodyH * 0.76), cornerRadius: 2).fill()

            // Eye
            UIColor.white.setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + bodyW * 0.22, y: cy - 6, width: 8, height: 8)).fill()
            UIColor(red: 0.08, green: 0.12, blue: 0.20, alpha: 1.0).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + bodyW * 0.22 + 3, y: cy - 4, width: 4.5, height: 4.5)).fill()
        }

        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func sharkTexture() -> SKTexture {
        let key = "shark"
        if let tex = cache[key] { return tex }

        let size = CGSize(width: 180, height: 100)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let cx = size.width * 0.53
            let cy = size.height * 0.54

            // Subtle menacing red danger glow
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 14, color: UIColor(red: 1.0, green: 0.22, blue: 0.25, alpha: 0.42).cgColor)

            // Crescent shark tail
            let tail = UIBezierPath()
            tail.move(to: CGPoint(x: cx - 42, y: cy))
            tail.addLine(to: CGPoint(x: cx - 78, y: cy - 28))
            tail.addQuadCurve(to: CGPoint(x: cx - 60, y: cy), controlPoint: CGPoint(x: cx - 64, y: cy - 10))
            tail.addLine(to: CGPoint(x: cx - 74, y: cy + 22))
            tail.close()
            UIColor(red: 0.22, green: 0.30, blue: 0.40, alpha: 1.0).setFill()
            tail.fill()

            // Iconic tall dorsal fin
            let dorsal = UIBezierPath()
            dorsal.move(to: CGPoint(x: cx - 14, y: cy - 18))
            dorsal.addQuadCurve(to: CGPoint(x: cx + 2, y: cy - 44), controlPoint: CGPoint(x: cx - 10, y: cy - 34))
            dorsal.addQuadCurve(to: CGPoint(x: cx + 18, y: cy - 17), controlPoint: CGPoint(x: cx + 10, y: cy - 30))
            dorsal.close()
            UIColor(red: 0.24, green: 0.32, blue: 0.44, alpha: 1.0).setFill()
            dorsal.fill()

            // Sleek torpedo body
            let body = UIBezierPath()
            body.move(to: CGPoint(x: cx - 46, y: cy))
            body.addQuadCurve(to: CGPoint(x: cx + 62, y: cy - 2), controlPoint: CGPoint(x: cx + 6, y: cy - 34))
            body.addQuadCurve(to: CGPoint(x: cx + 30, y: cy + 18), controlPoint: CGPoint(x: cx + 52, y: cy + 16))
            body.addQuadCurve(to: CGPoint(x: cx - 46, y: cy), controlPoint: CGPoint(x: cx - 12, y: cy + 22))
            body.close()
            UIColor(red: 0.28, green: 0.37, blue: 0.49, alpha: 1.0).setFill()
            body.fill()
            cg.restoreGState()

            // Pale underbelly
            let belly = UIBezierPath()
            belly.move(to: CGPoint(x: cx - 26, y: cy + 7))
            belly.addQuadCurve(to: CGPoint(x: cx + 44, y: cy + 8), controlPoint: CGPoint(x: cx + 10, y: cy + 20))
            belly.addLine(to: CGPoint(x: cx + 12, y: cy + 6))
            belly.close()
            UIColor(red: 0.78, green: 0.85, blue: 0.90, alpha: 0.85).setFill()
            belly.fill()

            // Gill slits
            UIColor(red: 0.14, green: 0.20, blue: 0.28, alpha: 0.8).setStroke()
            for gx in [cx + 8, cx + 14, cx + 20] {
                let gill = UIBezierPath()
                gill.move(to: CGPoint(x: gx, y: cy - 5))
                gill.addLine(to: CGPoint(x: gx - 2, y: cy + 7))
                gill.lineWidth = 2.0
                gill.stroke()
            }

            // Sharp teeth mouth
            let mouth = UIBezierPath()
            mouth.move(to: CGPoint(x: cx + 32, y: cy + 10))
            mouth.addLine(to: CGPoint(x: cx + 54, y: cy + 6))
            UIColor(red: 0.12, green: 0.08, blue: 0.12, alpha: 0.9).setStroke()
            mouth.lineWidth = 2.5
            mouth.stroke()

            UIColor.white.setFill()
            for tx in stride(from: cx + 35, through: cx + 49, by: 5) {
                let tooth = UIBezierPath()
                tooth.move(to: CGPoint(x: tx, y: cy + 9))
                tooth.addLine(to: CGPoint(x: tx + 2.5, y: cy + 14))
                tooth.addLine(to: CGPoint(x: tx + 4.5, y: cy + 8))
                tooth.close()
                tooth.fill()
            }

            // Glowing crimson eye
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 7, color: UIColor.red.cgColor)
            UIColor(red: 1.0, green: 0.22, blue: 0.22, alpha: 1.0).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + 36, y: cy - 9, width: 10, height: 10)).fill()
            cg.restoreGState()
            UIColor(red: 0.25, green: 0.02, blue: 0.02, alpha: 1.0).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx + 41, y: cy - 7, width: 4, height: 6)).fill()
        }

        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func prankOrbTexture(prank: PrankType) -> SKTexture {
        let key = "orb_\(prank.rawValue)"
        if let tex = cache[key] { return tex }

        let size = CGSize(width: 72, height: 72)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let rect = CGRect(x: 12, y: 12, width: 48, height: 48)
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 12, color: UIColor(red: 0.72, green: 0.30, blue: 1.0, alpha: 0.85).cgColor)
            UIColor(red: 0.52, green: 0.22, blue: 0.90, alpha: 0.88).setFill()
            UIBezierPath(ovalIn: rect).fill()
            cg.restoreGState()

            UIColor(red: 0.90, green: 0.76, blue: 1.0, alpha: 0.95).setStroke()
            let ring = UIBezierPath(ovalIn: rect)
            ring.lineWidth = 2.5
            ring.stroke()

            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24)
            ]
            let text = NSString(string: prank.emoji)
            let tSize = text.size(withAttributes: attrs)
            text.draw(at: CGPoint(x: (size.width - tSize.width) * 0.5, y: (size.height - tSize.height) * 0.5), withAttributes: attrs)
        }

        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func bubbleTexture() -> SKTexture {
        let key = "bubble_trap"
        if let tex = cache[key] { return tex }

        let size = CGSize(width: 110, height: 110)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { _ in
            let rect = CGRect(x: 6, y: 6, width: 98, height: 98)
            UIColor(red: 0.65, green: 0.95, blue: 1.0, alpha: 0.24).setFill()
            UIBezierPath(ovalIn: rect).fill()

            UIColor(red: 0.88, green: 0.98, blue: 1.0, alpha: 0.88).setStroke()
            let stroke = UIBezierPath(ovalIn: rect)
            stroke.lineWidth = 3.0
            stroke.stroke()

            UIColor.white.withAlphaComponent(0.75).setFill()
            UIBezierPath(ovalIn: CGRect(x: 24, y: 20, width: 24, height: 14)).fill()
        }

        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }
}

// MARK: - Internal Simulation Entities

private struct SimPlayer {
    var x: Float
    var y: Float
    var vx: Float = 0
    var vy: Float = 0
    var facingRight: Bool = true
    var score: Int = 0
    var level: Int = 1
    var lives: Int = 3
    var dashCooldown: Float = 0
    var dashTimer: Float = 0
    var invuln: Float = 0
    var inkTimer: Float = 0
    var invertTimer: Float = 0
    var bubbleTimer: Float = 0
    var pranksUsed: Int = 0
    var bites: Int = 0

    var radius: Float {
        16.0 + Float(level - 1) * 4.5
    }

    func toSync() -> PlayerSyncState {
        PlayerSyncState(
            x: x, y: y, facingRight: facingRight,
            score: score, level: level, lives: lives,
            dashCooldown: dashCooldown, invuln: invuln,
            inkTimer: inkTimer, invertTimer: invertTimer,
            bubbleTimer: bubbleTimer, isDashing: dashTimer > 0,
            pranksUsed: pranksUsed, bites: bites
        )
    }

    mutating func apply(_ s: PlayerSyncState, lerp: Float) {
        x += (s.x - x) * lerp
        y += (s.y - y) * lerp
        facingRight = s.facingRight
        score = s.score
        level = s.level
        lives = s.lives
        dashCooldown = s.dashCooldown
        invuln = s.invuln
        inkTimer = s.inkTimer
        invertTimer = s.invertTimer
        bubbleTimer = s.bubbleTimer
        dashTimer = s.isDashing ? 0.15 : 0
        pranksUsed = s.pranksUsed
        bites = s.bites
    }
}

private struct SimFish {
    var id: Int
    var x: Float
    var y: Float
    var baseY: Float
    var vx: Float
    var vy: Float
    var radius: Float
    var kind: UInt8
    var isShark: Bool
    var bobPhase: Float
    var bobAmp: Float
    var chaseTarget: Int? // 0 = P1, 1 = P2
    var chaseTimer: Float

    func toSync() -> FishSyncState {
        FishSyncState(
            id: id, x: x, y: y, vx: vx, vy: vy,
            radius: radius, kind: kind, isShark: isShark,
            facingRight: vx >= 0, isChasing: chaseTarget != nil && chaseTimer > 0
        )
    }
}

private struct SimOrb {
    var id: Int
    var x: Float
    var y: Float
    var baseY: Float
    var phase: Float
    var prank: PrankType
    var life: Float

    func toSync() -> OrbSyncState {
        OrbSyncState(id: id, x: x, y: y, prank: prank)
    }
}

private struct SimWarning {
    var y: Float
    var fromLeft: Bool
    var timer: Float
    var duration: Float
    var chaseTarget: Int?
}

// MARK: - SpriteKit Ocean Scene

final class OceanScene: SKScene {
    // Virtual 2:1 landscape world that fills every modern iPhone edge-to-edge without black bars
    static let worldWidth: CGFloat = 1200
    static let worldHeight: CGFloat = 600
    static let safeMinX: Float = 85
    static let safeMaxX: Float = 1115
    static let safeMinY: Float = 56
    static let safeMaxY: Float = 544

    // External callbacks to SwiftUI / Multipeer
    var onHudUpdate: ((HudState) -> Void)?
    var onRoundOver: ((RoundResult) -> Void)?
    var onSendSnapshot: ((WorldSnapshot) -> Void)?
    var onSendEvent: ((GameEventPacket) -> Void)?
    var onSendGuestInput: ((PlayerInputPacket) -> Void)?

    // Configuration
    private(set) var currentMap: MapTheme = .lagoon
    private var gamePhase: GamePhase = .menu
    private var gameMode: GameMode = .solo
    private var isGuestClient: Bool = false
    private var seriesP1: Int = 0
    private var seriesP2: Int = 0

    // Local & remote inputs
    private var localInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)
    private var remoteGuestInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)

    // Simulation state
    private var p1 = SimPlayer(x: 340, y: 300, facingRight: true)
    private var p2 = SimPlayer(x: 860, y: 300, facingRight: false)
    private var fishes: [SimFish] = []
    private var orbs: [SimOrb] = []
    private var warnings: [SimWarning] = []
    private var nextEntityID: Int = 1

    // Timers
    private var lastUpdateTime: TimeInterval = 0
    private var simTime: Float = 0
    private var roundTimeRemaining: Float = 90.0
    private var sharkSpawnTimer: Float = 7.5
    private var orbSpawnTimer: Float = 8.5
    private var snapshotTimer: Float = 0
    private var guestInputTimer: Float = 0
    private var hudTimer: Float = 0
    private var bubbleEmitTimer: Float = 0

    // Calm AI bot state (human-like pace)
    private var botRetargetTimer: Float = 0
    private var botPauseTimer: Float = 0
    private var botTargetID: Int? = nil
    private var botWanderAngle: Float = 0

    // Active banner toast
    private var bannerText: String? = nil
    private var bannerEmoji: String? = nil
    private var bannerTimer: Float = 0

    // Scene layers & visual nodes
    private let bgNode = SKSpriteNode()
    private let kelpLayer = SKNode()
    private let bubbleLayer = SKNode()
    private let worldLayer = SKNode()
    private let fxLayer = SKNode()
    private let warningLayer = SKNode()

    private var kelpNodes: [(SKShapeNode, CGFloat, CGFloat, CGFloat)] = []
    private var ambientBubbles: [(SKShapeNode, CGFloat, CGFloat)] = []

    // Player visual containers (separate sprite from label so label never mirrors)
    private let p1Container = SKNode()
    private let p1Sprite = SKSpriteNode()
    private let p1Tag = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p1Crown = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p1Bubble = SKSpriteNode()

    private let p2Container = SKNode()
    private let p2Sprite = SKSpriteNode()
    private let p2Tag = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p2Crown = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p2Bubble = SKSpriteNode()

    // Entity visual pools
    private var fishNodes: [Int: SKSpriteNode] = [:]
    private var orbNodes: [Int: SKSpriteNode] = [:]
    private var warningNodes: [SKNode] = []

    // Guest interpolated state
    private var latestSnapshot: WorldSnapshot? = nil

    override init(size: CGSize) {
        super.init(size: CGSize(width: Self.worldWidth, height: Self.worldHeight))
        scaleMode = .aspectFill
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.04, green: 0.25, blue: 0.45, alpha: 1.0)
        setupLayers()
        applyMapVisuals(.lagoon, animated: false)
        setupMenuAmbientFish()
    }

    private func setupLayers() {
        bgNode.position = CGPoint(x: Self.worldWidth * 0.5, y: Self.worldHeight * 0.5)
        bgNode.zPosition = -20
        addChild(bgNode)

        kelpLayer.zPosition = -10
        addChild(kelpLayer)

        bubbleLayer.zPosition = -5
        addChild(bubbleLayer)

        worldLayer.zPosition = 5
        addChild(worldLayer)

        fxLayer.zPosition = 15
        addChild(fxLayer)

        warningLayer.zPosition = 25
        addChild(warningLayer)

        // Setup P1 visual container
        p1Sprite.texture = OceanTextureFactory.shared.playerFishTexture(isP1: true)
        p1Sprite.size = CGSize(width: 64, height: 48)
        p1Container.addChild(p1Sprite)

        p1Tag.fontSize = 13
        p1Tag.fontColor = UIColor(red: 1.0, green: 0.92, blue: 0.45, alpha: 0.95)
        p1Tag.position = CGPoint(x: 0, y: 26)
        p1Container.addChild(p1Tag)

        p1Crown.text = "👑"
        p1Crown.fontSize = 18
        p1Crown.position = CGPoint(x: 0, y: 40)
        p1Crown.isHidden = true
        p1Container.addChild(p1Crown)

        p1Bubble.texture = OceanTextureFactory.shared.bubbleTexture()
        p1Bubble.size = CGSize(width: 78, height: 78)
        p1Bubble.isHidden = true
        p1Bubble.zPosition = 4
        p1Container.addChild(p1Bubble)
        p1Container.zPosition = 12
        p1Container.isHidden = true
        worldLayer.addChild(p1Container)

        // Setup P2 visual container
        p2Sprite.texture = OceanTextureFactory.shared.playerFishTexture(isP1: false)
        p2Sprite.size = CGSize(width: 64, height: 48)
        p2Container.addChild(p2Sprite)

        p2Tag.fontSize = 13
        p2Tag.fontColor = UIColor(red: 1.0, green: 0.62, blue: 0.84, alpha: 0.95)
        p2Tag.position = CGPoint(x: 0, y: 26)
        p2Container.addChild(p2Tag)

        p2Crown.text = "👑"
        p2Crown.fontSize = 18
        p2Crown.position = CGPoint(x: 0, y: 40)
        p2Crown.isHidden = true
        p2Container.addChild(p2Crown)

        p2Bubble.texture = OceanTextureFactory.shared.bubbleTexture()
        p2Bubble.size = CGSize(width: 78, height: 78)
        p2Bubble.isHidden = true
        p2Bubble.zPosition = 4
        p2Container.addChild(p2Bubble)
        p2Container.zPosition = 11
        p2Container.isHidden = true
        worldLayer.addChild(p2Container)

        // Ambient decorative rising bubbles
        for _ in 0..<22 {
            let r = CGFloat.random(in: 3...8)
            let b = SKShapeNode(circleOfRadius: r)
            b.fillColor = UIColor.white.withAlphaComponent(0.14)
            b.strokeColor = UIColor.white.withAlphaComponent(0.32)
            b.lineWidth = 1.0
            b.position = CGPoint(x: CGFloat.random(in: 40...1160), y: CGFloat.random(in: 20...580))
            bubbleLayer.addChild(b)
            ambientBubbles.append((b, CGFloat.random(in: 16...36), CGFloat.random(in: 0...6.28)))
        }
    }

    // MARK: - Public Controls & State

    func setMap(_ map: MapTheme) {
        guard map != currentMap else { return }
        applyMapVisuals(map, animated: true)
    }

    private func applyMapVisuals(_ map: MapTheme, animated: Bool) {
        currentMap = map
        RetroAudioEngine.shared.setMap(map)

        let tex = OceanTextureFactory.shared.backgroundTexture(for: map, size: CGSize(width: Self.worldWidth, height: Self.worldHeight))
        if animated {
            let fadeOverlay = SKSpriteNode(texture: bgNode.texture)
            fadeOverlay.position = bgNode.position
            fadeOverlay.size = CGSize(width: Self.worldWidth, height: Self.worldHeight)
            fadeOverlay.zPosition = -19
            addChild(fadeOverlay)
            bgNode.texture = tex
            bgNode.size = CGSize(width: Self.worldWidth, height: Self.worldHeight)
            fadeOverlay.run(SKAction.sequence([SKAction.fadeOut(withDuration: 0.45), SKAction.removeFromParent()]))
        } else {
            bgNode.texture = tex
            bgNode.size = CGSize(width: Self.worldWidth, height: Self.worldHeight)
        }

        rebuildKelp(for: map)
    }

    private func rebuildKelp(for map: MapTheme) {
        kelpLayer.removeAllChildren()
        kelpNodes.removeAll()

        let xPositions: [CGFloat] = [95, 145, 270, 320, 460, 660, 710, 860, 930, 1060, 1110]
        for (i, xPos) in xPositions.enumerated() {
            let h = CGFloat.random(in: map == .lagoon ? 95...175 : 85...155)
            let node = SKShapeNode()
            node.position = CGPoint(x: xPos, y: 22)
            node.lineWidth = map == .lagoon ? 9.0 : 7.5
            node.lineCap = .round
            if map == .lagoon {
                let greenTone = (i % 2 == 0)
                    ? UIColor(red: 0.14, green: 0.72, blue: 0.36, alpha: 0.78)
                    : UIColor(red: 0.22, green: 0.80, blue: 0.42, alpha: 0.70)
                node.strokeColor = greenTone
            } else {
                let deepTone = (i % 2 == 0)
                    ? UIColor(red: 0.08, green: 0.52, blue: 0.48, alpha: 0.68)
                    : UIColor(red: 0.14, green: 0.68, blue: 0.58, alpha: 0.56)
                node.strokeColor = deepTone
            }
            kelpLayer.addChild(node)
            kelpNodes.append((node, h, CGFloat.random(in: 0...6.28), CGFloat.random(in: 1.1...1.8)))
        }
    }

    func updateLocalInput(dx: Float, dy: Float, dashPressed: Bool) {
        localInput.dx = dx
        localInput.dy = dy
        if dashPressed {
            localInput.dashPressed = true
        }
    }

    func receiveGuestInput(_ packet: PlayerInputPacket) {
        remoteGuestInput.dx = packet.dx
        remoteGuestInput.dy = packet.dy
        if packet.dashPressed {
            remoteGuestInput.dashPressed = true
        }
    }

    func receiveSnapshot(_ snapshot: WorldSnapshot) {
        guard isGuestClient else { return }
        if snapshot.map != currentMap {
            applyMapVisuals(snapshot.map, animated: false)
        }
        latestSnapshot = snapshot
    }

    func receiveNetworkEvent(_ event: GameEventPacket) {
        let localIdx = isGuestClient ? 1 : 0
        triggerLocalFeedback(for: event, localIdx: localIdx)
    }

    func returnToMenu() {
        gamePhase = .menu
        isGuestClient = false
        clearGameplayEntities()
        p1Container.isHidden = true
        p2Container.isHidden = true
        setupMenuAmbientFish()
    }

    func startMatch(mode: GameMode, map: MapTheme, isGuest: Bool, seriesP1: Int, seriesP2: Int) {
        self.gameMode = mode
        self.isGuestClient = isGuest
        self.seriesP1 = seriesP1
        self.seriesP2 = seriesP2
        self.gamePhase = .playing
        self.latestSnapshot = nil

        if map != currentMap {
            applyMapVisuals(map, animated: true)
        }

        clearGameplayEntities()

        p1 = SimPlayer(x: 340, y: 300, facingRight: true)
        p2 = SimPlayer(x: 860, y: 300, facingRight: false)
        localInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)
        remoteGuestInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)

        roundTimeRemaining = 90.0
        sharkSpawnTimer = 8.0
        orbSpawnTimer = 7.5
        botRetargetTimer = 0.6
        botPauseTimer = 0
        bannerText = nil
        bannerEmoji = nil
        bannerTimer = 0

        // Labels so each player clearly sees themselves
        if isGuest {
            p1Tag.text = "▼ ПАРТНЁР"
            p2Tag.text = "▼ ТЫ"
        } else {
            p1Tag.text = "▼ ТЫ"
            p2Tag.text = (mode == .solo) ? "▼ БОТ" : "▼ ПАРТНЁР"
        }

        p1Container.isHidden = false
        p2Container.isHidden = false
        p1Container.position = CGPoint(x: CGFloat(p1.x), y: CGFloat(p1.y))
        p2Container.position = CGPoint(x: CGFloat(p2.x), y: CGFloat(p2.y))

        if !isGuest {
            for _ in 0..<14 {
                spawnEdibleFish(randomX: true)
            }
        }

        emitHud()
    }

    private func clearGameplayEntities() {
        fishes.removeAll()
        orbs.removeAll()
        warnings.removeAll()
        for (_, node) in fishNodes { node.removeFromParent() }
        fishNodes.removeAll()
        for (_, node) in orbNodes { node.removeFromParent() }
        orbNodes.removeAll()
        for node in warningNodes { node.removeFromParent() }
        warningNodes.removeAll()
    }

    private func setupMenuAmbientFish() {
        clearGameplayEntities()
        for _ in 0..<12 {
            spawnEdibleFish(randomX: true)
        }
    }

    // MARK: - Main Frame Loop (Strict dt for identical 60Hz & 120Hz feel)

    override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime == 0 { lastUpdateTime = currentTime }
        let rawDt = Float(currentTime - lastUpdateTime)
        lastUpdateTime = currentTime
        let dt = min(max(rawDt, 0.001), 0.05)
        simTime += dt

        animateEnvironment(dt: dt)

        if gamePhase == .menu {
            updateMenuFish(dt: dt)
            syncEntityNodes()
            return
        }

        guard gamePhase == .playing else { return }

        if bannerTimer > 0 {
            bannerTimer -= dt
            if bannerTimer <= 0 {
                bannerText = nil
                bannerEmoji = nil
            }
        }

        if isGuestClient {
            updateGuestClient(dt: dt)
        } else {
            updateHostSimulation(dt: dt)
        }

        syncPlayerVisuals()
        syncEntityNodes()
        syncWarningVisuals()

        hudTimer += dt
        if hudTimer >= 0.06 {
            hudTimer = 0
            emitHud()
        }
    }

    // MARK: - Environment Animation

    private func animateEnvironment(dt: Float) {
        // Gentle swaying kelp blades
        for (node, height, phase, speed) in kelpNodes {
            let sway = sin(CGFloat(simTime) * speed + phase) * 14.0
            let path = UIBezierPath()
            path.move(to: .zero)
            path.addCurve(
                to: CGPoint(x: sway, y: height),
                controlPoint1: CGPoint(x: sway * 0.35 + 8, y: height * 0.35),
                controlPoint2: CGPoint(x: sway * 0.75 - 8, y: height * 0.72)
            )
            node.path = path.cgPath
        }

        // Rising ambient bubbles
        for (bubble, speed, phase) in ambientBubbles {
            bubble.position.y += speed * CGFloat(dt)
            bubble.position.x += sin(CGFloat(simTime) * 1.4 + phase) * 8.0 * CGFloat(dt)
            if bubble.position.y > Self.worldHeight + 16 {
                bubble.position.y = -12
                bubble.position.x = CGFloat.random(in: 40...1160)
            }
        }
    }

    private func updateMenuFish(dt: Float) {
        for i in fishes.indices {
            fishes[i].x += fishes[i].vx * dt
            fishes[i].bobPhase += dt * 1.6
            fishes[i].y = fishes[i].baseY + sin(fishes[i].bobPhase) * fishes[i].bobAmp
            if fishes[i].vx > 0 && fishes[i].x > Float(Self.worldWidth) + 70 {
                fishes[i].x = -70
            } else if fishes[i].vx < 0 && fishes[i].x < -70 {
                fishes[i].x = Float(Self.worldWidth) + 70
            }
        }
    }

    // MARK: - Guest Client Loop

    private func updateGuestClient(dt: Float) {
        // Send input to Host at ~30Hz (or immediately when dash tapped)
        guestInputTimer += dt
        if guestInputTimer >= 0.033 || localInput.dashPressed {
            guestInputTimer = 0
            onSendGuestInput?(localInput)
            localInput.dashPressed = false
        }

        guard let snap = latestSnapshot else { return }
        let lerp = min(1.0, 1.0 - exp(-18.0 * dt))
        p1.apply(snap.p1, lerp: lerp)
        p2.apply(snap.p2, lerp: lerp)
        roundTimeRemaining = snap.timeRemaining

        // Update fishes smoothly
        var updatedFishes: [SimFish] = []
        updatedFishes.reserveCapacity(snap.fish.count)
        for sf in snap.fish {
            if let existing = fishes.first(where: { $0.id == sf.id }) {
                var f = existing
                f.x += (sf.x - f.x) * lerp
                f.y += (sf.y - f.y) * lerp
                f.vx = sf.vx
                f.vy = sf.vy
                f.radius = sf.radius
                f.isShark = sf.isShark
                f.chaseTarget = sf.isChasing ? 1 : nil
                f.chaseTimer = sf.isChasing ? 1 : 0
                updatedFishes.append(f)
            } else {
                updatedFishes.append(SimFish(
                    id: sf.id, x: sf.x, y: sf.y, baseY: sf.y,
                    vx: sf.vx, vy: sf.vy, radius: sf.radius,
                    kind: sf.kind, isShark: sf.isShark,
                    bobPhase: 0, bobAmp: 0, chaseTarget: sf.isChasing ? 1 : nil, chaseTimer: sf.isChasing ? 1 : 0
                ))
            }
        }
        fishes = updatedFishes

        orbs = snap.orbs.map {
            SimOrb(id: $0.id, x: $0.x, y: $0.y, baseY: $0.y, phase: 0, prank: $0.prank, life: 10)
        }
        warnings = snap.warnings.map {
            SimWarning(y: $0.y, fromLeft: $0.fromLeft, timer: (1.0 - $0.progress) * 1.4, duration: 1.4, chaseTarget: nil)
        }

        // Local shark proximity heartbeat for Guest
        let prox = computeSharkProximity(for: p2)
        if prox > 0.14 {
            HapticManager.shared.playSharkHeartbeat(proximity: prox)
        }
    }

    // MARK: - Host Authoritative Simulation

    private func updateHostSimulation(dt: Float) {
        roundTimeRemaining = max(0, roundTimeRemaining - dt)

        // Update Player 1 (Local Host)
        let p1Dash = localInput.dashPressed
        localInput.dashPressed = false
        updatePlayer(&p1, dx: localInput.dx, dy: localInput.dy, dashPressed: p1Dash, playerIdx: 0, speedScale: 1.0, dt: dt)

        // Update Player 2 (Either calm AI Bot or Remote Guest)
        if gameMode == .solo {
            let (bdx, bdy) = computeCalmBotInput(dt: dt)
            updatePlayer(&p2, dx: bdx, dy: bdy, dashPressed: false, playerIdx: 1, speedScale: 0.72, dt: dt)
        } else {
            let p2Dash = remoteGuestInput.dashPressed
            remoteGuestInput.dashPressed = false
            updatePlayer(&p2, dx: remoteGuestInput.dx, dy: remoteGuestInput.dy, dashPressed: p2Dash, playerIdx: 1, speedScale: 1.0, dt: dt)
        }

        // Maintain comfortable horizontal stream of edible fish (~14-16 fish)
        let edibleCount = fishes.filter { !$0.isShark }.count
        if edibleCount < 15 {
            spawnEdibleFish(randomX: false)
        }

        // Rare sharks with 1.4s edge warning (max 1 early, up to 2 in final 35s)
        sharkSpawnTimer -= dt
        let maxSharks = roundTimeRemaining < 35 ? 2 : 1
        let activeSharks = fishes.filter { $0.isShark }.count + warnings.count
        if sharkSpawnTimer <= 0 {
            if activeSharks < maxSharks {
                let yLane = Float.random(in: 105...495)
                let fromLeft = Bool.random()
                warnings.append(SimWarning(y: yLane, fromLeft: fromLeft, timer: 1.4, duration: 1.4, chaseTarget: nil))
                dispatchEvent(GameEventPacket(type: .sharkWarning, targetPlayer: 2))
            }
            sharkSpawnTimer = Float.random(in: 9.0...12.5)
        }

        // Prank purple orbs every 9-13 seconds (max 2 on screen)
        orbSpawnTimer -= dt
        if orbSpawnTimer <= 0 {
            if orbs.count < 2 {
                spawnPrankOrb()
            }
            orbSpawnTimer = Float.random(in: 9.0...13.0)
        }

        // Process shark warnings
        for i in stride(from: warnings.count - 1, through: 0, by: -1) {
            warnings[i].timer -= dt
            if warnings[i].timer <= 0 {
                let w = warnings.remove(at: i)
                spawnShark(y: w.y, fromLeft: w.fromLeft, chaseTarget: w.chaseTarget)
            }
        }

        // Update all fish
        for i in stride(from: fishes.count - 1, through: 0, by: -1) {
            if fishes[i].isShark {
                updateShark(&fishes[i], dt: dt)
            } else {
                fishes[i].x += fishes[i].vx * dt
                fishes[i].bobPhase += dt * 1.9
                fishes[i].y = fishes[i].baseY + sin(fishes[i].bobPhase) * fishes[i].bobAmp
            }

            if fishes[i].x < -140 || fishes[i].x > Float(Self.worldWidth) + 140 {
                fishes.remove(at: i)
            }
        }

        // Update orbs
        for i in stride(from: orbs.count - 1, through: 0, by: -1) {
            orbs[i].life -= dt
            orbs[i].phase += dt * 2.4
            orbs[i].y = orbs[i].baseY + sin(orbs[i].phase) * 10.0
            if orbs[i].life <= 0 {
                orbs.remove(at: i)
            }
        }

        // Collisions for both players
        checkPlayerCollisions(player: &p1, opponent: &p2, playerIdx: 0)
        checkPlayerCollisions(player: &p2, opponent: &p1, playerIdx: 1)

        // Subtle trail bubbles for players
        bubbleEmitTimer += dt
        if bubbleEmitTimer >= 0.22 {
            bubbleEmitTimer = 0
            emitTinyBubble(at: CGPoint(x: CGFloat(p1.x), y: CGFloat(p1.y)))
            emitTinyBubble(at: CGPoint(x: CGFloat(p2.x), y: CGFloat(p2.y)))
        }

        // Host shark heartbeat haptics
        let prox = computeSharkProximity(for: p1)
        if prox > 0.14 {
            HapticManager.shared.playSharkHeartbeat(proximity: prox)
        }

        // Broadcast snapshot at 25Hz in multiplayer
        if gameMode == .multiplayer {
            snapshotTimer += dt
            if snapshotTimer >= 0.04 {
                snapshotTimer = 0
                let snap = WorldSnapshot(
                    p1: p1.toSync(),
                    p2: p2.toSync(),
                    fish: fishes.map { $0.toSync() },
                    orbs: orbs.map { $0.toSync() },
                    warnings: warnings.map {
                        WarningSyncState(y: $0.y, fromLeft: $0.fromLeft, progress: 1.0 - max(0, $0.timer / $0.duration))
                    },
                    timeRemaining: roundTimeRemaining,
                    map: currentMap
                )
                onSendSnapshot?(snap)
            }
        }

        // Check round end
        if roundTimeRemaining <= 0 || p1.lives <= 0 || p2.lives <= 0 {
            finishRound()
        }
    }

    private func updatePlayer(_ p: inout SimPlayer, dx: Float, dy: Float, dashPressed: Bool, playerIdx: Int, speedScale: Float, dt: Float) {
        if p.dashCooldown > 0 { p.dashCooldown = max(0, p.dashCooldown - dt) }
        if p.dashTimer > 0 { p.dashTimer = max(0, p.dashTimer - dt) }
        if p.invuln > 0 { p.invuln = max(0, p.invuln - dt) }
        if p.inkTimer > 0 { p.inkTimer = max(0, p.inkTimer - dt) }
        if p.invertTimer > 0 { p.invertTimer = max(0, p.invertTimer - dt) }

        // Soap bubble prank floats the player gently upward
        if p.bubbleTimer > 0 {
            p.bubbleTimer -= dt
            p.vx *= exp(-6.0 * dt)
            p.vy = 62.0
            p.x += p.vx * dt
            p.y += p.vy * dt
            clampPlayer(&p)
            if p.bubbleTimer <= 0 {
                p.bubbleTimer = 0
                dispatchEvent(GameEventPacket(type: .bubblePop, targetPlayer: playerIdx))
                spawnWaterRipple(at: CGPoint(x: CGFloat(p.x), y: CGFloat(p.y)), color: UIColor(red: 0.72, green: 0.96, blue: 1.0, alpha: 0.85))
            }
            return
        }

        // Trigger dash
        if dashPressed && p.dashCooldown <= 0 {
            p.dashTimer = 0.24
            p.dashCooldown = 2.6
            dispatchEvent(GameEventPacket(type: .dash, targetPlayer: playerIdx))
        }

        var inX = dx
        var inY = dy
        if p.invertTimer > 0 {
            inX = -inX
            inY = -inY
        }

        let mag = hypot(inX, inY)
        if mag > 1.0 {
            inX /= mag
            inY /= mag
        }

        let baseSpeed: Float = (255.0 - Float(p.level - 1) * 8.0) * speedScale
        let boost: Float = p.dashTimer > 0 ? 1.85 : 1.0
        let targetVX = inX * baseSpeed * boost
        let targetVY = inY * baseSpeed * boost

        // Crisp, responsive feel without heavy slippery inertia
        let accelRate: Float = (mag > 0.05) ? 14.0 : 11.5
        let factor = 1.0 - exp(-accelRate * dt)
        p.vx += (targetVX - p.vx) * factor
        p.vy += (targetVY - p.vy) * factor

        p.x += p.vx * dt
        p.y += p.vy * dt

        if abs(inX) > 0.08 {
            p.facingRight = inX > 0
        }

        clampPlayer(&p)
    }

    private func clampPlayer(_ p: inout SimPlayer) {
        p.x = min(max(p.x, Self.safeMinX), Self.safeMaxX)
        p.y = min(max(p.y, Self.safeMinY), Self.safeMaxY)
    }

    private func computeCalmBotInput(dt: Float) -> (Float, Float) {
        // Human pause after eating
        if botPauseTimer > 0 {
            botPauseTimer -= dt
            return (0, 0)
        }

        // Avoid nearby sharks calmly
        for f in fishes where f.isShark {
            let dx = p2.x - f.x
            let dy = p2.y - f.y
            let dist = hypot(dx, dy)
            if dist < 175 && dist > 1 {
                return (dx / dist, dy / dist)
            }
        }

        // Ink disorients the bot gently
        if p2.inkTimer > 0 {
            botWanderAngle += dt * 3.2
            return (cos(botWanderAngle) * 0.5, sin(botWanderAngle) * 0.5)
        }

        // Re-evaluate target only every 0.9 - 1.5s within 270pt vision
        botRetargetTimer -= dt
        if botRetargetTimer <= 0 || botTargetID == nil {
            botRetargetTimer = Float.random(in: 0.9...1.5)
            botTargetID = nil
            var bestDist: Float = 270.0
            for f in fishes where !f.isShark && f.radius <= p2.radius * 1.06 {
                let d = hypot(f.x - p2.x, f.y - p2.y)
                if d < bestDist {
                    bestDist = d
                    botTargetID = f.id
                }
            }
        }

        if let tid = botTargetID, let target = fishes.first(where: { $0.id == tid }) {
            let dx = target.x - p2.x
            let dy = target.y - p2.y
            let d = hypot(dx, dy)
            if d > 6 {
                return (dx / d, dy / d)
            }
        }

        // Gentle ocean drift when nothing nearby
        botWanderAngle += dt * 0.65
        let driftX = cos(botWanderAngle) * 0.45
        let driftY = sin(botWanderAngle * 1.3) * 0.35
        return (driftX, driftY)
    }

    private func spawnEdibleFish(randomX: Bool) {
        let fromLeft = Bool.random()
        let speed = Float.random(in: 44...84)
        let x: Float = randomX
            ? Float.random(in: 120...1080)
            : (fromLeft ? -55 : Float(Self.worldWidth) + 55)
        let y = Float.random(in: 75...525)

        // ~85% clearly edible for level 1-2, occasional medium tasty fish for higher levels
        let r: Float
        let roll = Float.random(in: 0...1)
        if roll < 0.62 {
            r = Float.random(in: 9.5...13.5)
        } else if roll < 0.88 {
            r = Float.random(in: 14.0...17.5)
        } else {
            r = Float.random(in: 18.5...23.0)
        }

        let fish = SimFish(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            radius: r,
            kind: UInt8.random(in: 0...2),
            isShark: false,
            bobPhase: Float.random(in: 0...6.28),
            bobAmp: Float.random(in: 6...14),
            chaseTarget: nil,
            chaseTimer: 0
        )
        nextEntityID += 1
        fishes.append(fish)
    }

    private func spawnShark(y: Float, fromLeft: Bool, chaseTarget: Int?) {
        let speed = Float.random(in: 132...168)
        let x: Float = fromLeft ? -95 : Float(Self.worldWidth) + 95
        let shark = SimFish(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            radius: 35.0,
            kind: 99,
            isShark: true,
            bobPhase: 0,
            bobAmp: 6,
            chaseTarget: chaseTarget,
            chaseTimer: chaseTarget != nil ? 3.8 : 0
        )
        nextEntityID += 1
        fishes.append(shark)
    }

    private func updateShark(_ s: inout SimFish, dt: Float) {
        if let targetIdx = s.chaseTarget, s.chaseTimer > 0 {
            s.chaseTimer -= dt
            let target = (targetIdx == 0) ? p1 : p2
            let dx = target.x - s.x
            let dy = target.y - s.y
            let dist = max(1, hypot(dx, dy))
            let desiredVX = (dx / dist) * 165.0
            let desiredVY = (dy / dist) * 145.0
            let k = 1.0 - exp(-3.0 * dt)
            s.vx += (desiredVX - s.vx) * k
            s.vy += (desiredVY - s.vy) * k
            if s.chaseTimer <= 0 {
                // Cruise away calmly horizontally
                s.vx = s.vx >= 0 ? 155 : -155
                s.vy = 0
                s.chaseTarget = nil
            }
        }
        s.x += s.vx * dt
        s.y += s.vy * dt
        s.y = min(max(s.y, 70), 530)
    }

    private func spawnPrankOrb() {
        let prank = PrankType.allCases.randomElement() ?? .ink
        let x = Float.random(in: 220...980)
        let y = Float.random(in: 120...480)
        let orb = SimOrb(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            phase: Float.random(in: 0...6.28),
            prank: prank,
            life: 11.5
        )
        nextEntityID += 1
        orbs.append(orb)
    }

    private func checkPlayerCollisions(player: inout SimPlayer, opponent: inout SimPlayer, playerIdx: Int) {
        let oppIdx = (playerIdx == 0) ? 1 : 0

        // 1. Fish collisions
        for i in stride(from: fishes.count - 1, through: 0, by: -1) {
            let f = fishes[i]
            let dist = hypot(player.x - f.x, player.y - f.y)
            let hitDist = player.radius + f.radius * 0.78
            guard dist < hitDist else { continue }

            if f.isShark {
                // Shark hurts player unless invulnerable
                if player.invuln <= 0 {
                    player.lives = max(0, player.lives - 1)
                    player.invuln = 2.2
                    player.score = max(0, player.score - 3)
                    dispatchEvent(GameEventPacket(type: .hurt, targetPlayer: playerIdx))
                    spawnWaterRipple(at: CGPoint(x: CGFloat(player.x), y: CGFloat(player.y)), color: UIColor.systemRed.withAlphaComponent(0.8))
                }
            } else if f.radius <= player.radius * 1.15 {
                // Eat fish!
                let points = f.radius > 16 ? 2 : 1
                player.score += points
                player.bites += 1
                let eatenPos = CGPoint(x: CGFloat(f.x), y: CGFloat(f.y))
                fishes.remove(at: i)

                if playerIdx == 1 && gameMode == .solo {
                    botPauseTimer = Float.random(in: 0.45...0.65)
                    botTargetID = nil
                }

                let rippleColor = (playerIdx == 0)
                    ? UIColor(red: 1.0, green: 0.88, blue: 0.35, alpha: 0.8)
                    : UIColor(red: 1.0, green: 0.48, blue: 0.78, alpha: 0.8)
                spawnWaterRipple(at: eatenPos, color: rippleColor)
                dispatchEvent(GameEventPacket(type: .bite, targetPlayer: playerIdx))

                let newLevel = min(5, 1 + player.score / 10)
                if newLevel > player.level {
                    player.level = newLevel
                    dispatchEvent(GameEventPacket(type: .levelUp, targetPlayer: playerIdx))
                }
            }
        }

        // 2. Prank Orb collisions
        for i in stride(from: orbs.count - 1, through: 0, by: -1) {
            let orb = orbs[i]
            let dist = hypot(player.x - orb.x, player.y - orb.y)
            if dist < player.radius + 24 {
                let prank = orb.prank
                orbs.remove(at: i)
                player.pranksUsed += 1
                applyPrank(prank, fromPlayer: playerIdx, toOpponent: &opponent, opponentIdx: oppIdx)
            }
        }
    }

    private func applyPrank(_ prank: PrankType, fromPlayer: Int, toOpponent: inout SimPlayer, opponentIdx: Int) {
        switch prank {
        case .ink:
            toOpponent.inkTimer = 4.5
            dispatchEvent(GameEventPacket(type: .prankInk, targetPlayer: opponentIdx))
        case .invert:
            toOpponent.invertTimer = 4.8
            dispatchEvent(GameEventPacket(type: .prankInvert, targetPlayer: opponentIdx))
        case .shark:
            let fromLeft = toOpponent.x > Float(Self.worldWidth) * 0.5
            warnings.append(SimWarning(y: toOpponent.y, fromLeft: fromLeft, timer: 1.0, duration: 1.0, chaseTarget: opponentIdx))
            dispatchEvent(GameEventPacket(type: .prankShark, targetPlayer: opponentIdx))
        case .bubble:
            toOpponent.bubbleTimer = 3.6
            dispatchEvent(GameEventPacket(type: .prankBubble, targetPlayer: opponentIdx))
        }
        // Subtle confirmation haptic for the prank sender
        if fromPlayer == 0 {
            HapticManager.shared.playPrankSent()
        }
    }

    private func dispatchEvent(_ event: GameEventPacket) {
        let localIdx = isGuestClient ? 1 : 0
        triggerLocalFeedback(for: event, localIdx: localIdx)
        if gameMode == .multiplayer && !isGuestClient {
            onSendEvent?(event)
        }
    }

    private func triggerLocalFeedback(for event: GameEventPacket, localIdx: Int) {
        let isForMe = (event.targetPlayer == localIdx || event.targetPlayer == 2)
        switch event.type {
        case .bite:
            if isForMe {
                HapticManager.shared.playBite()
                RetroAudioEngine.shared.playSFX(.bite)
            }
        case .dash:
            if isForMe {
                HapticManager.shared.playDash()
                RetroAudioEngine.shared.playSFX(.dash)
            }
        case .sharkWarning:
            HapticManager.shared.playSharkWarning()
            RetroAudioEngine.shared.playSFX(.sharkWarning)
        case .levelUp:
            if isForMe {
                HapticManager.shared.playLevelUp()
                RetroAudioEngine.shared.playSFX(.levelUp)
                showBanner(emoji: "✨", text: "Новый уровень!")
            }
        case .prankInk:
            RetroAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🐙", text: "Чернила осьминога!")
            } else {
                showBanner(emoji: "🐙", text: "Чернила отправлены!")
            }
        case .prankInvert:
            RetroAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🔄", text: "Управление перевёрнуто!")
            } else {
                showBanner(emoji: "🔄", text: "Перевёртыш отправлен!")
            }
        case .prankShark:
            RetroAudioEngine.shared.playSFX(.sharkWarning)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🦈", text: "На тебя натравили акулу!")
            } else {
                showBanner(emoji: "🦈", text: "Акула пошла за соперником!")
            }
        case .prankBubble:
            RetroAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🫧", text: "Ты в мыльном пузыре!")
            } else {
                showBanner(emoji: "🫧", text: "Соперник в пузыре!")
            }
        case .bubblePop:
            RetroAudioEngine.shared.playSFX(.bubblePop)
            if isForMe {
                HapticManager.shared.playBubblePop()
            }
        case .hurt:
            RetroAudioEngine.shared.playSFX(.hurt)
            if isForMe {
                HapticManager.shared.playHurt()
            }
        }
    }

    private func showBanner(emoji: String, text: String) {
        bannerEmoji = emoji
        bannerText = text
        bannerTimer = 2.2
    }

    private func computeSharkProximity(for player: SimPlayer) -> Float {
        var maxProx: Float = 0
        for f in fishes where f.isShark {
            let d = hypot(player.x - f.x, player.y - f.y)
            if d < 320 {
                let p = max(0, 1.0 - d / 320.0)
                if p > maxProx { maxProx = p }
            }
        }
        return maxProx
    }

    private func finishRound() {
        gamePhase = .roundOver

        let winner: Int
        if p1.lives == 0 && p2.lives > 0 {
            winner = 1
        } else if p2.lives == 0 && p1.lives > 0 {
            winner = 0
        } else if p1.score > p2.score {
            winner = 0
        } else if p2.score > p1.score {
            winner = 1
        } else {
            winner = -1
        }

        if winner == 0 { seriesP1 += 1 }
        if winner == 1 { seriesP2 += 1 }

        let result = RoundResult(
            scoreP1: p1.score,
            scoreP2: p2.score,
            levelP1: p1.level,
            levelP2: p2.level,
            titleP1: TitleGenerator.pickTitle(score: p1.score, level: p1.level, lives: p1.lives, pranks: p1.pranksUsed, won: winner == 0),
            titleP2: TitleGenerator.pickTitle(score: p2.score, level: p2.level, lives: p2.lives, pranks: p2.pranksUsed, won: winner == 1),
            winnerIndex: winner,
            seriesP1: seriesP1,
            seriesP2: seriesP2
        )

        onRoundOver?(result)
    }

    // MARK: - SpriteKit Visual Sync

    private func syncPlayerVisuals() {
        updateSinglePlayerNode(
            p: p1, container: p1Container, sprite: p1Sprite,
            tag: p1Tag, crown: p1Crown, bubble: p1Bubble,
            isLeading: p1.score > p2.score && p1.score > 0
        )
        updateSinglePlayerNode(
            p: p2, container: p2Container, sprite: p2Sprite,
            tag: p2Tag, crown: p2Crown, bubble: p2Bubble,
            isLeading: p2.score > p1.score && p2.score > 0
        )
    }

    private func updateSinglePlayerNode(
        p: SimPlayer,
        container: SKNode,
        sprite: SKSpriteNode,
        tag: SKLabelNode,
        crown: SKLabelNode,
        bubble: SKSpriteNode,
        isLeading: Bool
    ) {
        container.position = CGPoint(x: CGFloat(p.x), y: CGFloat(p.y))
        let scale = CGFloat(p.radius / 18.0)
        let dirSign: CGFloat = p.facingRight ? 1.0 : -1.0
        sprite.xScale = scale * dirSign
        sprite.yScale = scale

        // Invulnerability blink
        if p.invuln > 0 {
            sprite.alpha = (Int(simTime * 16) % 2 == 0) ? 0.35 : 0.95
        } else {
            sprite.alpha = 1.0
        }

        // Gentle swim tilt
        let speedRatio = CGFloat(min(1, max(-1, p.vy / 240.0)))
        sprite.zRotation = speedRatio * 0.22 * dirSign

        tag.position = CGPoint(x: 0, y: CGFloat(p.radius) + 14)
        crown.position = CGPoint(x: 0, y: CGFloat(p.radius) + 30)
        crown.isHidden = !isLeading

        bubble.isHidden = p.bubbleTimer <= 0
        if !bubble.isHidden {
            let bScale = CGFloat(p.radius / 17.0) * (1.0 + 0.05 * sin(CGFloat(simTime) * 6.0))
            bubble.setScale(bScale)
        }
    }

    private func syncEntityNodes() {
        var activeFishIDs = Set<Int>()
        for f in fishes {
            activeFishIDs.insert(f.id)
            let node: SKSpriteNode
            if let existing = fishNodes[f.id] {
                node = existing
            } else {
                let tex = f.isShark
                    ? OceanTextureFactory.shared.sharkTexture()
                    : OceanTextureFactory.shared.ambientFishTexture(kind: f.kind)
                node = SKSpriteNode(texture: tex)
                node.size = f.isShark ? CGSize(width: 156, height: 86) : CGSize(width: 56, height: 40)
                node.zPosition = f.isShark ? 10 : 6
                worldLayer.addChild(node)
                fishNodes[f.id] = node
            }

            node.position = CGPoint(x: CGFloat(f.x), y: CGFloat(f.y))
            let scale = f.isShark ? 1.0 : CGFloat(f.radius / 13.5)
            node.xScale = (f.vx >= 0 ? 1.0 : -1.0) * scale
            node.yScale = scale
        }

        for (id, node) in fishNodes where !activeFishIDs.contains(id) {
            node.removeFromParent()
            fishNodes.removeValue(forKey: id)
        }

        var activeOrbIDs = Set<Int>()
        for orb in orbs {
            activeOrbIDs.insert(orb.id)
            let node: SKSpriteNode
            if let existing = orbNodes[orb.id] {
                node = existing
            } else {
                node = SKSpriteNode(texture: OceanTextureFactory.shared.prankOrbTexture(prank: orb.prank))
                node.size = CGSize(width: 54, height: 54)
                node.zPosition = 9
                worldLayer.addChild(node)
                orbNodes[orb.id] = node
            }
            node.position = CGPoint(x: CGFloat(orb.x), y: CGFloat(orb.y))
            let pulse = 1.0 + 0.08 * sin(CGFloat(simTime) * 4.5 + CGFloat(orb.phase))
            node.setScale(pulse)
        }

        for (id, node) in orbNodes where !activeOrbIDs.contains(id) {
            node.removeFromParent()
            orbNodes.removeValue(forKey: id)
        }
    }

    private func syncWarningVisuals() {
        for n in warningNodes { n.removeFromParent() }
        warningNodes.removeAll()

        for w in warnings {
            let xPos: CGFloat = w.fromLeft ? 88 : Self.worldWidth - 88
            let container = SKNode()
            container.position = CGPoint(x: xPos, y: CGFloat(w.y))

            let pulse = 0.55 + 0.45 * sin(CGFloat(simTime) * 16.0)
            let badge = SKShapeNode(circleOfRadius: 24)
            badge.fillColor = UIColor(red: 0.95, green: 0.14, blue: 0.18, alpha: 0.32 + 0.35 * pulse)
            badge.strokeColor = UIColor(red: 1.0, green: 0.32, blue: 0.32, alpha: 0.95)
            badge.lineWidth = 2.5
            container.addChild(badge)

            let label = SKLabelNode(text: "⚠️")
            label.fontSize = 22
            label.verticalAlignmentMode = .center
            container.addChild(label)

            warningLayer.addChild(container)
            warningNodes.append(container)
        }
    }

    private func spawnWaterRipple(at pos: CGPoint, color: UIColor) {
        let ring = SKShapeNode(circleOfRadius: 10)
        ring.position = pos
        ring.fillColor = .clear
        ring.strokeColor = color
        ring.lineWidth = 2.5
        fxLayer.addChild(ring)

        let group = SKAction.group([
            SKAction.scale(to: 3.0, duration: 0.34),
            SKAction.fadeOut(withDuration: 0.34)
        ])
        ring.run(SKAction.sequence([group, SKAction.removeFromParent()]))
    }

    private func emitTinyBubble(at pos: CGPoint) {
        let b = SKShapeNode(circleOfRadius: CGFloat.random(in: 2.0...4.0))
        b.position = pos
        b.fillColor = UIColor.white.withAlphaComponent(0.28)
        b.strokeColor = .clear
        fxLayer.addChild(b)

        let move = SKAction.moveBy(x: CGFloat.random(in: -10...10), y: 26, duration: 0.65)
        let fade = SKAction.fadeOut(withDuration: 0.65)
        b.run(SKAction.sequence([SKAction.group([move, fade]), SKAction.removeFromParent()]))
    }

    private func emitHud() {
        let localPlayer = isGuestClient ? p2 : p1
        let hud = HudState(
            scoreP1: p1.score,
            scoreP2: p2.score,
            levelP1: p1.level,
            levelP2: p2.level,
            livesP1: p1.lives,
            livesP2: p2.lives,
            dashCooldownLocal: localPlayer.dashCooldown,
            timeRemaining: roundTimeRemaining,
            inkTimerLocal: localPlayer.inkTimer,
            invertTimerLocal: localPlayer.invertTimer,
            bubbleTimerLocal: localPlayer.bubbleTimer,
            sharkProximityLocal: computeSharkProximity(for: localPlayer),
            bannerText: bannerText,
            bannerEmoji: bannerEmoji
        )
        onHudUpdate?(hud)
    }
}
