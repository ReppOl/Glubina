import Foundation
import SwiftUI

enum MapTheme: String, Codable, CaseIterable, Identifiable {
    case lagoon
    case deep

    var id: String { rawValue }

    var title: String {
        switch self {
        case .lagoon: return "Лагуна"
        case .deep: return "Глубина"
        }
    }

    var icon: String {
        switch self {
        case .lagoon: return "sun.max.fill"
        case .deep: return "water.waves"
        }
    }

    var accentColor: Color {
        switch self {
        case .lagoon: return Color(red: 0.22, green: 0.85, blue: 0.96)
        case .deep: return Color(red: 0.25, green: 0.56, blue: 1.0)
        }
    }
}

enum GameMode: String, Codable, CaseIterable, Identifiable {
    case solo
    case multiplayer

    var id: String { rawValue }

    var title: String {
        switch self {
        case .solo: return "1 Игрок"
        case .multiplayer: return "Вдвоём"
        }
    }
}

enum PrankType: String, Codable, CaseIterable {
    case ink
    case invert
    case shark
    case bubble

    var emoji: String {
        switch self {
        case .ink: return "🐙"
        case .invert: return "🔄"
        case .shark: return "🦈"
        case .bubble: return "🫧"
        }
    }

    var title: String {
        switch self {
        case .ink: return "Чернила осьминога!"
        case .invert: return "Перевёртыш!"
        case .shark: return "Приманка акулы!"
        case .bubble: return "Мыльный пузырь!"
        }
    }
}

enum GamePhase: Equatable {
    case menu
    case playing
    case roundOver
}

enum GameEventType: String, Codable {
    case bite
    case sharkWarning
    case dash
    case levelUp
    case prankInk
    case prankInvert
    case prankShark
    case prankBubble
    case bubblePop
    case hurt
}

struct GameEventPacket: Codable {
    let type: GameEventType
    /// 0 = P1 (Host), 1 = P2 (Guest / Bot), 2 = Both
    let targetPlayer: Int
}

struct PlayerInputPacket: Codable {
    var dx: Float
    var dy: Float
    var dashPressed: Bool
}

struct PlayerSyncState: Codable {
    var x: Float
    var y: Float
    var facingRight: Bool
    var score: Int
    var level: Int
    var lives: Int
    var dashCooldown: Float
    var invuln: Float
    var inkTimer: Float
    var invertTimer: Float
    var bubbleTimer: Float
    var isDashing: Bool
    var pranksUsed: Int
    var bites: Int
}

struct FishSyncState: Codable {
    var id: Int
    var x: Float
    var y: Float
    var vx: Float
    var vy: Float
    var radius: Float
    var kind: UInt8
    var isShark: Bool
    var facingRight: Bool
    var isChasing: Bool
}

struct OrbSyncState: Codable {
    var id: Int
    var x: Float
    var y: Float
    var prank: PrankType
}

struct WarningSyncState: Codable {
    var y: Float
    var fromLeft: Bool
    var progress: Float
}

struct WorldSnapshot: Codable {
    var p1: PlayerSyncState
    var p2: PlayerSyncState
    var fish: [FishSyncState]
    var orbs: [OrbSyncState]
    var warnings: [WarningSyncState]
    var timeRemaining: Float
    var map: MapTheme
}

struct RoundResult: Codable, Equatable {
    let scoreP1: Int
    let scoreP2: Int
    let levelP1: Int
    let levelP2: Int
    let titleP1: String
    let titleP2: String
    /// 0 = P1 wins, 1 = P2 wins, -1 = Draw
    let winnerIndex: Int
    let seriesP1: Int
    let seriesP2: Int
}

enum NetworkMessage: Codable {
    case startMatch(map: MapTheme, seriesP1: Int, seriesP2: Int)
    case input(PlayerInputPacket)
    case snapshot(WorldSnapshot)
    case event(GameEventPacket)
    case roundOver(RoundResult)
    case returnToMenu
}

struct HudState {
    var scoreP1: Int = 0
    var scoreP2: Int = 0
    var levelP1: Int = 1
    var levelP2: Int = 1
    var livesP1: Int = 3
    var livesP2: Int = 3
    var dashCooldownLocal: Float = 0
    var timeRemaining: Float = 90
    var inkTimerLocal: Float = 0
    var invertTimerLocal: Float = 0
    var bubbleTimerLocal: Float = 0
    var sharkProximityLocal: Float = 0
    var bannerText: String? = nil
    var bannerEmoji: String? = nil
}

struct TitleGenerator {
    static func pickTitle(score: Int, level: Int, lives: Int, pranks: Int, won: Bool) -> String {
        if pranks >= 3 { return "Король пакостей" }
        if lives == 0 { return "Ужин акулы" }
        if won && score >= 45 { return "Пылесос океана" }
        if won && level >= 5 { return "Владыка лагуны" }
        if won { return "Гроза планктона" }
        if pranks >= 2 { return "Морской хитрец" }
        if score >= 25 { return "Ловкий малёк" }
        return "Мирный дайвер"
    }
}
