import Foundation
import CoreHaptics
import QuartzCore
import UIKit

final class HapticManager {
    static let shared = HapticManager()

    var isEnabled: Bool = true
    private var engine: CHHapticEngine?
    private var supportsHaptics: Bool = false
    private var lastHeartbeatTime: TimeInterval = 0
    private var lastClickTime: TimeInterval = 0

    private let lightImpact = UIImpactFeedbackGenerator(style: .light)
    private let mediumImpact = UIImpactFeedbackGenerator(style: .medium)
    private let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)

    private init() {
        supportsHaptics = CHHapticEngine.capabilitiesForHardware().supportsHaptics
        prepare()
    }

    func prepare() {
        lightImpact.prepare()
        mediumImpact.prepare()
        heavyImpact.prepare()

        guard supportsHaptics else { return }
        do {
            let newEngine = try CHHapticEngine()
            newEngine.isAutoShutdownEnabled = true
            newEngine.stoppedHandler = { [weak self] _ in
                self?.restartEngineIfNeeded()
            }
            newEngine.resetHandler = { [weak self] in
                self?.restartEngineIfNeeded()
            }
            try newEngine.start()
            engine = newEngine
        } catch {
            engine = nil
        }
    }

    private func restartEngineIfNeeded() {
        guard supportsHaptics else { return }
        DispatchQueue.main.async { [weak self] in
            do {
                try self?.engine?.start()
            } catch {
                self?.prepare()
            }
        }
    }

    private func playPattern(_ events: [CHHapticEvent], curves: [CHHapticParameterCurve] = []) {
        guard isEnabled else { return }
        guard supportsHaptics else { return }

        if engine == nil {
            prepare()
        }
        guard let engine = engine else { return }

        do {
            try engine.start()
            let pattern = try CHHapticPattern(events: events, parameterCurves: curves)
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: CHHapticTimeImmediate)
        } catch {
            // Silently ignore if app is transitioning to background
        }
    }

    /// Subtle crisp keyboard-like click when eating a fish
    func playBite() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.45)
            return
        }
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.44)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.90)
        let event = CHHapticEvent(eventType: .hapticTransient, parameters: [intensity, sharpness], relativeTime: 0)
        playPattern([event])
    }

    /// Distant low rumble swelling and fading when a shark appears on the horizon
    func playSharkWarning() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.5)
            return
        }
        let baseIntensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.55)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.14)
        let rumble = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [baseIntensity, sharpness],
            relativeTime: 0,
            duration: 0.72
        )
        let curve = CHHapticParameterCurve(
            parameterID: .hapticIntensityControl,
            controlPoints: [
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.0, value: 0.12),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.35, value: 0.78),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.72, value: 0.05)
            ],
            relativeTime: 0
        )
        playPattern([rumble], curves: [curve])
    }

    /// Subtle underwater heartbeat (lub-dub) as a shark gets close
    func playSharkHeartbeat(proximity: Float) {
        guard isEnabled, proximity > 0.12 else { return }
        let now = CACurrentMediaTime()
        let interval = Double(max(0.48, 1.05 - proximity * 0.55))
        guard now - lastHeartbeatTime >= interval else { return }
        lastHeartbeatTime = now

        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: CGFloat(min(1.0, 0.25 + proximity * 0.5)))
            return
        }

        let level = min(0.70, 0.20 + proximity * 0.48)
        let beat1 = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: level),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.20)
            ],
            relativeTime: 0.0
        )
        let beat2 = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: level * 0.72),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.16)
            ],
            relativeTime: 0.15
        )
        playPattern([beat1, beat2])
    }

    /// Snappy double impulse with smooth water swoosh tail for Dash
    func playDash() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.75)
            return
        }
        let punch = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.75),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.65)
            ],
            relativeTime: 0.0
        )
        let tail = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.35),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.30)
            ],
            relativeTime: 0.04,
            duration: 0.14
        )
        playPattern([punch, tail])
    }

    /// Ascending 3-tap chime on level up
    func playLevelUp() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.8)
            return
        }
        let events = [
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.45),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.50)
            ], relativeTime: 0.0),
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.68),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.72)
            ], relativeTime: 0.09),
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.92),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.92)
            ], relativeTime: 0.18)
        ]
        playPattern(events)
    }

    /// Playful rapid trill when sending a prank
    func playPrankSent() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.7)
            return
        }
        var events: [CHHapticEvent] = []
        for i in 0..<4 {
            let t = TimeInterval(i) * 0.055
            events.append(CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.52 + Float(i) * 0.08),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.80)
                ],
                relativeTime: t
            ))
        }
        playPattern(events)
    }

    /// Tense double buzz when hit by opponent's prank
    func playPrankReceived() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 0.85)
            return
        }
        let buzz1 = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.75),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.42)
            ],
            relativeTime: 0.0,
            duration: 0.12
        )
        let buzz2 = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.85),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.35)
            ],
            relativeTime: 0.17,
            duration: 0.16
        )
        playPattern([buzz1, buzz2])
    }

    /// Crisp high-sharpness pop when soap bubble bursts
    func playBubblePop() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.65)
            return
        }
        let pop = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.62),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.98)
            ],
            relativeTime: 0.0
        )
        playPattern([pop])
    }

    /// Deep heavy thud when bitten by a shark
    func playHurt() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 1.0)
            return
        }
        let hit = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.25)
            ],
            relativeTime: 0.0
        )
        let shake = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.80),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.14)
            ],
            relativeTime: 0.02,
            duration: 0.24
        )
        playPattern([hit, shake])
    }

    /// Ultra-light crisp UI/D-Pad feedback
    func playUIClick() {
        guard isEnabled else { return }
        let now = CACurrentMediaTime()
        guard now - lastClickTime > 0.045 else { return }
        lastClickTime = now

        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.3)
            return
        }
        let tap = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.28),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.85)
            ],
            relativeTime: 0
        )
        playPattern([tap])
    }
}
