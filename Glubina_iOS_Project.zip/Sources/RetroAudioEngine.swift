import Foundation
import AVFoundation
import os

enum RetroSFXKind: Int {
    case bite = 0
    case dash = 1
    case sharkWarning = 2
    case levelUp = 3
    case prank = 4
    case bubblePop = 5
    case hurt = 6
    case uiClick = 7
}

private struct SFXVoice {
    var active: Bool = false
    var kind: RetroSFXKind = .bite
    var time: Double = 0
    var duration: Double = 0.2
    var phase: Double = 0
    var phase2: Double = 0
}

/// Real-time 16-bit hypnotic underwater synthesizer & retro SFX mixer.
/// 100% procedural (zero external audio files needed) using AVAudioEngine + AVAudioSourceNode.
final class RetroAudioEngine {
    static let shared = RetroAudioEngine()

    private let engine = AVAudioEngine()
    private var sourceNode: AVAudioSourceNode?
    private let sampleRate: Double = 44100.0
    private var isStarted: Bool = false

    // Thread-safe lock for parameters & SFX triggers
    private let lockPtr: UnsafeMutablePointer<os_unfair_lock>

    // Audio state owned by DSP
    private var musicEnabledState: Bool = true
    private var sfxEnabledState: Bool = true
    private var isLagoonMap: Bool = true

    // Music synthesizer state (D Dorian hypnotic aquatic ambience)
    private var musicTime: Double = 0
    private var stepIndex: Int = 0
    private var stepTimer: Double = 0
    private var chordIndex: Int = 0
    private var chordTimer: Double = 0

    // Oscillator phases for pad (4 voices), bass, FM arp
    private var padPhases: [Double] = [0, 0, 0, 0]
    private var padDetunePhases: [Double] = [0, 0, 0, 0]
    private var bassPhase: Double = 0
    private var arpCarrierPhase: Double = 0
    private var arpModPhase: Double = 0
    private var arpFreq: Double = 293.66
    private var arpEnv: Double = 0
    private var bassFreq: Double = 73.42
    private var bassEnv: Double = 0
    private var sparklePhase: Double = 0
    private var sparkleFreq: Double = 1174.66
    private var sparkleEnv: Double = 0

    // Lowpass state for dreamy underwater warmth
    private var lpLeft: Double = 0
    private var lpRight: Double = 0

    // Stereo ping-pong delay buffer (~0.42s and ~0.56s)
    private let delayLenL: Int = 18522
    private let delayLenR: Int = 24696
    private var delayBufL: [Float]
    private var delayBufR: [Float]
    private var delayIdxL: Int = 0
    private var delayIdxR: Int = 0

    // Noise generator seed
    private var rngState: UInt32 = 0x1234ABCD

    // SFX polyphony (8 fixed slots, owned exclusively by audio render thread)
    private var sfxVoices: [SFXVoice] = Array(repeating: SFXVoice(), count: 8)
    private var pendingSFXQueue: [RetroSFXKind] = []

    // D Dorian chord progression (Hz): Dm9 -> G13 -> Am7 -> Cmaj7
    private let chords: [[Double]] = [
        [146.83, 174.61, 220.00, 329.63], // D3, F3, A3, E4
        [196.00, 246.94, 293.66, 329.63], // G3, B3, D4, E4
        [220.00, 261.63, 329.63, 392.00], // A3, C4, E4, G4
        [130.81, 196.00, 246.94, 329.63]  // C3, G3, B3, E4
    ]
    private let bassRoots: [Double] = [73.42, 98.00, 110.00, 65.41]

    // Hypnotic 16-step arpeggio scale degrees in D Dorian
    private let arpNotes: [[Double]] = [
        [293.66, 440.00, 523.25, 659.25, 587.33, 440.00, 349.23, 523.25],
        [392.00, 493.88, 587.33, 659.25, 587.33, 493.88, 392.00, 440.00],
        [440.00, 523.25, 659.25, 783.99, 659.25, 523.25, 440.00, 392.00],
        [261.63, 392.00, 493.88, 659.25, 587.33, 493.88, 392.00, 329.63]
    ]

    var isMusicEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = musicEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            musicEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    var isSFXEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = sfxEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            sfxEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    private init() {
        lockPtr = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1)
        lockPtr.initialize(to: os_unfair_lock())
        delayBufL = Array(repeating: 0, count: delayLenL)
        delayBufR = Array(repeating: 0, count: delayLenR)
    }

    deinit {
        engine.stop()
        lockPtr.deinitialize(count: 1)
        lockPtr.deallocate()
    }

    func setMap(_ map: MapTheme) {
        os_unfair_lock_lock(lockPtr)
        isLagoonMap = (map == .lagoon)
        os_unfair_lock_unlock(lockPtr)
    }

    func start() {
        if isStarted {
            if !engine.isRunning {
                try? engine.start()
            }
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {
            // Continue even if session setup fails in simulator
        }

        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2) else { return }

        let node = AVAudioSourceNode(format: format) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            let ablPointer = UnsafeMutableAudioBufferListPointer(audioBufferList)
            let frames = Int(frameCount)
            self.renderAudio(ablPointer: ablPointer, frames: frames)
            return noErr
        }

        sourceNode = node
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: format)
        engine.mainMixerNode.outputVolume = 0.85

        do {
            try engine.start()
            isStarted = true
        } catch {
            isStarted = false
        }
    }

    func playSFX(_ kind: RetroSFXKind) {
        if !isStarted { start() }
        os_unfair_lock_lock(lockPtr)
        if sfxEnabledState && pendingSFXQueue.count < 8 {
            pendingSFXQueue.append(kind)
        }
        os_unfair_lock_unlock(lockPtr)
    }

    private func triggerVoiceOnAudioThread(_ kind: RetroSFXKind) {
        var slot = 0
        var oldestTime: Double = -1
        for i in 0..<sfxVoices.count {
            if !sfxVoices[i].active {
                slot = i
                break
            }
            if sfxVoices[i].time > oldestTime {
                oldestTime = sfxVoices[i].time
                slot = i
            }
        }
        var v = SFXVoice()
        v.active = true
        v.kind = kind
        v.time = 0
        v.phase = 0
        v.phase2 = 0
        switch kind {
        case .bite: v.duration = 0.13
        case .dash: v.duration = 0.24
        case .sharkWarning: v.duration = 0.85
        case .levelUp: v.duration = 0.52
        case .prank: v.duration = 0.42
        case .bubblePop: v.duration = 0.14
        case .hurt: v.duration = 0.36
        case .uiClick: v.duration = 0.06
        }
        sfxVoices[slot] = v
    }

    @inline(__always)
    private func nextNoise() -> Double {
        rngState = rngState &* 1664525 &+ 1013904223
        let norm = Double(rngState & 0xFFFF) / 32768.0 - 1.0
        return norm
    }

    private func renderAudio(ablPointer: UnsafeMutableAudioBufferListPointer, frames: Int) {
        guard ablPointer.count >= 1 else { return }
        let leftBuf = ablPointer[0].mData?.assumingMemoryBound(to: Float.self)
        let rightBuf = ablPointer.count > 1 ? ablPointer[1].mData?.assumingMemoryBound(to: Float.self) : nil

        os_unfair_lock_lock(lockPtr)
        let playMusic = musicEnabledState
        let playSfx = sfxEnabledState
        let lagoon = isLagoonMap
        let queuedCount = pendingSFXQueue.count
        var localQueue: (RetroSFXKind?, RetroSFXKind?, RetroSFXKind?, RetroSFXKind?) = (nil, nil, nil, nil)
        if queuedCount > 0 {
            if queuedCount >= 1 { localQueue.0 = pendingSFXQueue[0] }
            if queuedCount >= 2 { localQueue.1 = pendingSFXQueue[1] }
            if queuedCount >= 3 { localQueue.2 = pendingSFXQueue[2] }
            if queuedCount >= 4 { localQueue.3 = pendingSFXQueue[3] }
            pendingSFXQueue.removeAll(keepingCapacity: true)
        }
        os_unfair_lock_unlock(lockPtr)

        if playSfx {
            if let q0 = localQueue.0 { triggerVoiceOnAudioThread(q0) }
            if let q1 = localQueue.1 { triggerVoiceOnAudioThread(q1) }
            if let q2 = localQueue.2 { triggerVoiceOnAudioThread(q2) }
            if let q3 = localQueue.3 { triggerVoiceOnAudioThread(q3) }
        }

        let dt = 1.0 / sampleRate
        let twoPi = Double.pi * 2.0
        let stepDur: Double = lagoon ? 0.34 : 0.40
        let chordDur: Double = stepDur * 16.0

        for i in 0..<frames {
            var outL: Double = 0
            var outR: Double = 0

            // --- 1. HYPNOTIC 16-BIT UNDERWATER MUSIC ---
            if playMusic {
                musicTime += dt
                stepTimer += dt
                chordTimer += dt

                if chordTimer >= chordDur {
                    chordTimer -= chordDur
                    chordIndex = (chordIndex + 1) % chords.count
                    bassFreq = bassRoots[chordIndex]
                    bassEnv = 1.0
                }

                if stepTimer >= stepDur {
                    stepTimer -= stepDur
                    let pattern = arpNotes[chordIndex]
                    let noteIdx = stepIndex % pattern.count
                    // Rest on some beats for hypnotic breathing space
                    if stepIndex % 8 != 7 {
                        arpFreq = pattern[noteIdx] * (lagoon ? 1.0 : 0.5)
                        if !lagoon { arpFreq *= 2.0 }
                        arpEnv = 1.0
                    }
                    if stepIndex % 4 == 0 {
                        bassFreq = bassRoots[chordIndex]
                        bassEnv = 0.85
                    }
                    if stepIndex % 11 == 3 {
                        sparkleFreq = pattern[(noteIdx + 2) % pattern.count] * 2.0
                        sparkleEnv = lagoon ? 0.65 : 0.42
                    }
                    stepIndex = (stepIndex + 1) % 16
                }

                // Breathing pad (4 gentle detuned voices)
                let chord = chords[chordIndex]
                let breath = 0.65 + 0.35 * sin(musicTime * 0.42)
                var padL: Double = 0
                var padR: Double = 0
                for v in 0..<4 {
                    let f = chord[v]
                    padPhases[v] += twoPi * f * dt
                    if padPhases[v] > twoPi { padPhases[v] -= twoPi }
                    padDetunePhases[v] += twoPi * (f * 1.0035) * dt
                    if padDetunePhases[v] > twoPi { padDetunePhases[v] -= twoPi }

                    let s1 = sin(padPhases[v]) * 0.7 + sin(padPhases[v] * 2.0) * 0.16
                    let s2 = sin(padDetunePhases[v]) * 0.7
                    if v % 2 == 0 {
                        padL += s1 * 0.65 + s2 * 0.35
                        padR += s2 * 0.65 + s1 * 0.35
                    } else {
                        padL += s2 * 0.65 + s1 * 0.35
                        padR += s1 * 0.65 + s2 * 0.35
                    }
                }
                padL *= 0.048 * breath
                padR *= 0.048 * breath

                // Deep warm bass
                bassPhase += twoPi * bassFreq * dt
                if bassPhase > twoPi { bassPhase -= twoPi }
                bassEnv *= 0.99993
                let bassSample = (sin(bassPhase) * 0.85 + sin(bassPhase * 2.0) * 0.15) * bassEnv * 0.11

                // 16-bit crystal FM arpeggio bell
                arpEnv *= 0.99982
                arpModPhase += twoPi * (arpFreq * 2.0) * dt
                if arpModPhase > twoPi { arpModPhase -= twoPi }
                let modIndex = (lagoon ? 1.8 : 1.15) * arpEnv
                arpCarrierPhase += twoPi * arpFreq * dt
                if arpCarrierPhase > twoPi { arpCarrierPhase -= twoPi }
                let arpRaw = sin(arpCarrierPhase + sin(arpModPhase) * modIndex) * arpEnv * 0.095

                // Subtle water-drop bell shimmer
                sparkleEnv *= 0.99972
                sparklePhase += twoPi * sparkleFreq * dt
                if sparklePhase > twoPi { sparklePhase -= twoPi }
                let sparkle = sin(sparklePhase) * sparkleEnv * 0.04

                // Stereo ping-pong delay on arp + sparkle
                let dL = Double(delayBufL[delayIdxL])
                let dR = Double(delayBufR[delayIdxR])
                let pan = 0.5 + 0.45 * sin(musicTime * 0.7)
                let wetInL = arpRaw * pan + sparkle * (1.0 - pan)
                let wetInR = arpRaw * (1.0 - pan) + sparkle * pan

                delayBufL[delayIdxL] = Float(wetInL + dR * 0.46)
                delayBufR[delayIdxR] = Float(wetInR + dL * 0.46)
                delayIdxL = (delayIdxL + 1) % delayLenL
                delayIdxR = (delayIdxR + 1) % delayLenR

                let rawMusicL = padL + bassSample + wetInL + dL * 0.55
                let rawMusicR = padR + bassSample + wetInR + dR * 0.55

                // Gentle resonant underwater lowpass filter
                let cutoff = lagoon ? (0.24 + 0.08 * sin(musicTime * 0.35)) : (0.14 + 0.06 * sin(musicTime * 0.28))
                lpLeft += (rawMusicL - lpLeft) * cutoff
                lpRight += (rawMusicR - lpRight) * cutoff

                outL += lpLeft
                outR += lpRight
            }

            // --- 2. PROCEDURAL RETRO SFX (100% lock-free) ---
            if playSfx {
                for idx in 0..<sfxVoices.count {
                    guard sfxVoices[idx].active else { continue }
                    var v = sfxVoices[idx]
                    let t = v.time
                    let p = t / v.duration
                    if p >= 1.0 {
                        v.active = false
                        sfxVoices[idx] = v
                        continue
                    }

                    var s: Double = 0
                    switch v.kind {
                    case .bite:
                        // Crisp water click + cheerful rising retro blip
                        let freq = 420.0 + p * 680.0
                        v.phase += twoPi * freq * dt
                        let env = (1.0 - p) * (1.0 - p)
                        let click = t < 0.012 ? nextNoise() * 0.35 : 0.0
                        s = (sin(v.phase) * 0.65 + (sin(v.phase) > 0 ? 0.2 : -0.2)) * env * 0.26 + click * 0.25

                    case .dash:
                        // Fast water swoosh
                        let freq = 260.0 + (1.0 - p) * 320.0
                        v.phase += twoPi * freq * dt
                        let env = sin(p * Double.pi)
                        s = (nextNoise() * 0.45 + sin(v.phase) * 0.35) * env * 0.22

                    case .sharkWarning:
                        // Deep haunting submarine sonar ping
                        let freq = 196.0 - p * 18.0
                        v.phase += twoPi * freq * dt
                        v.phase2 += twoPi * (freq * 2.01) * dt
                        let env = exp(-p * 3.8)
                        s = (sin(v.phase) * 0.8 + sin(v.phase2) * 0.25) * env * 0.28

                    case .levelUp:
                        // Classic 16-bit ascending arpeggio
                        let notes: [Double] = [523.25, 659.25, 783.99, 1046.50]
                        let nIdx = min(3, Int(p * 4.0))
                        let localP = (p * 4.0) - Double(nIdx)
                        v.phase += twoPi * notes[nIdx] * dt
                        let env = (1.0 - localP * 0.65) * (1.0 - p * 0.2)
                        let sq = sin(v.phase) > 0 ? 0.5 : -0.5
                        s = (sin(v.phase) * 0.65 + sq * 0.35) * env * 0.22

                    case .prank:
                        // Playful warbling FM slide
                        let lfo = sin(t * 42.0) * 95.0
                        let freq = 620.0 - p * 260.0 + lfo
                        v.phase += twoPi * max(80, freq) * dt
                        let env = (1.0 - p)
                        s = sin(v.phase) * env * 0.24

                    case .bubblePop:
                        // Rapid upward bubble pop
                        let freq = 300.0 + p * p * 1450.0
                        v.phase += twoPi * freq * dt
                        let env = sin(p * Double.pi)
                        s = sin(v.phase) * env * 0.28

                    case .hurt:
                        // Crunchy retro low descending hit
                        let freq = 180.0 - p * 125.0
                        v.phase += twoPi * max(40, freq) * dt
                        let env = (1.0 - p)
                        let buzz = sin(v.phase) > 0 ? 0.7 : -0.7
                        s = (buzz * 0.65 + nextNoise() * 0.35) * env * 0.30

                    case .uiClick:
                        let freq = 760.0
                        v.phase += twoPi * freq * dt
                        let env = (1.0 - p) * (1.0 - p)
                        s = sin(v.phase) * env * 0.14
                    }

                    outL += s
                    outR += s
                    v.time += dt
                    sfxVoices[idx] = v
                }
            }

            // Soft limiter to guarantee zero digital clipping
            let clampedL = Float(tanh(outL))
            let clampedR = Float(tanh(outR))
            leftBuf?[i] = clampedL
            rightBuf?[i] = clampedR
        }
    }
}
