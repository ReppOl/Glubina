import Foundation
import MultipeerConnectivity
import UIKit

enum PeerRole: Equatable {
    case none
    case host
    case guest
}

final class MultipeerManager: NSObject, ObservableObject {
    static let serviceType = "glubina-mp"

    @Published var role: PeerRole = .none
    @Published var isSearching: Bool = false
    @Published var discoveredPeers: [MCPeerID] = []
    @Published var connectedPeer: MCPeerID? = nil
    @Published var statusText: String = "Не подключено"

    var onReceiveMessage: ((NetworkMessage) -> Void)?
    var onDisconnect: (() -> Void)?

    private let myPeerID: MCPeerID
    private var session: MCSession?
    private var advertiser: MCNearbyServiceAdvertiser?
    private var browser: MCNearbyServiceBrowser?

    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    override init() {
        let name = UIDevice.current.name
        self.myPeerID = MCPeerID(displayName: name)
        super.init()
    }

    var isConnected: Bool {
        connectedPeer != nil
    }

    func startHosting() {
        stopAll()
        role = .host
        isSearching = true
        statusText = "Ждём подключения второго iPhone..."

        let newSession = MCSession(peer: myPeerID, securityIdentity: nil, encryptionPreference: .none)
        newSession.delegate = self
        session = newSession

        let adv = MCNearbyServiceAdvertiser(peer: myPeerID, discoveryInfo: nil, serviceType: Self.serviceType)
        adv.delegate = self
        adv.startAdvertisingPeer()
        advertiser = adv
    }

    func startBrowsing() {
        stopAll()
        role = .guest
        isSearching = true
        statusText = "Ищем комнату рядом..."

        let newSession = MCSession(peer: myPeerID, securityIdentity: nil, encryptionPreference: .none)
        newSession.delegate = self
        session = newSession

        let br = MCNearbyServiceBrowser(peer: myPeerID, serviceType: Self.serviceType)
        br.delegate = self
        br.startBrowsingForPeers()
        browser = br
    }

    func invite(peer: MCPeerID) {
        guard let browser = browser, let session = session else { return }
        statusText = "Подключаемся к \(peer.displayName)..."
        browser.invitePeer(peer, to: session, withContext: nil, timeout: 15)
    }

    func stopAll() {
        advertiser?.stopAdvertisingPeer()
        advertiser = nil
        browser?.stopBrowsingForPeers()
        browser = nil
        session?.disconnect()
        session = nil

        DispatchQueue.main.async {
            self.role = .none
            self.isSearching = false
            self.discoveredPeers = []
            self.connectedPeer = nil
            self.statusText = "Не подключено"
        }
    }

    func send(_ message: NetworkMessage, reliable: Bool) {
        guard let session = session, !session.connectedPeers.isEmpty else { return }
        do {
            let data = try encoder.encode(message)
            try session.send(data, toPeers: session.connectedPeers, with: reliable ? .reliable : .unreliable)
        } catch {
            // Unreliable packets may occasionally drop safely
        }
    }
}

extension MultipeerManager: MCSessionDelegate {
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .connected:
                self.connectedPeer = peerID
                self.isSearching = false
                self.advertiser?.stopAdvertisingPeer()
                self.browser?.stopBrowsingForPeers()
                self.statusText = "Подключено: \(peerID.displayName)"
                HapticManager.shared.playLevelUp()

            case .connecting:
                self.statusText = "Соединение с \(peerID.displayName)..."

            case .notConnected:
                let wasConnected = (self.connectedPeer == peerID)
                if wasConnected {
                    self.connectedPeer = nil
                    self.statusText = "Связь прервана"
                    self.onDisconnect?()
                }

            @unknown default:
                break
            }
        }
    }

    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        guard let msg = try? decoder.decode(NetworkMessage.self, from: data) else { return }
        DispatchQueue.main.async { [weak self] in
            self?.onReceiveMessage?(msg)
        }
    }

    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {}
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {}
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?) {}
}

extension MultipeerManager: MCNearbyServiceAdvertiserDelegate {
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        // Auto-accept partner's invitation for effortless 1-tap pairing
        invitationHandler(true, session)
    }

    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: Error) {
        DispatchQueue.main.async {
            self.statusText = "Проверь доступ к Bluetooth / Wi-Fi"
            self.isSearching = false
        }
    }
}

extension MultipeerManager: MCNearbyServiceBrowserDelegate {
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
        DispatchQueue.main.async {
            if !self.discoveredPeers.contains(peerID) {
                self.discoveredPeers.append(peerID)
            }
        }
    }

    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
        DispatchQueue.main.async {
            self.discoveredPeers.removeAll { $0 == peerID }
        }
    }

    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: Error) {
        DispatchQueue.main.async {
            self.statusText = "Проверь доступ к Bluetooth / Wi-Fi"
            self.isSearching = false
        }
    }
}
