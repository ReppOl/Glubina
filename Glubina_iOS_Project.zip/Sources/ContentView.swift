import SwiftUI
import SpriteKit
import MultipeerConnectivity

// MARK: - Game Coordinator (Owns Scene, Multipeer & Persistent Series State)

final class GameCoordinator: ObservableObject {
    @Published var phase: GamePhase = .menu
    @Published var selectedMap: MapTheme = .lagoon {
        didSet {
            scene.setMap(selectedMap)
        }
    }
    @Published var selectedMode: GameMode = .solo
    @Published var hud = HudState()
    @Published var roundResult: RoundResult? = nil
    @Published var dpadVisual = DPadVisualState()

    @Published var musicEnabled: Bool = true {
        didSet { RetroAudioEngine.shared.isMusicEnabled = musicEnabled }
    }
    @Published var sfxEnabled: Bool = true {
        didSet { RetroAudioEngine.shared.isSFXEnabled = sfxEnabled }
    }
    @Published var hapticsEnabled: Bool = true {
        didSet { HapticManager.shared.isEnabled = hapticsEnabled }
    }

    @Published var showPairingSheet: Bool = false
    @Published var seriesP1: Int = UserDefaults.standard.integer(forKey: "glubina_series_p1")
    @Published var seriesP2: Int = UserDefaults.standard.integer(forKey: "glubina_series_p2")

    let multipeer = MultipeerManager()
    let scene: OceanScene

    init() {
        scene = OceanScene(size: CGSize(width: OceanScene.worldWidth, height: OceanScene.worldHeight))
        wireCallbacks()
    }

    private func wireCallbacks() {
        scene.onHudUpdate = { [weak self] newHud in
            DispatchQueue.main.async {
                self?.hud = newHud
            }
        }

        scene.onRoundOver = { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.seriesP1 = result.seriesP1
                self.seriesP2 = result.seriesP2
                UserDefaults.standard.set(result.seriesP1, forKey: "glubina_series_p1")
                UserDefaults.standard.set(result.seriesP2, forKey: "glubina_series_p2")
                self.roundResult = result
                self.phase = .roundOver
                if self.selectedMode == .multiplayer && self.multipeer.role == .host {
                    self.multipeer.send(.roundOver(result), reliable: true)
                }
            }
        }

        scene.onSendSnapshot = { [weak self] snap in
            self?.multipeer.send(.snapshot(snap), reliable: false)
        }

        scene.onSendEvent = { [weak self] ev in
            self?.multipeer.send(.event(ev), reliable: true)
        }

        scene.onSendGuestInput = { [weak self] input in
            self?.multipeer.send(.input(input), reliable: false)
        }

        multipeer.onReceiveMessage = { [weak self] message in
            guard let self = self else { return }
            switch message {
            case .startMatch(let map, let s1, let s2):
                self.selectedMode = .multiplayer
                self.selectedMap = map
                self.seriesP1 = s1
                self.seriesP2 = s2
                self.showPairingSheet = false
                self.roundResult = nil
                self.phase = .playing
                RetroAudioEngine.shared.start()
                self.scene.startMatch(mode: .multiplayer, map: map, isGuest: true, seriesP1: s1, seriesP2: s2)

            case .input(let packet):
                self.scene.receiveGuestInput(packet)

            case .snapshot(let snap):
                self.scene.receiveSnapshot(snap)

            case .event(let ev):
                self.scene.receiveNetworkEvent(ev)

            case .roundOver(let res):
                self.seriesP1 = res.seriesP1
                self.seriesP2 = res.seriesP2
                self.roundResult = res
                self.phase = .roundOver

            case .returnToMenu:
                self.goToMenuLocal()
            }
        }

        multipeer.onDisconnect = { [weak self] in
            guard let self = self else { return }
            if self.phase != .menu {
                self.goToMenuLocal()
            }
        }
    }

    func startPressed() {
        HapticManager.shared.playUIClick()
        RetroAudioEngine.shared.start()

        if selectedMode == .multiplayer && !multipeer.isConnected {
            showPairingSheet = true
            return
        }

        if selectedMode == .multiplayer && multipeer.role == .guest {
            // Guest waits for Host to launch (or opens pairing status)
            showPairingSheet = true
            return
        }

        launchMatchAsHostOrSolo()
    }

    func launchMatchAsHostOrSolo() {
        roundResult = nil
        showPairingSheet = false
        phase = .playing
        RetroAudioEngine.shared.start()

        if selectedMode == .multiplayer {
            multipeer.send(.startMatch(map: selectedMap, seriesP1: seriesP1, seriesP2: seriesP2), reliable: true)
        }
        scene.startMatch(
            mode: selectedMode,
            map: selectedMap,
            isGuest: false,
            seriesP1: seriesP1,
            seriesP2: seriesP2
        )
    }

    func exitToMenu() {
        HapticManager.shared.playUIClick()
        if selectedMode == .multiplayer && multipeer.isConnected {
            multipeer.send(.returnToMenu, reliable: true)
        }
        goToMenuLocal()
    }

    private func goToMenuLocal() {
        phase = .menu
        roundResult = nil
        dpadVisual = DPadVisualState()
        scene.returnToMenu()
    }

    func resetSeries() {
        HapticManager.shared.playUIClick()
        seriesP1 = 0
        seriesP2 = 0
        UserDefaults.standard.set(0, forKey: "glubina_series_p1")
        UserDefaults.standard.set(0, forKey: "glubina_series_p2")
    }
}

// MARK: - Root View

struct ContentView: View {
    @StateObject private var game = GameCoordinator()

    var body: some View {
        ZStack {
            // Live animated ocean runs seamlessly behind Menu, Gameplay & Results
            SpriteView(scene: game.scene, preferredFramesPerSecond: 120)
                .ignoresSafeArea()

            if game.phase == .playing {
                GameplayOverlayView(game: game)
            } else if game.phase == .menu {
                MainMenuOverlayView(game: game)
                    .transition(.opacity.combined(with: .scale(scale: 0.97)))
            } else if game.phase == .roundOver, let result = game.roundResult {
                RoundOverOverlayView(game: game, result: result)
                    .transition(.opacity.combined(with: .scale(scale: 0.95)))
            }
        }
        .animation(.easeInOut(duration: 0.28), value: game.phase)
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .sheet(isPresented: $game.showPairingSheet) {
            MultiplayerPairingSheet(game: game, multipeer: game.multipeer)
        }
        .onAppear {
            HapticManager.shared.prepare()
            RetroAudioEngine.shared.start()
        }
    }
}

// MARK: - Clean Glassmorphic Main Menu

private struct MainMenuOverlayView: View {
    @ObservedObject var game: GameCoordinator
    @ObservedObject var multipeer: MultipeerManager

    init(game: GameCoordinator) {
        self.game = game
        self.multipeer = game.multipeer
    }

    var body: some View {
        ZStack {
            // Top-right sleek circular icon toggles
            VStack {
                HStack {
                    if multipeer.isConnected, let peer = multipeer.connectedPeer {
                        Button {
                            game.showPairingSheet = true
                        } label: {
                            HStack(spacing: 6) {
                                Circle().fill(Color.green).frame(width: 8, height: 8)
                                Text(peer.displayName)
                                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                                    .lineLimit(1)
                            }
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(.ultraThinMaterial, in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.25), lineWidth: 1))
                        }
                    }

                    Spacer()

                    HStack(spacing: 10) {
                        CircleIconToggle(icon: game.musicEnabled ? "music.note" : "music.note.list", active: game.musicEnabled) {
                            game.musicEnabled.toggle()
                            HapticManager.shared.playUIClick()
                            RetroAudioEngine.shared.start()
                        }
                        CircleIconToggle(icon: game.sfxEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill", active: game.sfxEnabled) {
                            game.sfxEnabled.toggle()
                            HapticManager.shared.playUIClick()
                        }
                        CircleIconToggle(icon: "iphone.radiowaves.left.and.right", active: game.hapticsEnabled) {
                            game.hapticsEnabled.toggle()
                            if game.hapticsEnabled { HapticManager.shared.playUIClick() }
                        }
                    }
                }
                .padding(.horizontal, 22)
                .padding(.top, 14)

                Spacer()
            }

            // Center compact glass card
            VStack(spacing: 16) {
                // Emblem & Title
                HStack(spacing: 10) {
                    Image(systemName: "fish.fill")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [Color(red: 1.0, green: 0.90, blue: 0.35), Color(red: 1.0, green: 0.58, blue: 0.16)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    Text("ГЛУБИНА")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .tracking(3)
                        .foregroundColor(.white)
                }

                // Map selector cards
                HStack(spacing: 12) {
                    ForEach(MapTheme.allCases) { map in
                        MapCardButton(map: map, isSelected: game.selectedMap == map) {
                            HapticManager.shared.playUIClick()
                            RetroAudioEngine.shared.playSFX(.uiClick)
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                                game.selectedMap = map
                            }
                        }
                    }
                }

                // Mode segmented selector (1 Игрок / Вдвоём Bluetooth+Wi-Fi)
                HStack(spacing: 6) {
                    ForEach(GameMode.allCases) { mode in
                        Button {
                            HapticManager.shared.playUIClick()
                            RetroAudioEngine.shared.playSFX(.uiClick)
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                                game.selectedMode = mode
                            }
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: mode == .solo ? "person.fill" : "wave.3.right.circle.fill")
                                    .font(.system(size: 13, weight: .semibold))
                                Text(mode.title)
                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 9)
                            .foregroundColor(game.selectedMode == mode ? Color(red: 0.04, green: 0.14, blue: 0.26) : .white.opacity(0.85))
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(game.selectedMode == mode ? Color.white : Color.clear)
                            )
                        }
                    }
                }
                .padding(4)
                .background(Color.black.opacity(0.24), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

                // Primary Action Button
                Button {
                    game.startPressed()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: primaryButtonIcon)
                            .font(.system(size: 16, weight: .bold))
                        Text(primaryButtonTitle)
                            .font(.system(size: 17, weight: .heavy, design: .rounded))
                            .tracking(1)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(
                        LinearGradient(
                            colors: [Color(red: 0.14, green: 0.72, blue: 1.0), Color(red: 0.10, green: 0.44, blue: 0.96)],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous)
                    )
                    .shadow(color: Color(red: 0.10, green: 0.62, blue: 1.0).opacity(0.45), radius: 10, y: 4)
                }
            }
            .padding(.horizontal, 22)
            .padding(.vertical, 20)
            .frame(width: 340)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .stroke(Color.white.opacity(0.26), lineWidth: 1.2)
            )
            .shadow(color: .black.opacity(0.28), radius: 24, y: 10)
        }
    }

    private var primaryButtonTitle: String {
        if game.selectedMode == .multiplayer {
            if !multipeer.isConnected {
                return "ПОДКЛЮЧИТЬСЯ"
            }
            if multipeer.role == .guest {
                return "ЖДЁМ ХОСТА..."
            }
        }
        return "ИГРАТЬ"
    }

    private var primaryButtonIcon: String {
        if game.selectedMode == .multiplayer && !multipeer.isConnected {
            return "antenna.radiowaves.left.and.right"
        }
        return "play.fill"
    }
}

private struct CircleIconToggle: View {
    let icon: String
    let active: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(active ? .white : .white.opacity(0.42))
                .frame(width: 38, height: 38)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(active ? 0.32 : 0.14), lineWidth: 1))
        }
    }
}

private struct MapCardButton: View {
    let map: MapTheme
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: map.icon)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(map == .lagoon ? Color(red: 1.0, green: 0.88, blue: 0.35) : Color(red: 0.45, green: 0.80, blue: 1.0))
                Text(map.title)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                LinearGradient(
                    colors: map == .lagoon
                        ? [Color(red: 0.16, green: 0.78, blue: 0.94).opacity(0.75), Color(red: 0.10, green: 0.54, blue: 0.72).opacity(0.75)]
                        : [Color(red: 0.08, green: 0.30, blue: 0.56).opacity(0.85), Color(red: 0.04, green: 0.14, blue: 0.32).opacity(0.85)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(isSelected ? Color.white : Color.white.opacity(0.18), lineWidth: isSelected ? 2.2 : 1.0)
            )
        }
    }
}

// MARK: - Bluetooth / Local Wi-Fi Pairing Sheet

private struct MultiplayerPairingSheet: View {
    @ObservedObject var game: GameCoordinator
    @ObservedObject var multipeer: MultipeerManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                if let peer = multipeer.connectedPeer {
                    VStack(spacing: 12) {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 42))
                            .foregroundColor(.green)
                        Text("Подключено: \(peer.displayName)")
                            .font(.system(size: 19, weight: .bold, design: .rounded))

                        if multipeer.role == .host {
                            Button {
                                game.launchMatchAsHostOrSolo()
                            } label: {
                                Text("Начать игру вдвоём")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: 260)
                                    .padding(.vertical, 12)
                                    .background(Color.blue, in: RoundedRectangle(cornerRadius: 14))
                            }
                        } else {
                            Text("Ждём, пока хост нажмёт «Начать игру»...")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }

                        Button("Отключиться", role: .destructive) {
                            multipeer.stopAll()
                        }
                        .font(.footnote)
                        .padding(.top, 4)
                    }
                } else {
                    HStack(spacing: 14) {
                        Button {
                            HapticManager.shared.playUIClick()
                            multipeer.startHosting()
                        } label: {
                            VStack(spacing: 6) {
                                Image(systemName: "dot.radiowaves.left.and.right")
                                    .font(.system(size: 24))
                                Text("Создать комнату")
                                    .font(.system(size: 15, weight: .bold, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(multipeer.role == .host ? Color.blue : Color.blue.opacity(0.14), in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(multipeer.role == .host ? .white : .blue)
                        }

                        Button {
                            HapticManager.shared.playUIClick()
                            multipeer.startBrowsing()
                        } label: {
                            VStack(spacing: 6) {
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 24))
                                Text("Найти рядом")
                                    .font(.system(size: 15, weight: .bold, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(multipeer.role == .guest ? Color.blue : Color.blue.opacity(0.14), in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(multipeer.role == .guest ? .white : .blue)
                        }
                    }
                    .padding(.horizontal, 24)

                    HStack(spacing: 8) {
                        if multipeer.isSearching {
                            ProgressView()
                        }
                        Text(multipeer.statusText)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    if multipeer.role == .guest && !multipeer.discoveredPeers.isEmpty {
                        List(multipeer.discoveredPeers, id: \.self) { peer in
                            Button {
                                HapticManager.shared.playUIClick()
                                multipeer.invite(peer: peer)
                            } label: {
                                HStack {
                                    Image(systemName: "iphone")
                                        .foregroundColor(.blue)
                                    Text(peer.displayName)
                                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    Spacer()
                                    Text("Войти")
                                        .font(.system(size: 14, weight: .bold))
                                        .foregroundColor(.blue)
                                }
                            }
                        }
                        .frame(maxHeight: 160)
                    }
                }
            }
            .padding(.vertical, 12)
            .navigationTitle("Игра вдвоём (BT / Wi-Fi)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Закрыть") { dismiss() }
                }
            }
        }
    }
}

// MARK: - In-Game HUD, Effects & Multi-Touch Controls

private struct GameplayOverlayView: View {
    @ObservedObject var game: GameCoordinator

    var body: some View {
        ZStack {
            // 1. Subtle red edge pulse when a shark is right nearby
            if game.hud.sharkProximityLocal > 0.14 {
                RoundedRectangle(cornerRadius: 0)
                    .stroke(Color.red.opacity(Double(game.hud.sharkProximityLocal) * 0.55), lineWidth: 26)
                    .blur(radius: 14)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }

            // 2. Octopus ink splatters prank overlay
            if game.hud.inkTimerLocal > 0 {
                InkSplatOverlay(opacity: min(1.0, Double(game.hud.inkTimerLocal) / 0.8))
                    .allowsHitTesting(false)
            }

            // 3. Visual Dash (left thumb) + 4-Way D-Pad (right thumb)
            GeometryReader { geo in
                let leftInset = max(geo.safeAreaInsets.leading, 20)
                let rightInset = max(geo.safeAreaInsets.trailing, 20)
                let bottomInset = max(geo.safeAreaInsets.bottom, 16)

                // Left-thumb Dash button
                DashVisualButton(
                    cooldown: game.hud.dashCooldownLocal,
                    pressed: game.dpadVisual.dashPressed
                )
                .position(x: leftInset + 54, y: geo.size.height - bottomInset - 54)

                // Right-thumb 4-way D-Pad
                DPadVisualView(
                    state: game.dpadVisual,
                    inverted: game.hud.invertTimerLocal > 0
                )
                .position(x: geo.size.width - rightInset - 86, y: geo.size.height - bottomInset - 86)
            }
            .ignoresSafeArea()
            .allowsHitTesting(false)

            // 4. Native UIKit Multi-Touch Capture Layer (passes top HUD touches through)
            MultiTouchControlsOverlay { dx, dy, dash, visual in
                game.scene.updateLocalInput(dx: dx, dy: dy, dashPressed: dash)
                if game.dpadVisual != visual {
                    game.dpadVisual = visual
                }
            }
            .ignoresSafeArea()

            // 5. Compact Top Glass HUD
            VStack(spacing: 8) {
                HStack(spacing: 12) {
                    // P1 Pill (Gold)
                    PlayerHudPill(
                        label: game.multipeer.role == .guest ? "ПАРТНЁР" : "ТЫ",
                        color: Color(red: 1.0, green: 0.84, blue: 0.24),
                        score: game.hud.scoreP1,
                        level: game.hud.levelP1,
                        lives: game.hud.livesP1
                    )

                    Spacer()

                    // Center Timer & Series
                    VStack(spacing: 1) {
                        Text(formatTime(game.hud.timeRemaining))
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                            .monospacedDigit()
                            .foregroundColor(game.hud.timeRemaining < 15 ? Color(red: 1.0, green: 0.45, blue: 0.45) : .white)
                        Text("\(game.seriesP1) : \(game.seriesP2)")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.72))
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.22), lineWidth: 1))

                    Spacer()

                    // P2 Pill (Pink)
                    PlayerHudPill(
                        label: game.multipeer.role == .guest ? "ТЫ" : (game.selectedMode == .solo ? "БОТ" : "ПАРТНЁР"),
                        color: Color(red: 1.0, green: 0.40, blue: 0.68),
                        score: game.hud.scoreP2,
                        level: game.hud.levelP2,
                        lives: game.hud.livesP2
                    )

                    // Exit button
                    Button {
                        game.exitToMenu()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 34, height: 34)
                            .background(.ultraThinMaterial, in: Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.24), lineWidth: 1))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)

                // Prank / Event Toast Pill
                if let text = game.hud.bannerText, let emoji = game.hud.bannerEmoji {
                    HStack(spacing: 6) {
                        Text(emoji)
                        Text(text)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(Color.purple.opacity(0.72), in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.35), lineWidth: 1))
                    .transition(.move(edge: .top).combined(with: .opacity))
                }

                Spacer()
            }
        }
    }

    private func formatTime(_ seconds: Float) -> String {
        let s = max(0, Int(ceil(seconds)))
        return String(format: "%d:%02d", s / 60, s % 60)
    }
}

private struct PlayerHudPill: View {
    let label: String
    let color: Color
    let score: Int
    let level: Int
    let lives: Int

    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(color)
                .frame(width: 10, height: 10)
                .shadow(color: color, radius: 4)

            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 5) {
                    Text(label)
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .foregroundColor(.white.opacity(0.75))
                    Text("Ур.\(level)")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundColor(color)
                }
                HStack(spacing: 3) {
                    ForEach(0..<3, id: \.self) { idx in
                        Image(systemName: idx < lives ? "heart.fill" : "heart")
                            .font(.system(size: 9))
                            .foregroundColor(idx < lives ? Color(red: 1.0, green: 0.35, blue: 0.45) : .white.opacity(0.28))
                    }
                }
            }

            Text("\(score)")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .monospacedDigit()
                .foregroundColor(.white)
                .frame(minWidth: 26, alignment: .trailing)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(color.opacity(0.45), lineWidth: 1.2))
    }
}

private struct DashVisualButton: View {
    let cooldown: Float
    let pressed: Bool

    var body: some View {
        let ready = cooldown <= 0.05
        let progress = CGFloat(1.0 - min(1.0, cooldown / 2.6))

        ZStack {
            Circle()
                .fill(.ultraThinMaterial)
                .opacity(pressed ? 0.95 : 0.72)

            Circle()
                .stroke(Color.white.opacity(0.22), lineWidth: 3)

            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    ready ? Color(red: 1.0, green: 0.86, blue: 0.25) : Color.cyan.opacity(0.75),
                    style: StrokeStyle(lineWidth: 3.5, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))

            Image(systemName: "bolt.fill")
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(ready ? Color(red: 1.0, green: 0.90, blue: 0.35) : .white.opacity(0.45))
        }
        .frame(width: 78, height: 78)
        .scaleEffect(pressed ? 0.91 : 1.0)
        .animation(.easeOut(duration: 0.08), value: pressed)
    }
}

private struct DPadVisualView: View {
    let state: DPadVisualState
    let inverted: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(.ultraThinMaterial)
                .opacity(0.58)
                .overlay(
                    Circle().stroke(
                        inverted ? Color.purple.opacity(0.85) : Color.white.opacity(0.26),
                        lineWidth: inverted ? 2.5 : 1.4
                    )
                )

            // Up
            ArrowKeyCap(symbol: "chevron.up", active: state.up)
                .offset(y: -46)
            // Down
            ArrowKeyCap(symbol: "chevron.down", active: state.down)
                .offset(y: 46)
            // Left
            ArrowKeyCap(symbol: "chevron.left", active: state.left)
                .offset(x: -46)
            // Right
            ArrowKeyCap(symbol: "chevron.right", active: state.right)
                .offset(x: 46)

            // Center dot or invert symbol
            if inverted {
                Text("🔄")
                    .font(.system(size: 16))
            } else {
                Circle()
                    .fill(Color.white.opacity(0.22))
                    .frame(width: 14, height: 14)
            }
        }
        .frame(width: 148, height: 148)
    }
}

private struct ArrowKeyCap: View {
    let symbol: String
    let active: Bool

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: 20, weight: .heavy))
            .foregroundColor(active ? Color(red: 0.05, green: 0.16, blue: 0.28) : .white.opacity(0.85))
            .frame(width: 44, height: 44)
            .background(
                Circle().fill(active ? Color.white.opacity(0.92) : Color.white.opacity(0.14))
            )
            .scaleEffect(active ? 1.08 : 1.0)
            .animation(.easeOut(duration: 0.07), value: active)
    }
}

private struct InkSplatOverlay: View {
    let opacity: Double

    var body: some View {
        GeometryReader { geo in
            ZStack {
                InkBlob(x: 0.24, y: 0.30, r: 105, size: geo.size)
                InkBlob(x: 0.52, y: 0.48, r: 135, size: geo.size)
                InkBlob(x: 0.76, y: 0.34, r: 95, size: geo.size)
                InkBlob(x: 0.38, y: 0.72, r: 90, size: geo.size)
                InkBlob(x: 0.66, y: 0.68, r: 100, size: geo.size)
            }
            .opacity(opacity * 0.92)
        }
        .ignoresSafeArea()
    }
}

private struct InkBlob: View {
    let x: CGFloat
    let y: CGFloat
    let r: CGFloat
    let size: CGSize

    var body: some View {
        ZStack {
            Circle()
                .fill(Color(red: 0.05, green: 0.02, blue: 0.11))
                .frame(width: r * 1.6, height: r * 1.4)
            Capsule()
                .fill(Color(red: 0.05, green: 0.02, blue: 0.11))
                .frame(width: r * 0.22, height: r * 1.2)
                .offset(x: -r * 0.25, y: r * 0.65)
            Capsule()
                .fill(Color(red: 0.05, green: 0.02, blue: 0.11))
                .frame(width: r * 0.16, height: r * 0.95)
                .offset(x: r * 0.30, y: r * 0.55)
        }
        .position(x: size.width * x, y: size.height * y)
    }
}

// MARK: - Round Over Glass Card

private struct RoundOverOverlayView: View {
    @ObservedObject var game: GameCoordinator
    let result: RoundResult

    var body: some View {
        let isGuest = (game.multipeer.role == .guest)
        let headline: String = {
            if result.winnerIndex == -1 { return "Ничья!" }
            if isGuest {
                return result.winnerIndex == 1 ? "Победа!" : "Победил партнёр!"
            } else {
                if result.winnerIndex == 0 { return "Победа!" }
                return game.selectedMode == .solo ? "Победил бот" : "Победил партнёр!"
            }
        }()

        VStack(spacing: 14) {
            Text(headline)
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundColor(.white)

            HStack(spacing: 14) {
                ResultPlayerColumn(
                    name: isGuest ? "Партнёр" : "Ты",
                    color: Color(red: 1.0, green: 0.84, blue: 0.24),
                    score: result.scoreP1,
                    title: result.titleP1,
                    won: result.winnerIndex == 0
                )
                ResultPlayerColumn(
                    name: isGuest ? "Ты" : (game.selectedMode == .solo ? "Бот" : "Партнёр"),
                    color: Color(red: 1.0, green: 0.40, blue: 0.68),
                    score: result.scoreP2,
                    title: result.titleP2,
                    won: result.winnerIndex == 1
                )
            }

            Text("Серия: \(result.seriesP1) : \(result.seriesP2)")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundColor(.white.opacity(0.85))

            HStack(spacing: 12) {
                Button {
                    game.exitToMenu()
                } label: {
                    Text("Меню")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(Color.white.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
                }

                if !isGuest {
                    Button {
                        game.launchMatchAsHostOrSolo()
                    } label: {
                        Text("Ещё раунд")
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 11)
                            .background(
                                LinearGradient(
                                    colors: [Color(red: 0.14, green: 0.72, blue: 1.0), Color(red: 0.10, green: 0.44, blue: 0.96)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                in: RoundedRectangle(cornerRadius: 14)
                            )
                    }
                }
            }
        }
        .padding(22)
        .frame(width: 390)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(Color.white.opacity(0.28), lineWidth: 1.2)
        )
        .shadow(color: .black.opacity(0.32), radius: 24, y: 10)
    }
}

private struct ResultPlayerColumn: View {
    let name: String
    let color: Color
    let score: Int
    let title: String
    let won: Bool

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                if won { Text("👑") }
                Text(name)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(color)
            }
            Text("\(score)")
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundColor(.white)
            Text(title)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundColor(.white.opacity(0.82))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .padding(.horizontal, 8)
        .background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(won ? color.opacity(0.75) : Color.white.opacity(0.12), lineWidth: won ? 1.6 : 1)
        )
    }
}
