import Foundation
import MultipeerConnectivity
import NearbyInteraction
import UIKit

enum PeerRole: Equatable {
    case none
    case host
    case guest
}

final class MultipeerManager: NSObject, ObservableObject {
    static let serviceType = "glubina-mp"

    @Published var role: PeerRole = .none
    @Published var isSearching: Bool = false
    @Published var connectedPeer: MCPeerID? = nil
    @Published var statusText: String = "Поднесите iPhone друг к другу"
    @Published var distanceMeters: Float? = nil
    @Published var supportsUWB: Bool = false
    @Published var touchWaveActive: Bool = false

    var onReceiveMessage: ((NetworkMessage) -> Void)?
    var onDisconnect: (() -> Void)?
    var onTouchConnectCompleted: (() -> Void)?

    private let myPeerID: MCPeerID
    private let tieBreakerKey: String
    private var session: MCSession?
    private var advertiser: MCNearbyServiceAdvertiser?
    private var browser: MCNearbyServiceBrowser?

    private var niSession: NISession?
    private var hasTriggeredTouchConnect: Bool = false

    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    override init() {
        self.myPeerID = MCPeerID(displayName: UIDevice.current.name)
        self.tieBreakerKey = UUID().uuidString
        super.init()
        self.supportsUWB = NISession.deviceCapabilities.supportsPreciseDistanceMeasurement
    }

    var isConnected: Bool {
        connectedPeer != nil
    }

    /// Starts automatic zero-button discovery: BOTH iPhones advertise and browse simultaneously.
    /// A deterministic tie-breaker ensures one phone cleanly invites and becomes Host while the other accepts as Guest.
    func startAutoDiscovery() {
        if isConnected {
            // Already linked — re-arm UWB touch trigger if needed
            hasTriggeredTouchConnect = false
            startNearbyInteractionIfPossible()
            return
        }
        stopAll()
        isSearching = true
        hasTriggeredTouchConnect = false
        statusText = supportsUWB
            ? "Ищем второй iPhone рядом..."
            : "Ищем второй iPhone по Bluetooth / Wi-Fi..."

        let newSession = MCSession(peer: myPeerID, securityIdentity: nil, encryptionPreference: .none)
        newSession.delegate = self
        session = newSession

        let adv = MCNearbyServiceAdvertiser(
            peer: myPeerID,
            discoveryInfo: ["k": tieBreakerKey],
            serviceType: Self.serviceType
        )
        adv.delegate = self
        adv.startAdvertisingPeer()
        advertiser = adv

        let br = MCNearbyServiceBrowser(peer: myPeerID, serviceType: Self.serviceType)
        br.delegate = self
        br.startBrowsingForPeers()
        browser = br
    }

    func stopAll() {
        advertiser?.stopAdvertisingPeer()
        advertiser = nil
        browser?.stopBrowsingForPeers()
        browser = nil
        session?.disconnect()
        session = nil
        niSession?.invalidate()
        niSession = nil

        DispatchQueue.main.async {
            self.role = .none
            self.isSearching = false
            self.connectedPeer = nil
            self.distanceMeters = nil
            self.touchWaveActive = false
            self.hasTriggeredTouchConnect = false
            self.statusText = "Поднесите iPhone друг к другу"
        }
    }

    func send(_ message: NetworkMessage, reliable: Bool) {
        guard let session = session, !session.connectedPeers.isEmpty else { return }
        do {
            let data = try encoder.encode(message)
            try session.send(data, toPeers: session.connectedPeers, with: reliable ? .reliable : .unreliable)
        } catch {
            // Unreliable packets may safely drop
        }
    }

    // MARK: - Apple NearbyInteraction (U1/U2 Touch-to-Connect)

    private func startNearbyInteractionIfPossible() {
        guard supportsUWB else { return }
        niSession?.invalidate()
        let ni = NISession()
        ni.delegate = self
        niSession = ni

        if let token = ni.discoveryToken,
           let tokenData = try? NSKeyedArchiver.archivedData(withRootObject: token, requiringSecureCoding: true) {
            send(.discoveryToken(tokenData), reliable: true)
        }
    }

    private func handlePeerDiscoveryToken(_ data: Data) {
        guard supportsUWB else { return }
        guard let peerToken = try? NSKeyedUnarchiver.unarchivedObject(ofClass: NIDiscoveryToken.self, from: data) else {
            return
        }
        if niSession == nil {
            let ni = NISession()
            ni.delegate = self
            niSession = ni
            if let myToken = ni.discoveryToken,
               let myData = try? NSKeyedArchiver.archivedData(withRootObject: myToken, requiringSecureCoding: true) {
                send(.discoveryToken(myData), reliable: true)
            }
        }
        let config = NINearbyPeerConfiguration(peerToken: peerToken)
        niSession?.run(config)
    }

    func fireTouchConnectMagic(broadcast: Bool) {
        guard !hasTriggeredTouchConnect else { return }
        hasTriggeredTouchConnect = true
        if broadcast {
            send(.touchConnectTrigger, reliable: true)
        }
        DispatchQueue.main.async {
            self.touchWaveActive = true
            HapticManager.shared.playTouchConnect()
            AtmosphericAudioEngine.shared.playSFX(.touchConnect)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) {
                self.touchWaveActive = false
                self.onTouchConnectCompleted?()
            }
        }
    }

    func resetTouchArm() {
        hasTriggeredTouchConnect = false
    }
}

// MARK: - MCSessionDelegate

extension MultipeerManager: MCSessionDelegate {
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .connected:
                self.connectedPeer = peerID
                self.isSearching = false
                self.advertiser?.stopAdvertisingPeer()
                self.browser?.stopBrowsingForPeers()
                self.statusText = self.supportsUWB
                    ? "Рядом: \(peerID.displayName) — коснитесь верхними гранями!"
                    : "Подключено: \(peerID.displayName)"
                HapticManager.shared.playUIClick()
                self.startNearbyInteractionIfPossible()

            case .connecting:
                self.statusText = "Связываемся с \(peerID.displayName)..."

            case .notConnected:
                let wasConnected = (self.connectedPeer == peerID)
                if wasConnected {
                    self.connectedPeer = nil
                    self.distanceMeters = nil
                    self.niSession?.invalidate()
                    self.niSession = nil
                    self.statusText = "Связь прервана"
                    self.onDisconnect?()
                }

            @unknown default:
                break
            }
        }
    }

    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        guard let msg = try? decoder.decode(NetworkMessage.self, from: data) else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch msg {
            case .discoveryToken(let tokenData):
                self.handlePeerDiscoveryToken(tokenData)
            case .touchConnectTrigger:
                self.fireTouchConnectMagic(broadcast: false)
            default:
                self.onReceiveMessage?(msg)
            }
        }
    }

    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {}
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {}
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?) {}
}

// MARK: - Advertiser & Browser (Automatic Collision-Free Tie-Breaker)

extension MultipeerManager: MCNearbyServiceAdvertiserDelegate {
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        guard !isConnected else {
            invitationHandler(false, nil)
            return
        }
        DispatchQueue.main.async {
            self.role = .guest
        }
        invitationHandler(true, session)
    }

    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: Error) {
        DispatchQueue.main.async {
            self.statusText = "Разрешите Bluetooth и Локальную сеть"
            self.isSearching = false
        }
    }
}

extension MultipeerManager: MCNearbyServiceBrowserDelegate {
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
        guard !isConnected, let session = session else { return }
        let remoteKey = info?["k"] ?? peerID.displayName
        // Deterministic tie-breaker: only the peer with the larger key initiates the invite and becomes Host
        if tieBreakerKey > remoteKey {
            DispatchQueue.main.async {
                self.role = .host
                self.statusText = "Подключаем \(peerID.displayName)..."
            }
            browser.invitePeer(peerID, to: session, withContext: nil, timeout: 12)
        }
    }

    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {}

    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: Error) {
        DispatchQueue.main.async {
            self.statusText = "Разрешите Bluetooth и Локальную сеть"
            self.isSearching = false
        }
    }
}

// MARK: - NISessionDelegate (Live Centimeter Ranging & Touch Trigger)

extension MultipeerManager: NISessionDelegate {
    func session(_ session: NISession, didUpdate nearbyObjects: [NINearbyObject]) {
        guard let obj = nearbyObjects.first, let dist = obj.distance else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.distanceMeters = dist
            // Trigger AirDrop-like touch connect when phones come within 16 cm!
            if dist <= 0.16 && !self.hasTriggeredTouchConnect && self.isConnected {
                self.fireTouchConnectMagic(broadcast: true)
            }
        }
    }

    func session(_ session: NISession, didRemove nearbyObjects: [NINearbyObject], reason: NINearbyObject.RemovalReason) {
        DispatchQueue.main.async {
            self.distanceMeters = nil
        }
    }

    func sessionWasSuspended(_ session: NISession) {}
    func sessionSuspensionEnded(_ session: NISession) {}
    func session(_ session: NISession, didInvalidateWith error: Error) {
        DispatchQueue.main.async {
            self.distanceMeters = nil
        }
    }
}
