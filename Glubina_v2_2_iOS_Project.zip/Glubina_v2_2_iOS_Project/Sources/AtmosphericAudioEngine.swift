import Foundation
import AVFoundation
import os

enum OceanSFXKind: Int {
    case bite = 0
    case bigBite = 1
    case dash = 2
    case sharkWarning = 3
    case levelUp = 4
    case prank = 5
    case bubblePop = 6
    case pufferPuff = 7
    case jellyZap = 8
    case playerBump = 9
    case hurt = 10
    case touchConnect = 11
    case uiClick = 12
}

enum StereoDuetRole: Int {
    case solo = 0
    case hostDuet = 1
    case guestDuet = 2
}

private struct SFXVoice {
    var active: Bool = false
    var kind: OceanSFXKind = .bite
    var time: Double = 0
    var duration: Double = 0.2
    var phase: Double = 0
    var phase2: Double = 0
}

private struct MelodicVoice {
    var active: Bool = false
    var freq: Double = 440
    var phase: Double = 0
    var modPhase: Double = 0
    var env: Double = 0
    var decayRate: Double = 0.9999
    var pan: Double = 0.5
    var voiceType: Int = 0 // 0=abyss glass, 1=reef marimba, 2=reef harp, 3=film rhodes, 4=water drop
    var gain: Double = 0.1
}

/// Multi-world cinematic underwater soundtrack & tactile SFX synthesizer.
/// Features:
///  - 3 completely distinct musical genres/tempos/instruments for the 3 maps
///  - Continuous Phase-Lock Loop (PLL) sync across two iPhones (eliminates drift!)
///  - Spatial Stereo Duet where Host & Guest iPhones play complementary instruments & Call-and-Answer melodies
final class AtmosphericAudioEngine {
    static let shared = AtmosphericAudioEngine()

    private let engine = AVAudioEngine()
    private let reverb = AVAudioUnitReverb()
    private var musicSourceNode: AVAudioSourceNode?
    private var sfxSourceNode: AVAudioSourceNode?
    private let sampleRate: Double = 44100.0
    private var isStarted: Bool = false

    private let lockPtr: UnsafeMutablePointer<os_unfair_lock>

    // Shared control state (synchronized once per audio buffer)
    private var musicEnabledState: Bool = true
    private var sfxEnabledState: Bool = true
    private var currentMapRaw: Int = 0 // 0=abyss, 1=reef, 2=ocean35
    private var duetRoleState: StereoDuetRole = .solo
    private var threatLevelTarget: Double = 0.0

    // Clock sync state
    private var publishedMusicTime: Double = 0
    private var resetMusicFlag: Bool = false
    private var musicStartCountdownSamples: Int = 0
    private var pendingTargetMusicTime: Double? = nil

    // Audio-thread-exclusive music state
    private var musicTime: Double = 0
    private var lastTriggeredStepAbs: Int = -1
    private var smoothedThreat: Double = 0
    private var pllRateAdjust: Double = 1.0
    private var pllHoldRemaining: Double = 0.0

    // Pad / Chord oscillators
    private var padPhaseA: [Double] = [0, 0, 0, 0]
    private var padPhaseB: [Double] = [0, 0, 0, 0]
    private var subPhase: Double = 0
    private var whalePhase: Double = 0
    private var threatPulsePhase: Double = 0
    private var bassPluckEnv: Double = 0

    // Polyphonic melodic voices (8 slots)
    private var voices: [MelodicVoice] = Array(repeating: MelodicVoice(), count: 8)
    private var nextVoiceSlot: Int = 0

    // Hydrophone ocean wash
    private var oceanRng: UInt32 = 0x51A7BEEF
    private var oceanLP1: Double = 0
    private var oceanLP2: Double = 0

    // Master filter
    private var masterLPL: Double = 0
    private var masterLPR: Double = 0

    // Stereo ping-pong delay (~0.45s L, ~0.60s R)
    private let delayLenL = 19845
    private let delayLenR = 26460
    private var delayBufL: [Float]
    private var delayBufR: [Float]
    private var delayIdxL: Int = 0
    private var delayIdxR: Int = 0

    // SFX DSP state
    private var sfxVoices: [SFXVoice] = Array(repeating: SFXVoice(), count: 10)
    private var pendingSFXQueue: [OceanSFXKind] = []
    private var sfxRng: UInt32 = 0x99887766

    // =========================================================================
    // 3 COMPLETELY DISTINCT MUSICAL WORLDS
    // =========================================================================

    // WORLD 0: БЕЗДНА (Abyss) — 68 BPM Dark Hypnotic Deep-Sea Ambient (D Minor / Phrygian)
    // Slow, mysterious cathedral drones + haunting glass harmonica + distant resonant chimes
    private let abyssChords: [[Double]] = [
        [146.83, 174.61, 220.00, 329.63], // Dm9
        [116.54, 174.61, 220.00, 293.66], // Bbmaj7
        [130.81, 164.81, 196.00, 293.66], // Cadd9
        [110.00, 164.81, 196.00, 261.63]  // Am7
    ]
    private let abyssCallNotes: [[Double]] = [
        [293.66, 349.23, 440.00, 329.63],
        [293.66, 349.23, 293.66, 220.00],
        [261.63, 329.63, 392.00, 293.66],
        [220.00, 261.63, 329.63, 293.66]
    ]
    private let abyssAnswerNotes: [[Double]] = [
        [587.33, 659.25, 523.25, 440.00],
        [587.33, 523.25, 440.00, 349.23],
        [523.25, 587.33, 493.88, 392.00],
        [440.00, 523.25, 440.00, 329.63]
    ]

    // WORLD 1: АКВАРЕЛЬНЫЙ РИФ (Reef) — 112 BPM Sunlit Acoustic Marimba & Harp (G Major / Lydian)
    // Bright, joyful, organic Ghibli-inspired plucked wooden marimba + shimmering harp!
    private let reefChords: [[Double]] = [
        [196.00, 246.94, 293.66, 369.99], // Gmaj7
        [164.81, 246.94, 293.66, 369.99], // Em9
        [130.81, 196.00, 246.94, 329.63], // Cmaj7
        [146.83, 220.00, 293.66, 369.99]  // Dmaj7
    ]
    private let reefCallNotes: [[Double]] = [
        [392.00, 493.88, 587.33, 493.88],
        [329.63, 392.00, 493.88, 587.33],
        [261.63, 329.63, 392.00, 493.88],
        [293.66, 369.99, 440.00, 587.33]
    ]
    private let reefAnswerNotes: [[Double]] = [
        [783.99, 739.99, 587.33, 659.25],
        [739.99, 659.25, 587.33, 493.88],
        [659.25, 587.33, 493.88, 523.25],
        [739.99, 659.25, 587.33, 440.00]
    ]

    // WORLD 2: ОКЕАН 35mm (Ocean 35mm) — 86 BPM Nostalgic Analog Lo-Fi Rhodes Cinema (Fmaj9)
    // Warm detuned electric piano chords with gentle tremolo, soft analog bass pulse & film warmth
    private let filmChords: [[Double]] = [
        [174.61, 220.00, 261.63, 329.63], // Fmaj7
        [164.81, 196.00, 246.94, 293.66], // Em7
        [146.83, 174.61, 220.00, 261.63], // Dm7
        [130.81, 196.00, 246.94, 329.63]  // Cmaj7
    ]
    private let filmCallNotes: [[Double]] = [
        [349.23, 440.00, 329.63, 392.00],
        [329.63, 392.00, 293.66, 329.63],
        [293.66, 349.23, 440.00, 349.23],
        [329.63, 392.00, 493.88, 392.00]
    ]
    private let filmAnswerNotes: [[Double]] = [
        [659.25, 587.33, 523.25, 440.00],
        [587.33, 493.88, 440.00, 392.00],
        [523.25, 440.00, 392.00, 349.23],
        [659.25, 587.33, 493.88, 523.25]
    ]

    var isMusicEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = musicEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            musicEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    var isSFXEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = sfxEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            sfxEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    var currentMusicTime: Double {
        os_unfair_lock_lock(lockPtr)
        let t = publishedMusicTime
        os_unfair_lock_unlock(lockPtr)
        return t
    }

    private init() {
        lockPtr = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1)
        lockPtr.initialize(to: os_unfair_lock())
        delayBufL = Array(repeating: 0, count: delayLenL)
        delayBufR = Array(repeating: 0, count: delayLenR)
    }

    deinit {
        engine.stop()
        lockPtr.deinitialize(count: 1)
        lockPtr.deallocate()
    }

    func setMap(_ map: MapTheme) {
        let newRaw: Int
        switch map {
        case .abyss: newRaw = 0
        case .reef: newRaw = 1
        case .ocean35: newRaw = 2
        }
        os_unfair_lock_lock(lockPtr)
        currentMapRaw = newRaw
        os_unfair_lock_unlock(lockPtr)

        // Match reverb space cleanly to each map's acoustic personality
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch map {
            case .abyss:
                self.reverb.wetDryMix = 56
            case .reef:
                self.reverb.wetDryMix = 26
            case .ocean35:
                self.reverb.wetDryMix = 38
            }
        }
    }

    func setThreatLevel(_ value: Float) {
        os_unfair_lock_lock(lockPtr)
        threatLevelTarget = Double(min(max(value, 0), 1))
        os_unfair_lock_unlock(lockPtr)
    }

    func setDuetRole(_ role: StereoDuetRole) {
        os_unfair_lock_lock(lockPtr)
        duetRoleState = role
        os_unfair_lock_unlock(lockPtr)
    }

    func scheduleSynchronizedStart(delaySeconds: Double, role: StereoDuetRole, map: MapTheme) {
        start()
        setMap(map)
        let samples = max(0, Int(delaySeconds * sampleRate))
        os_unfair_lock_lock(lockPtr)
        duetRoleState = role
        resetMusicFlag = true
        pendingTargetMusicTime = nil
        musicStartCountdownSamples = samples
        os_unfair_lock_unlock(lockPtr)
    }

    /// Continuously phase-locks the Guest's audio clock to the Host's exact soundtrack time!
    func syncMusicPhase(targetHostTime: Double, role: StereoDuetRole, map: MapTheme) {
        if !isStarted { start() }
        let newRaw: Int
        switch map {
        case .abyss: newRaw = 0
        case .reef: newRaw = 1
        case .ocean35: newRaw = 2
        }
        os_unfair_lock_lock(lockPtr)
        currentMapRaw = newRaw
        duetRoleState = role
        pendingTargetMusicTime = targetHostTime
        os_unfair_lock_unlock(lockPtr)
    }

    func start() {
        if isStarted {
            if !engine.isRunning {
                try? engine.start()
            }
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {
            // Safe fallback
        }

        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2) else { return }

        reverb.loadFactoryPreset(.largeHall2)
        reverb.wetDryMix = 44

        let mNode = AVAudioSourceNode(format: format) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            self.renderMusic(abl: UnsafeMutableAudioBufferListPointer(audioBufferList), frames: Int(frameCount))
            return noErr
        }

        let sNode = AVAudioSourceNode(format: format) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            self.renderSFX(abl: UnsafeMutableAudioBufferListPointer(audioBufferList), frames: Int(frameCount))
            return noErr
        }

        musicSourceNode = mNode
        sfxSourceNode = sNode

        engine.attach(mNode)
        engine.attach(reverb)
        engine.attach(sNode)

        engine.connect(mNode, to: reverb, format: format)
        engine.connect(reverb, to: engine.mainMixerNode, format: format)
        engine.connect(sNode, to: engine.mainMixerNode, format: format)
        engine.mainMixerNode.outputVolume = 0.90

        do {
            try engine.start()
            isStarted = true
        } catch {
            isStarted = false
        }
    }

    func playSFX(_ kind: OceanSFXKind) {
        if !isStarted { start() }
        os_unfair_lock_lock(lockPtr)
        if sfxEnabledState && pendingSFXQueue.count < 8 {
            pendingSFXQueue.append(kind)
        }
        os_unfair_lock_unlock(lockPtr)
    }

    @inline(__always)
    private func nextNoise(_ state: inout UInt32) -> Double {
        state = state &* 1664525 &+ 1013904223
        return Double(state & 0xFFFF) / 32768.0 - 1.0
    }

    @inline(__always)
    private func spawnVoice(freq: Double, decay: Double, pan: Double, type: Int, gain: Double) {
        var v = MelodicVoice()
        v.active = true
        v.freq = freq
        v.phase = 0
        v.modPhase = 0
        v.env = 1.0
        v.decayRate = decay
        v.pan = pan
        v.voiceType = type
        v.gain = gain
        voices[nextVoiceSlot] = v
        nextVoiceSlot = (nextVoiceSlot + 1) % voices.count
    }

    // MARK: - Music Render (Deterministic Time-Indexed Sequencer + Smooth PLL Sync)

    private func renderMusic(abl: UnsafeMutableAudioBufferListPointer, frames: Int) {
        guard abl.count >= 1 else { return }
        let leftBuf = abl[0].mData?.assumingMemoryBound(to: Float.self)
        let rightBuf = abl.count > 1 ? abl[1].mData?.assumingMemoryBound(to: Float.self) : nil

        os_unfair_lock_lock(lockPtr)
        let playMusic = musicEnabledState
        let mapIdx = currentMapRaw
        let role = duetRoleState
        let threatTarget = threatLevelTarget
        let shouldReset = resetMusicFlag
        let countdown = musicStartCountdownSamples
        let syncTarget = pendingTargetMusicTime
        if shouldReset { resetMusicFlag = false }
        pendingTargetMusicTime = nil
        os_unfair_lock_unlock(lockPtr)

        if shouldReset {
            musicTime = 0
            lastTriggeredStepAbs = -1
            for i in 0..<voices.count { voices[i].active = false }
            for i in 0..<delayLenL { delayBufL[i] = 0 }
            for i in 0..<delayLenR { delayBufR[i] = 0 }
        }

        // Phase-Lock Loop (PLL): lock Guest clock tightly to Host clock across buffers!
        if let target = syncTarget, countdown == 0 {
            let err = target - musicTime
            if abs(err) > 0.065 {
                // Big initial offset (>65ms) -> instant clean snap to exact beat time!
                musicTime = max(0, target)
                let stepDur = (mapIdx == 0) ? 0.441 : (mapIdx == 1 ? 0.268 : 0.349)
                lastTriggeredStepAbs = Int(floor(musicTime / stepDur))
                pllRateAdjust = 1.0
                pllHoldRemaining = 0.0
            } else if abs(err) > 0.006 {
                // Small drift (6..65ms) -> smooth continuous speed glide over next 0.45s (max ±4%)
                pllRateAdjust = 1.0 + max(-0.04, min(0.04, err * 2.2))
                pllHoldRemaining = 0.45
            } else {
                pllRateAdjust = 1.0
                pllHoldRemaining = 0.0
            }
        }
        let bufDur = Double(frames) / sampleRate
        if pllHoldRemaining > 0 {
            pllHoldRemaining = max(0, pllHoldRemaining - bufDur)
            if pllHoldRemaining == 0 { pllRateAdjust = 1.0 }
        }
        let rateAdjust = pllRateAdjust

        if !playMusic {
            // Still advance silent clock if synced so re-enabling stays in sync
            musicTime += (Double(frames) / sampleRate) * rateAdjust
            os_unfair_lock_lock(lockPtr)
            publishedMusicTime = musicTime
            os_unfair_lock_unlock(lockPtr)
            for i in 0..<frames { leftBuf?[i] = 0; rightBuf?[i] = 0 }
            return
        }

        var localCountdown = countdown
        let dt = 1.0 / sampleRate
        let stepDt = dt * rateAdjust
        let twoPi = Double.pi * 2.0

        // Distinct tempos per map:
        // Map 0 (Abyss):   68 BPM (step = 8th note = 0.441s, 8 steps per chord = 3.53s)
        // Map 1 (Reef):   112 BPM (step = 8th note = 0.268s, 8 steps per chord = 2.14s)
        // Map 2 (Ocean35): 86 BPM (step = 8th note = 0.349s, 8 steps per chord = 2.79s)
        let stepDur: Double = (mapIdx == 0) ? 0.441 : (mapIdx == 1 ? 0.268 : 0.349)
        let chordList = (mapIdx == 0) ? abyssChords : (mapIdx == 1 ? reefChords : filmChords)
        let callList = (mapIdx == 0) ? abyssCallNotes : (mapIdx == 1 ? reefCallNotes : filmCallNotes)
        let answerList = (mapIdx == 0) ? abyssAnswerNotes : (mapIdx == 1 ? reefAnswerNotes : filmAnswerNotes)

        // Spatial Stereo Duet role separation (crystal clear when sitting side-by-side!):
        // Host iPhone  -> Rich Bass + Lower Foundation Pad + Odd-beat CALL phrases
        // Guest iPhone -> Airy Upper Pad Shimmer + Even-beat ANSWER phrases + Sparkles
        let hasBass = (role != .guestDuet)
        let lowPadGain: Double = (role == .guestDuet) ? 0.18 : (role == .hostDuet ? 1.15 : 0.88)
        let highPadGain: Double = (role == .hostDuet) ? 0.20 : (role == .guestDuet ? 1.15 : 0.82)

        for i in 0..<frames {
            if localCountdown > 0 {
                localCountdown -= 1
                leftBuf?[i] = 0
                rightBuf?[i] = 0
                continue
            }

            musicTime += stepDt
            smoothedThreat += (threatTarget - smoothedThreat) * 0.00025

            // Deterministic beat & chord lookup directly from musicTime (guaranteed identical on both iPhones!)
            let absStep = Int(floor(musicTime / stepDur))
            let chordIndex = (absStep / 8) % chordList.count
            let stepInBar = absStep % 8

            if absStep != lastTriggeredStepAbs {
                lastTriggeredStepAbs = absStep
                let callPat = callList[chordIndex]
                let ansPat = answerList[chordIndex]
                let isCallBeat = (stepInBar % 2 == 0)   // Steps 0, 2, 4, 6 -> Host CALL
                let isAnswerBeat = (stepInBar % 2 == 1) // Steps 1, 3, 5, 7 -> Guest ANSWER
                let phraseIdx = (stepInBar / 2) % 4

                // Bass pulse on beat 0 & 4 (Host & Solo)
                if hasBass && (stepInBar == 0 || (mapIdx != 0 && stepInBar == 4)) {
                    bassPluckEnv = 1.0
                }

                // Trigger map-specific instruments!
                if mapIdx == 0 {
                    // === MAP 0: БЕЗДНА (Hypnotic Glass Harmonica & Distant Abyssal Chimes) ===
                    if isCallBeat && (role == .solo || role == .hostDuet) {
                        if stepInBar != 6 { // spacious breathing pause
                            spawnVoice(freq: callPat[phraseIdx], decay: 0.99995, pan: 0.36, type: 0, gain: role == .hostDuet ? 0.15 : 0.11)
                        }
                    }
                    if isAnswerBeat && (role == .solo || role == .guestDuet) {
                        if stepInBar == 1 || stepInBar == 5 {
                            spawnVoice(freq: ansPat[phraseIdx], decay: 0.99994, pan: 0.68, type: 0, gain: role == .guestDuet ? 0.15 : 0.09)
                        }
                    }
                } else if mapIdx == 1 {
                    // === MAP 1: АКВАРЕЛЬНЫЙ РИФ (Sunlit Wooden Marimba + Nylon Harp + Water Drops) ===
                    if isCallBeat && (role == .solo || role == .hostDuet) {
                        // Warm rhythmic wooden marimba
                        spawnVoice(freq: callPat[phraseIdx], decay: 0.99972, pan: 0.32, type: 1, gain: role == .hostDuet ? 0.18 : 0.13)
                    }
                    if isAnswerBeat && (role == .solo || role == .guestDuet) {
                        // Bright plucked acoustic harp echoing from the second iPhone!
                        spawnVoice(freq: ansPat[phraseIdx], decay: 0.99985, pan: 0.70, type: 2, gain: role == .guestDuet ? 0.16 : 0.11)
                        if stepInBar == 7 {
                            spawnVoice(freq: ansPat[phraseIdx] * 2.0, decay: 0.99960, pan: 0.55, type: 4, gain: 0.07)
                        }
                    }
                } else {
                    // === MAP 2: ОКЕАН 35mm (Warm Nostalgic Rhodes Electric Piano Cinema) ===
                    if isCallBeat && (role == .solo || role == .hostDuet) {
                        if stepInBar == 0 || stepInBar == 4 {
                            // Full lush Rhodes chord stab on Host
                            let ch = chordList[chordIndex]
                            spawnVoice(freq: ch[1] * 2.0, decay: 0.99991, pan: 0.38, type: 3, gain: 0.10)
                            spawnVoice(freq: ch[2] * 2.0, decay: 0.99991, pan: 0.48, type: 3, gain: 0.09)
                        } else {
                            spawnVoice(freq: callPat[phraseIdx], decay: 0.99990, pan: 0.34, type: 3, gain: role == .hostDuet ? 0.14 : 0.10)
                        }
                    }
                    if isAnswerBeat && (role == .solo || role == .guestDuet) {
                        if stepInBar == 1 || stepInBar == 3 || stepInBar == 5 {
                            spawnVoice(freq: ansPat[phraseIdx], decay: 0.99992, pan: 0.72, type: 3, gain: role == .guestDuet ? 0.15 : 0.09)
                        }
                    }
                }
            }

            // 1. Subtle hydrophone underwater wash
            let wNoise = nextNoise(&oceanRng)
            oceanLP1 += (wNoise - oceanLP1) * (mapIdx == 1 ? 0.020 : 0.010)
            oceanLP2 += (oceanLP1 - oceanLP2) * 0.008
            let tide = 0.65 + 0.35 * sin(musicTime * 0.24)
            let hydrophone = oceanLP2 * (mapIdx == 0 ? 0.068 : 0.042) * tide

            // 2. Map-tuned Pad / Atmosphere
            let chord = chordList[chordIndex]
            let tapeWow = (mapIdx == 2) ? (1.0 + 0.0028 * sin(musicTime * 1.35)) : 1.0
            let breath = 0.70 + 0.30 * sin(musicTime * (mapIdx == 0 ? 0.25 : 0.45))
            var padL: Double = 0
            var padR: Double = 0

            for v in 0..<4 {
                let isUpper = (v >= 2)
                let layerGain = isUpper ? highPadGain : lowPadGain
                let f = chord[v] * (isUpper && mapIdx == 0 ? 1.0 : 1.0) * tapeWow
                padPhaseA[v] += twoPi * f * dt
                if padPhaseA[v] > twoPi { padPhaseA[v] -= twoPi }
                padPhaseB[v] += twoPi * (f * 1.0045) * dt
                if padPhaseB[v] > twoPi { padPhaseB[v] -= twoPi }

                let sA = sin(padPhaseA[v]) * 0.80 + sin(padPhaseA[v] * 2.0) * (mapIdx == 1 ? 0.08 : 0.14)
                let sB = sin(padPhaseB[v]) * 0.80
                let w = (mapIdx == 1 ? 0.026 : (mapIdx == 0 ? 0.056 : 0.042)) * breath * layerGain
                if v % 2 == 0 {
                    padL += (sA * 0.68 + sB * 0.32) * w
                    padR += (sB * 0.68 + sA * 0.32) * w
                } else {
                    padL += (sB * 0.68 + sA * 0.32) * w
                    padR += (sA * 0.68 + sB * 0.32) * w
                }
            }

            // Abyss-only deep haunting resonant sweep (subtle distant whale/sonar ambience)
            var abyssSweep: Double = 0
            if mapIdx == 0 {
                let whaleLfo = sin(musicTime * 0.18)
                let wf = 110.0 + 38.0 * whaleLfo
                whalePhase += twoPi * wf * dt
                if whalePhase > twoPi { whalePhase -= twoPi }
                let whaleGate = max(0.0, sin(musicTime * 0.14 - 1.2))
                abyssSweep = sin(whalePhase) * whaleGate * whaleGate * 0.042
            }

            // 3. Bass + Dynamic Predator Tension Pulse
            let rootSub = chord[0] * 0.5
            subPhase += twoPi * rootSub * dt
            if subPhase > twoPi { subPhase -= twoPi }
            bassPluckEnv *= (mapIdx == 0 ? 0.99996 : 0.99988)
            let bassLevel: Double = hasBass ? (mapIdx == 0 ? 0.125 : (mapIdx == 2 ? 0.115 : 0.085)) : 0.0
            let subWave = (sin(subPhase) * 0.82 + sin(subPhase * 2.0) * 0.18) * (0.35 + 0.65 * bassPluckEnv) * bassLevel

            threatPulsePhase += twoPi * 1.7 * dt
            if threatPulsePhase > twoPi { threatPulsePhase -= twoPi }
            let threatPulse = sin(subPhase * 0.75) * (0.5 + 0.5 * sin(threatPulsePhase)) * smoothedThreat * 0.13

            // 4. Polyphonic Map Instruments (Glass / Marimba / Harp / Rhodes / Waterdrop)
            var melL: Double = 0
            var melR: Double = 0
            let rhodesTrem = 0.82 + 0.18 * sin(musicTime * 4.8 * twoPi)

            for idx in 0..<voices.count {
                guard voices[idx].active else { continue }
                var mv = voices[idx]
                mv.env *= mv.decayRate
                if mv.env < 0.002 {
                    mv.active = false
                    voices[idx] = mv
                    continue
                }
                mv.phase += twoPi * mv.freq * dt
                if mv.phase > twoPi { mv.phase -= twoPi }

                let sample: Double
                switch mv.voiceType {
                case 0: // Abyss Glass Harmonica
                    mv.modPhase += twoPi * (mv.freq * 3.0) * dt
                    if mv.modPhase > twoPi { mv.modPhase -= twoPi }
                    sample = sin(mv.phase + sin(mv.modPhase) * 0.45 * mv.env) * mv.env * mv.gain

                case 1: // Reef Wooden Marimba (strong fundamental + fast-decaying 4th harmonic wood knock)
                    mv.modPhase += twoPi * (mv.freq * 4.0) * dt
                    if mv.modPhase > twoPi { mv.modPhase -= twoPi }
                    let knock = sin(mv.modPhase) * mv.env * mv.env * mv.env * 0.35
                    sample = (sin(mv.phase) * 0.85 + knock) * mv.env * mv.gain

                case 2: // Reef Nylon Harp (warm rich harmonic decay)
                    let h2 = sin(mv.phase * 2.0) * 0.30 * mv.env
                    let h3 = sin(mv.phase * 3.0) * 0.12 * mv.env * mv.env
                    sample = (sin(mv.phase) * 0.72 + h2 + h3) * mv.env * mv.gain

                case 3: // Ocean 35mm Warm Rhodes Electric Piano (bell tine attack + soulful tremolo)
                    mv.modPhase += twoPi * (mv.freq * 2.0) * dt
                    if mv.modPhase > twoPi { mv.modPhase -= twoPi }
                    let tine = sin(mv.phase * 7.0) * mv.env * mv.env * mv.env * mv.env * 0.18
                    sample = (sin(mv.phase + sin(mv.modPhase) * 0.28 * mv.env) * 0.84 + tine) * mv.env * rhodesTrem * mv.gain

                default: // Water-drop sparkle
                    sample = sin(mv.phase) * mv.env * mv.gain
                }

                melL += sample * mv.pan
                melR += sample * (1.0 - mv.pan)
                voices[idx] = mv
            }

            // 5. Delay tailored per world (shorter & crisper in Reef, dreamy in Abyss/35mm)
            let dL = Double(delayBufL[delayIdxL])
            let dR = Double(delayBufR[delayIdxR])
            let fb: Double = (mapIdx == 0) ? 0.52 : (mapIdx == 1 ? 0.28 : 0.42)
            delayBufL[delayIdxL] = Float(melL + dR * fb)
            delayBufR[delayIdxR] = Float(melR + dL * fb)
            delayIdxL = (delayIdxL + 1) % delayLenL
            delayIdxR = (delayIdxR + 1) % delayLenR

            let wetGain: Double = (mapIdx == 1) ? 0.36 : 0.55
            let rawL = hydrophone + padL + abyssSweep + subWave + threatPulse + melL + dL * wetGain
            let rawR = hydrophone + padR + abyssSweep + subWave + threatPulse + melR + dR * wetGain

            let baseCut: Double = (mapIdx == 1) ? 0.42 : (mapIdx == 2 ? 0.24 : 0.16)
            let cutoff = max(0.06, baseCut - smoothedThreat * 0.09 + 0.04 * sin(musicTime * 0.25))
            masterLPL += (rawL - masterLPL) * cutoff
            masterLPR += (rawR - masterLPR) * cutoff

            leftBuf?[i] = Float(tanh(masterLPL))
            rightBuf?[i] = Float(tanh(masterLPR))
        }

        os_unfair_lock_lock(lockPtr)
        publishedMusicTime = musicTime
        if localCountdown != countdown {
            musicStartCountdownSamples = localCountdown
        }
        os_unfair_lock_unlock(lockPtr)
    }

    // MARK: - Crisp Tactile SFX Render (Dry Channel, Lock-Free Loop)

    private func triggerSFXOnAudioThread(_ kind: OceanSFXKind) {
        var slot = 0
        var oldest: Double = -1
        for i in 0..<sfxVoices.count {
            if !sfxVoices[i].active { slot = i; break }
            if sfxVoices[i].time > oldest { oldest = sfxVoices[i].time; slot = i }
        }
        var v = SFXVoice()
        v.active = true
        v.kind = kind
        v.time = 0
        switch kind {
        case .bite: v.duration = 0.11
        case .bigBite: v.duration = 0.18
        case .dash: v.duration = 0.24
        case .sharkWarning: v.duration = 0.95
        case .levelUp: v.duration = 0.62
        case .prank: v.duration = 0.40
        case .bubblePop: v.duration = 0.13
        case .pufferPuff: v.duration = 0.22
        case .jellyZap: v.duration = 0.30
        case .playerBump: v.duration = 0.16
        case .hurt: v.duration = 0.34
        case .touchConnect: v.duration = 0.55
        case .uiClick: v.duration = 0.055
        }
        sfxVoices[slot] = v
    }

    private func renderSFX(abl: UnsafeMutableAudioBufferListPointer, frames: Int) {
        guard abl.count >= 1 else { return }
        let leftBuf = abl[0].mData?.assumingMemoryBound(to: Float.self)
        let rightBuf = abl.count > 1 ? abl[1].mData?.assumingMemoryBound(to: Float.self) : nil

        os_unfair_lock_lock(lockPtr)
        let playSfx = sfxEnabledState
        var q0: OceanSFXKind? = nil
        var q1: OceanSFXKind? = nil
        var q2: OceanSFXKind? = nil
        var q3: OceanSFXKind? = nil
        if !pendingSFXQueue.isEmpty {
            if pendingSFXQueue.count >= 1 { q0 = pendingSFXQueue[0] }
            if pendingSFXQueue.count >= 2 { q1 = pendingSFXQueue[1] }
            if pendingSFXQueue.count >= 3 { q2 = pendingSFXQueue[2] }
            if pendingSFXQueue.count >= 4 { q3 = pendingSFXQueue[3] }
            pendingSFXQueue.removeAll(keepingCapacity: true)
        }
        os_unfair_lock_unlock(lockPtr)

        if playSfx {
            if let k = q0 { triggerSFXOnAudioThread(k) }
            if let k = q1 { triggerSFXOnAudioThread(k) }
            if let k = q2 { triggerSFXOnAudioThread(k) }
            if let k = q3 { triggerSFXOnAudioThread(k) }
        }

        if !playSfx {
            for i in 0..<frames { leftBuf?[i] = 0; rightBuf?[i] = 0 }
            return
        }

        let dt = 1.0 / sampleRate
        let twoPi = Double.pi * 2.0

        for i in 0..<frames {
            var mix: Double = 0
            for idx in 0..<sfxVoices.count {
                guard sfxVoices[idx].active else { continue }
                var v = sfxVoices[idx]
                let t = v.time
                let p = t / v.duration
                if p >= 1.0 {
                    v.active = false
                    sfxVoices[idx] = v
                    continue
                }

                var s: Double = 0
                switch v.kind {
                case .bite:
                    let freq = 480.0 + p * 620.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * (1.0 - p) * (1.0 - p) * 0.25

                case .bigBite:
                    let freq = 260.0 + p * 540.0
                    v.phase += twoPi * freq * dt
                    v.phase2 += twoPi * (freq * 1.5) * dt
                    s = (sin(v.phase) * 0.72 + sin(v.phase2) * 0.28) * (1.0 - p) * (1.0 - p * 0.6) * 0.30

                case .dash:
                    let freq = 220.0 + (1.0 - p) * 280.0
                    v.phase += twoPi * freq * dt
                    s = (nextNoise(&sfxRng) * 0.42 + sin(v.phase) * 0.30) * sin(p * Double.pi) * 0.22

                case .sharkWarning:
                    let freq = 185.0 - p * 12.0
                    v.phase += twoPi * freq * dt
                    v.phase2 += twoPi * (freq * 2.005) * dt
                    s = (sin(v.phase) * 0.82 + sin(v.phase2) * 0.22) * exp(-p * 3.4) * 0.28

                case .levelUp:
                    let notes: [Double] = [523.25, 659.25, 783.99, 1046.50]
                    let n = min(3, Int(p * 4.0))
                    let lp = p * 4.0 - Double(n)
                    v.phase += twoPi * notes[n] * dt
                    s = (sin(v.phase) * 0.78 + sin(v.phase * 2.0) * 0.22) * exp(-lp * 2.2) * (1.0 - p * 0.15) * 0.24

                case .prank:
                    let freq = 580.0 - p * 220.0 + sin(t * 38.0) * 85.0
                    v.phase += twoPi * max(90, freq) * dt
                    s = sin(v.phase) * (1.0 - p) * 0.23

                case .bubblePop:
                    let freq = 340.0 + p * p * 1400.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * sin(p * Double.pi) * 0.27

                case .pufferPuff:
                    let freq = 140.0 + p * 260.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * sin(p * Double.pi) * 0.25

                case .jellyZap:
                    let freq = 950.0 + sin(t * 95.0) * 420.0
                    v.phase += twoPi * freq * dt
                    s = (sin(v.phase) * 0.55 + nextNoise(&sfxRng) * 0.45) * (1.0 - p) * 0.26

                case .playerBump:
                    let freq = 210.0 - p * 85.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * (1.0 - p) * 0.26

                case .hurt:
                    let freq = 155.0 - p * 95.0
                    v.phase += twoPi * max(40, freq) * dt
                    s = (sin(v.phase) * 0.65 + nextNoise(&sfxRng) * 0.35) * (1.0 - p) * 0.32

                case .touchConnect:
                    let f1 = 587.33 + p * 15.0
                    let f2 = 880.00
                    v.phase += twoPi * f1 * dt
                    v.phase2 += twoPi * f2 * dt
                    let env = sin(min(1.0, p * 3.0) * Double.pi * 0.5) * exp(-p * 2.6)
                    s = (sin(v.phase) * 0.6 + sin(v.phase2) * 0.4) * env * 0.30

                case .uiClick:
                    v.phase += twoPi * 720.0 * dt
                    s = sin(v.phase) * (1.0 - p) * (1.0 - p) * 0.13
                }

                mix += s
                v.time += dt
                sfxVoices[idx] = v
            }

            let clamped = Float(tanh(mix))
            leftBuf?[i] = clamped
            rightBuf?[i] = clamped
        }
    }
}
