import SwiftUI
import SpriteKit
import MultipeerConnectivity
import QuartzCore

// MARK: - Game Coordinator

final class GameCoordinator: ObservableObject {
    @Published var phase: GamePhase = .menu
    @Published var selectedMap: MapTheme = .abyss {
        didSet {
            scene.setMap(selectedMap)
            sendMenuAudioSyncIfHost()
        }
    }
    @Published var selectedMode: GameMode = .solo
    @Published var selectedRule: GameRuleMode = .timed
    @Published var stereoDuetEnabled: Bool = true {
        didSet {
            scene.stereoDuetEnabled = stereoDuetEnabled
            updateLocalMenuDuetRole()
            sendMenuAudioSyncIfHost()
        }
    }
    @Published var hud = HudState()
    @Published var roundResult: RoundResult? = nil
    @Published var dpadVisual = DPadVisualState()

    @Published var musicEnabled: Bool = true {
        didSet { AtmosphericAudioEngine.shared.isMusicEnabled = musicEnabled }
    }
    @Published var sfxEnabled: Bool = true {
        didSet { AtmosphericAudioEngine.shared.isSFXEnabled = sfxEnabled }
    }
    @Published var hapticsEnabled: Bool = true {
        didSet { HapticManager.shared.isEnabled = hapticsEnabled }
    }

    @Published var showTouchConnectOverlay: Bool = false
    // Series score lives only for the current app session: a fresh launch starts at 0 : 0.
    @Published var seriesP1: Int = 0
    @Published var seriesP2: Int = 0

    let multipeer = MultipeerManager()
    let scene: OceanScene

    private var pendingSyncLaunch: Bool = false
    private var syncFallbackWorkItem: DispatchWorkItem? = nil
    private var periodicSyncTimer: Timer? = nil

    init() {
        scene = OceanScene(size: CGSize(width: OceanScene.worldWidth, height: OceanScene.worldHeight))
        scene.stereoDuetEnabled = stereoDuetEnabled
        wireCallbacks()
        startPeriodicSyncTimer()
    }

    deinit {
        periodicSyncTimer?.invalidate()
    }

    private func startPeriodicSyncTimer() {
        // Keeps RTT measurement & menu/match music clock phase-locked between both iPhones!
        periodicSyncTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in
            guard let self = self, self.multipeer.isConnected else { return }
            if self.multipeer.role == .host {
                self.multipeer.send(.syncPing(CACurrentMediaTime()), reliable: false)
                if self.phase == .menu {
                    self.sendMenuAudioSyncIfHost()
                }
            }
        }
    }

    private func updateLocalMenuDuetRole() {
        guard multipeer.isConnected else {
            AtmosphericAudioEngine.shared.setDuetRole(.solo)
            return
        }
        if !stereoDuetEnabled {
            AtmosphericAudioEngine.shared.setDuetRole(.solo)
        } else {
            AtmosphericAudioEngine.shared.setDuetRole(multipeer.role == .host ? .hostDuet : .guestDuet)
        }
    }

    private func sendMenuAudioSyncIfHost() {
        guard multipeer.isConnected && multipeer.role == .host && phase == .menu else { return }
        updateLocalMenuDuetRole()
        multipeer.send(
            .menuMusicSync(
                map: selectedMap,
                stereoDuet: stereoDuetEnabled,
                musicTime: AtmosphericAudioEngine.shared.currentMusicTime
            ),
            reliable: false
        )
    }

    private func wireCallbacks() {
        scene.onHudUpdate = { [weak self] newHud in
            DispatchQueue.main.async { self?.hud = newHud }
        }

        scene.onRoundOver = { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.seriesP1 = result.seriesP1
                self.seriesP2 = result.seriesP2
                self.roundResult = result
                self.phase = .roundOver
                if self.selectedMode == .multiplayer && self.multipeer.role == .host {
                    self.multipeer.send(.roundOver(result), reliable: true)
                }
            }
        }

        scene.onSendSnapshot = { [weak self] snap in
            self?.multipeer.send(.snapshot(snap), reliable: false)
        }
        scene.onSendEvent = { [weak self] ev in
            self?.multipeer.send(.event(ev), reliable: true)
        }
        scene.onSendGuestInput = { [weak self] input in
            self?.multipeer.send(.input(input), reliable: false)
        }

        multipeer.onTouchConnectCompleted = { [weak self] in
            guard let self = self else { return }
            self.selectedMode = .multiplayer
            if self.multipeer.role == .host && self.phase == .menu {
                self.launchMatchWithAudioSync()
            }
        }

        multipeer.onReceiveMessage = { [weak self] message in
            guard let self = self else { return }
            switch message {
            case .syncPing(let t0):
                self.multipeer.send(.syncPong(t0), reliable: false)

            case .syncPong(let t0):
                let rtt = max(0.0, min(0.24, CACurrentMediaTime() - t0))
                self.scene.estimatedHalfRTT = rtt * 0.5
                if self.pendingSyncLaunch {
                    self.pendingSyncLaunch = false
                    self.syncFallbackWorkItem?.cancel()
                    self.executeHostLaunch(rttSeconds: rtt)
                }

            case .menuMusicSync(let map, let duet, let hostTime):
                guard self.phase == .menu else { return }
                if self.selectedMap != map {
                    self.selectedMap = map
                }
                self.stereoDuetEnabled = duet
                let role: StereoDuetRole = duet ? .guestDuet : .solo
                AtmosphericAudioEngine.shared.syncMusicPhase(
                    targetHostTime: hostTime + self.scene.estimatedHalfRTT,
                    role: role,
                    map: map
                )

            case .startMatch(let map, let rule, let duet, let s1, let s2, let musicDelay):
                self.selectedMode = .multiplayer
                self.selectedMap = map
                self.selectedRule = rule
                self.stereoDuetEnabled = duet
                self.seriesP1 = s1
                self.seriesP2 = s2
                self.showTouchConnectOverlay = false
                self.roundResult = nil
                self.phase = .playing

                let role: StereoDuetRole = duet ? .guestDuet : .solo
                AtmosphericAudioEngine.shared.scheduleSynchronizedStart(
                    delaySeconds: musicDelay,
                    role: role,
                    map: map
                )
                self.scene.startMatch(mode: .multiplayer, rule: rule, map: map, isGuest: true, seriesP1: s1, seriesP2: s2)

            case .input(let packet):
                self.scene.receiveGuestInput(packet)

            case .snapshot(let snap):
                self.scene.receiveSnapshot(snap)

            case .event(let ev):
                self.scene.receiveNetworkEvent(ev)

            case .roundOver(let res):
                self.seriesP1 = res.seriesP1
                self.seriesP2 = res.seriesP2
                self.roundResult = res
                self.phase = .roundOver

            case .returnToMenu:
                self.goToMenuLocal()

            case .discoveryToken, .touchConnectTrigger:
                break
            }
        }

        multipeer.onDisconnect = { [weak self] in
            guard let self = self else { return }
            AtmosphericAudioEngine.shared.setDuetRole(.solo)
            if self.phase != .menu {
                self.goToMenuLocal()
            }
        }
    }

    func startPressed() {
        HapticManager.shared.playUIClick()
        AtmosphericAudioEngine.shared.start()

        if selectedMode == .multiplayer {
            if !multipeer.isConnected || multipeer.role == .guest {
                openTouchConnect()
                return
            }
            launchMatchWithAudioSync()
        } else {
            launchSoloMatch()
        }
    }

    func openTouchConnect() {
        HapticManager.shared.playUIClick()
        showTouchConnectOverlay = true
        multipeer.startAutoDiscovery()
    }

    func closeTouchConnect() {
        HapticManager.shared.playUIClick()
        showTouchConnectOverlay = false
        if !multipeer.isConnected {
            multipeer.stopAll()
        }
    }

    private func launchSoloMatch() {
        roundResult = nil
        showTouchConnectOverlay = false
        phase = .playing
        AtmosphericAudioEngine.shared.setDuetRole(.solo)
        AtmosphericAudioEngine.shared.setMap(selectedMap)
        AtmosphericAudioEngine.shared.start()
        scene.startMatch(mode: .solo, rule: selectedRule, map: selectedMap, isGuest: false, seriesP1: seriesP1, seriesP2: seriesP2)
    }

    func launchMatchWithAudioSync() {
        guard selectedMode == .multiplayer && multipeer.isConnected else {
            launchSoloMatch()
            return
        }
        pendingSyncLaunch = true
        multipeer.send(.syncPing(CACurrentMediaTime()), reliable: true)

        syncFallbackWorkItem?.cancel()
        let fallback = DispatchWorkItem { [weak self] in
            guard let self = self, self.pendingSyncLaunch else { return }
            self.pendingSyncLaunch = false
            self.executeHostLaunch(rttSeconds: 0.04)
        }
        syncFallbackWorkItem = fallback
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: fallback)
    }

    private func executeHostLaunch(rttSeconds: Double) {
        roundResult = nil
        showTouchConnectOverlay = false
        phase = .playing

        let hostDelay = 0.22
        let guestDelay = max(0.02, hostDelay - rttSeconds * 0.5)

        multipeer.send(
            .startMatch(
                map: selectedMap,
                ruleMode: selectedRule,
                stereoDuet: stereoDuetEnabled,
                seriesP1: seriesP1,
                seriesP2: seriesP2,
                musicDelay: guestDelay
            ),
            reliable: true
        )

        let hostRole: StereoDuetRole = stereoDuetEnabled ? .hostDuet : .solo
        AtmosphericAudioEngine.shared.scheduleSynchronizedStart(
            delaySeconds: hostDelay,
            role: hostRole,
            map: selectedMap
        )

        scene.startMatch(
            mode: .multiplayer,
            rule: selectedRule,
            map: selectedMap,
            isGuest: false,
            seriesP1: seriesP1,
            seriesP2: seriesP2
        )
    }

    func exitToMenu() {
        HapticManager.shared.playUIClick()
        if selectedMode == .multiplayer && multipeer.isConnected {
            multipeer.send(.returnToMenu, reliable: true)
        }
        goToMenuLocal()
    }

    private func goToMenuLocal() {
        phase = .menu
        roundResult = nil
        dpadVisual = DPadVisualState()
        multipeer.resetTouchArm()
        updateLocalMenuDuetRole()
        scene.returnToMenu()
    }
}

// MARK: - Root View

struct ContentView: View {
    @StateObject private var game = GameCoordinator()

    var body: some View {
        ZStack {
            SpriteView(scene: game.scene, preferredFramesPerSecond: 120)
                .ignoresSafeArea()

            if game.phase == .playing {
                GameplayOverlayView(game: game)
            } else if game.phase == .menu {
                MainMenuOverlayView(game: game)
                    .transition(.opacity.combined(with: .scale(scale: 0.97)))
            } else if game.phase == .roundOver, let result = game.roundResult {
                RoundOverOverlayView(game: game, result: result)
                    .transition(.opacity.combined(with: .scale(scale: 0.95)))
            }

            if game.showTouchConnectOverlay && game.phase == .menu {
                TouchConnectOverlayView(game: game, multipeer: game.multipeer)
                    .transition(.opacity)
            }

            if game.multipeer.touchWaveActive {
                TouchMagicWaveView()
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }
        }
        .animation(.easeInOut(duration: 0.28), value: game.phase)
        .animation(.easeInOut(duration: 0.24), value: game.showTouchConnectOverlay)
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .onAppear {
            HapticManager.shared.prepare()
            AtmosphericAudioEngine.shared.setMap(game.selectedMap)
            AtmosphericAudioEngine.shared.start()
        }
    }
}

// MARK: - Glassmorphic Main Menu v2.1

private struct MainMenuOverlayView: View {
    @ObservedObject var game: GameCoordinator
    @ObservedObject var multipeer: MultipeerManager

    init(game: GameCoordinator) {
        self.game = game
        self.multipeer = game.multipeer
    }

    var body: some View {
        ZStack {
            VStack {
                HStack {
                    if multipeer.isConnected, let peer = multipeer.connectedPeer {
                        Button {
                            game.openTouchConnect()
                        } label: {
                            HStack(spacing: 7) {
                                Circle().fill(Color.green).frame(width: 8, height: 8)
                                Text(peer.displayName)
                                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                                    .lineLimit(1)
                            }
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(.ultraThinMaterial, in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.28), lineWidth: 1))
                        }
                    }

                    Spacer()

                    HStack(spacing: 9) {
                        Button {
                            game.stereoDuetEnabled.toggle()
                            HapticManager.shared.playUIClick()
                        } label: {
                            HStack(spacing: 5) {
                                Image(systemName: "hifispeaker.2.fill")
                                    .font(.system(size: 13, weight: .semibold))
                                Text("Дуэт")
                                    .font(.system(size: 12, weight: .bold, design: .rounded))
                            }
                            .foregroundColor(game.stereoDuetEnabled ? Color(red: 0.56, green: 0.94, blue: 1.0) : .white.opacity(0.45))
                            .padding(.horizontal, 11)
                            .frame(height: 36)
                            .background(.ultraThinMaterial, in: Capsule())
                            .overlay(Capsule().stroke(game.stereoDuetEnabled ? Color(red: 0.48, green: 0.90, blue: 1.0).opacity(0.55) : Color.white.opacity(0.15), lineWidth: 1))
                        }

                        CircleIconToggle(icon: game.musicEnabled ? "music.note" : "music.note.list", active: game.musicEnabled) {
                            game.musicEnabled.toggle()
                            HapticManager.shared.playUIClick()
                            AtmosphericAudioEngine.shared.start()
                        }
                        CircleIconToggle(icon: game.sfxEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill", active: game.sfxEnabled) {
                            game.sfxEnabled.toggle()
                            HapticManager.shared.playUIClick()
                        }
                        CircleIconToggle(icon: "iphone.radiowaves.left.and.right", active: game.hapticsEnabled) {
                            game.hapticsEnabled.toggle()
                            if game.hapticsEnabled { HapticManager.shared.playUIClick() }
                        }
                    }
                }
                .padding(.horizontal, 22)
                .padding(.top, 12)

                Spacer()
            }

            VStack(spacing: 13) {
                HStack(spacing: 9) {
                    Image("fish_p1_gold")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 38, height: 28)
                    Text("ГЛУБИНА")
                        .font(.system(size: 29, weight: .black, design: .rounded))
                        .tracking(3.5)
                        .foregroundColor(.white)
                }

                HStack(spacing: 10) {
                    ForEach(MapTheme.allCases) { map in
                        MapPhotoCard(map: map, isSelected: game.selectedMap == map) {
                            HapticManager.shared.playUIClick()
                            AtmosphericAudioEngine.shared.playSFX(.uiClick)
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                                game.selectedMap = map
                            }
                        }
                    }
                }

                HStack(spacing: 8) {
                    HStack(spacing: 4) {
                        ForEach(GameMode.allCases) { mode in
                            SegmentPillButton(
                                title: mode.title,
                                icon: mode == .solo ? "person.fill" : "wave.3.right",
                                selected: game.selectedMode == mode
                            ) {
                                HapticManager.shared.playUIClick()
                                AtmosphericAudioEngine.shared.playSFX(.uiClick)
                                withAnimation(.spring(response: 0.26, dampingFraction: 0.8)) {
                                    game.selectedMode = mode
                                }
                            }
                        }
                    }
                    .padding(3)
                    .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                    HStack(spacing: 4) {
                        ForEach(GameRuleMode.allCases) { rule in
                            SegmentPillButton(
                                title: rule.title,
                                icon: rule.icon,
                                selected: game.selectedRule == rule
                            ) {
                                HapticManager.shared.playUIClick()
                                AtmosphericAudioEngine.shared.playSFX(.uiClick)
                                withAnimation(.spring(response: 0.26, dampingFraction: 0.8)) {
                                    game.selectedRule = rule
                                }
                            }
                        }
                    }
                    .padding(3)
                    .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                }

                Button {
                    game.startPressed()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: primaryButtonIcon)
                            .font(.system(size: 15, weight: .bold))
                        Text(primaryButtonTitle)
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .tracking(1.2)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(
                        LinearGradient(
                            colors: [game.selectedMap.accentColor, Color(red: 0.10, green: 0.42, blue: 0.94)],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
                    )
                    .shadow(color: game.selectedMap.accentColor.opacity(0.45), radius: 10, y: 4)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .frame(width: 446)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .stroke(Color.white.opacity(0.24), lineWidth: 1.1)
            )
            .shadow(color: .black.opacity(0.35), radius: 26, y: 12)
        }
    }

    private var primaryButtonTitle: String {
        if game.selectedMode == .multiplayer {
            if !multipeer.isConnected { return "ПОДКЛЮЧИТЬСЯ" }
            if multipeer.role == .guest { return "ЖДЁМ СТАРТА..." }
        }
        return "ИГРАТЬ"
    }

    private var primaryButtonIcon: String {
        if game.selectedMode == .multiplayer && !multipeer.isConnected {
            return "iphone.gen3.radiowaves.left.and.right"
        }
        return "play.fill"
    }
}

private struct MapPhotoCard: View {
    let map: MapTheme
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack(alignment: .bottomLeading) {
                Image(map.backgroundImageName)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 62)
                    .clipped()

                LinearGradient(colors: [.clear, Color.black.opacity(0.68)], startPoint: .top, endPoint: .bottom)

                HStack(spacing: 5) {
                    Image(systemName: map.icon)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(map.accentColor)
                    Text(map.title)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .lineLimit(1)
                }
                .padding(.horizontal, 8)
                .padding(.bottom, 6)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(isSelected ? Color.white : Color.white.opacity(0.18), lineWidth: isSelected ? 2.2 : 1.0)
            )
            .scaleEffect(isSelected ? 1.03 : 0.98)
        }
    }
}

private struct SegmentPillButton: View {
    let title: String
    let icon: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 11, weight: .bold))
                Text(title)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .padding(.horizontal, 6)
            .foregroundColor(selected ? Color(red: 0.04, green: 0.12, blue: 0.22) : .white.opacity(0.84))
            .background(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(selected ? Color.white : Color.clear)
            )
        }
    }
}

private struct CircleIconToggle: View {
    let icon: String
    let active: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(active ? .white : .white.opacity(0.42))
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(active ? 0.30 : 0.14), lineWidth: 1))
        }
    }
}

// MARK: - Touch-to-Connect Overlay

private struct TouchConnectOverlayView: View {
    @ObservedObject var game: GameCoordinator
    @ObservedObject var multipeer: MultipeerManager
    @State private var pulse: Bool = false

    var body: some View {
        ZStack {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
                .onTapGesture { game.closeTouchConnect() }

            VStack(spacing: 14) {
                HStack {
                    Spacer()
                    Button { game.closeTouchConnect() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white.opacity(0.8))
                            .frame(width: 30, height: 30)
                            .background(Color.white.opacity(0.14), in: Circle())
                    }
                }
                .padding(.bottom, -14)

                ZStack {
                    ForEach(0..<3, id: \.self) { ring in
                        Circle()
                            .stroke(
                                LinearGradient(colors: [Color.cyan.opacity(0.65), Color.purple.opacity(0.35)], startPoint: .top, endPoint: .bottom),
                                lineWidth: 1.8
                            )
                            .frame(width: 64 + CGFloat(ring) * 28, height: 64 + CGFloat(ring) * 28)
                            .scaleEffect(pulse ? 1.15 : 0.92)
                            .opacity(pulse ? 0.25 : 0.72)
                            .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(Double(ring) * 0.22), value: pulse)
                    }

                    Image(systemName: multipeer.isConnected ? "iphone.radiowaves.left.and.right.circle.fill" : "wave.3.right.circle.fill")
                        .font(.system(size: 46))
                        .foregroundStyle(
                            LinearGradient(colors: [Color(red: 0.42, green: 0.92, blue: 1.0), Color(red: 0.48, green: 0.52, blue: 1.0)], startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                }
                .frame(height: 112)

                Text(multipeer.statusText)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)

                if let dist = multipeer.distanceMeters {
                    let cm = max(1, Int(round(dist * 100)))
                    Text("Дистанция: \(cm) см")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .monospacedDigit()
                        .foregroundColor(cm <= 22 ? Color(red: 0.45, green: 1.0, blue: 0.72) : Color.cyan)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color.black.opacity(0.28), in: Capsule())
                }

                if multipeer.isConnected {
                    if multipeer.role == .host {
                        Button {
                            HapticManager.shared.playTouchConnect()
                            game.launchMatchWithAudioSync()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "play.fill")
                                Text("Начать с дивана")
                            }
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                            .background(Color.blue.opacity(0.85), in: Capsule())
                        }
                    } else {
                        Text("Коснитесь телефонами или ждите старта от хоста")
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundColor(.white.opacity(0.70))
                    }
                } else {
                    Text("Откройте «Вдвоём» на обоих iPhone")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.68))
                }
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 18)
            .frame(width: 356)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.28), lineWidth: 1.2))
            .shadow(color: .black.opacity(0.45), radius: 28, y: 12)
            .onAppear { pulse = true }
        }
    }
}

private struct TouchMagicWaveView: View {
    @State private var expand = false

    var body: some View {
        RoundedRectangle(cornerRadius: 36, style: .continuous)
            .stroke(
                LinearGradient(colors: [Color.cyan, Color(red: 1.0, green: 0.85, blue: 0.35), Color.purple], startPoint: .topLeading, endPoint: .bottomTrailing),
                lineWidth: expand ? 4 : 26
            )
            .blur(radius: expand ? 18 : 6)
            .opacity(expand ? 0.0 : 0.95)
            .onAppear {
                withAnimation(.easeOut(duration: 0.55)) { expand = true }
            }
    }
}

// MARK: - In-Game HUD & Crisp 4-Way Cross D-Pad

private struct GameplayOverlayView: View {
    @ObservedObject var game: GameCoordinator

    var body: some View {
        ZStack {
            if game.hud.dangerProximityLocal > 0.16 {
                RoundedRectangle(cornerRadius: 0)
                    .stroke(Color.red.opacity(Double(game.hud.dangerProximityLocal) * 0.50), lineWidth: 24)
                    .blur(radius: 14)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }

            if game.hud.inkTimerLocal > 0 {
                InkSplatOverlay(opacity: min(1.0, Double(game.hud.inkTimerLocal) / 0.8))
                    .allowsHitTesting(false)
            }

            GeometryReader { geo in
                let leftInset = max(geo.safeAreaInsets.leading, 20)
                let rightInset = max(geo.safeAreaInsets.trailing, 20)
                let bottomInset = max(geo.safeAreaInsets.bottom, 16)

                DashVisualButton(
                    cooldown: game.hud.dashCooldownLocal,
                    pressed: game.dpadVisual.dashPressed
                )
                .position(x: leftInset + 54, y: geo.size.height - bottomInset - 54)

                DPadCrossVisualView(
                    state: game.dpadVisual,
                    inverted: game.hud.invertTimerLocal > 0
                )
                .position(x: geo.size.width - rightInset - 88, y: geo.size.height - bottomInset - 88)
            }
            .ignoresSafeArea()
            .allowsHitTesting(false)

            MultiTouchControlsOverlay { dx, dy, dash, visual in
                game.scene.updateLocalInput(dx: dx, dy: dy, dashPressed: dash)
                if game.dpadVisual != visual {
                    game.dpadVisual = visual
                }
            }
            .ignoresSafeArea()

            VStack(spacing: 8) {
                HStack(spacing: 12) {
                    PlayerHudPill(
                        label: game.multipeer.role == .guest ? "ПАРТНЁР" : "ТЫ",
                        color: Color(red: 1.0, green: 0.84, blue: 0.28),
                        score: game.hud.scoreP1,
                        level: game.hud.levelP1,
                        lives: game.hud.livesP1
                    )

                    Spacer()

                    VStack(spacing: 1) {
                        HStack(spacing: 4) {
                            if game.hud.ruleMode == .survival {
                                Image(systemName: "infinity")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(.cyan)
                            }
                            Text(formatTime(game.hud.timeValue))
                                .font(.system(size: 17, weight: .heavy, design: .rounded))
                                .monospacedDigit()
                                .foregroundColor(
                                    (game.hud.ruleMode == .timed && game.hud.timeValue < 15)
                                        ? Color(red: 1.0, green: 0.45, blue: 0.45) : .white
                                )
                        }
                        Text("\(game.seriesP1) : \(game.seriesP2)")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.70))
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 5)
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.22), lineWidth: 1))

                    Spacer()

                    PlayerHudPill(
                        label: game.multipeer.role == .guest ? "ТЫ" : (game.selectedMode == .solo ? "БОТ" : "ПАРТНЁР"),
                        color: Color(red: 1.0, green: 0.42, blue: 0.70),
                        score: game.hud.scoreP2,
                        level: game.hud.levelP2,
                        lives: game.hud.livesP2
                    )

                    Button {
                        game.exitToMenu()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 34, height: 34)
                            .background(.ultraThinMaterial, in: Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.24), lineWidth: 1))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)

                if let text = game.hud.bannerText, let emoji = game.hud.bannerEmoji {
                    HStack(spacing: 6) {
                        Text(emoji)
                        Text(text)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(Color.purple.opacity(0.72), in: Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.35), lineWidth: 1))
                    .transition(.move(edge: .top).combined(with: .opacity))
                }

                if game.selectedMode == .multiplayer {
                    let myLives = (game.multipeer.role == .guest) ? game.hud.livesP2 : game.hud.livesP1
                    let partnerLives = (game.multipeer.role == .guest) ? game.hud.livesP1 : game.hud.livesP2
                    if myLives <= 0 || partnerLives <= 0 {
                        Text(myLives <= 0 ? "Ты выбыл. Смотри, как партнёр доигрывает" : "Партнёр выбыл. Играй дальше и набирай очки!")
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 6)
                            .background(Color.black.opacity(0.45), in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.28), lineWidth: 1))
                    }
                }

                Spacer()
            }
        }
    }

    private func formatTime(_ seconds: Float) -> String {
        let s = max(0, Int(seconds))
        return String(format: "%d:%02d", s / 60, s % 60)
    }
}

private struct PlayerHudPill: View {
    let label: String
    let color: Color
    let score: Int
    let level: Int
    let lives: Int

    var body: some View {
        HStack(spacing: 8) {
            Circle().fill(color).frame(width: 10, height: 10).shadow(color: color, radius: 4)

            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 5) {
                    Text(label)
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .foregroundColor(.white.opacity(0.75))
                    Text("Ур.\(level)")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundColor(color)
                }
                HStack(spacing: 3) {
                    ForEach(0..<GameConfig.maxLives, id: \.self) { idx in
                        Image(systemName: idx < lives ? "heart.fill" : "heart")
                            .font(.system(size: 9))
                            .foregroundColor(idx < lives ? Color(red: 1.0, green: 0.35, blue: 0.45) : .white.opacity(0.28))
                    }
                }
            }

            Text("\(score)")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .monospacedDigit()
                .foregroundColor(.white)
                .frame(minWidth: 26, alignment: .trailing)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(color.opacity(0.45), lineWidth: 1.2))
    }
}

private struct DashVisualButton: View {
    let cooldown: Float
    let pressed: Bool

    var body: some View {
        let ready = cooldown <= 0.05
        let progress = CGFloat(1.0 - min(1.0, cooldown / 2.5))

        ZStack {
            Circle().fill(.ultraThinMaterial).opacity(pressed ? 0.95 : 0.66)
            Circle().stroke(Color.white.opacity(0.20), lineWidth: 3)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(ready ? Color(red: 1.0, green: 0.86, blue: 0.25) : Color.cyan.opacity(0.75), style: StrokeStyle(lineWidth: 3.4, lineCap: .round))
                .rotationEffect(.degrees(-90))

            Image(systemName: "bolt.fill")
                .font(.system(size: 25, weight: .bold))
                .foregroundColor(ready ? Color(red: 1.0, green: 0.90, blue: 0.35) : .white.opacity(0.42))
        }
        .frame(width: 76, height: 76)
        .scaleEffect(pressed ? 0.91 : 1.0)
        .animation(.easeOut(duration: 0.08), value: pressed)
    }
}

private struct DPadCrossVisualView: View {
    let state: DPadVisualState
    let inverted: Bool

    var body: some View {
        ZStack {
            // Subtle cross guide arms so thumb intuitively feels the 4 cardinal buttons
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.ultraThinMaterial)
                .opacity(0.50)
                .frame(width: 54, height: 152)
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(inverted ? Color.purple.opacity(0.8) : Color.white.opacity(0.22), lineWidth: 1.2)
                )

            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.ultraThinMaterial)
                .opacity(0.50)
                .frame(width: 152, height: 54)
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(inverted ? Color.purple.opacity(0.8) : Color.white.opacity(0.22), lineWidth: 1.2)
                )

            ArrowKeyCap(symbol: "chevron.up", active: state.up).offset(y: -49)
            ArrowKeyCap(symbol: "chevron.down", active: state.down).offset(y: 49)
            ArrowKeyCap(symbol: "chevron.left", active: state.left).offset(x: -49)
            ArrowKeyCap(symbol: "chevron.right", active: state.right).offset(x: 49)

            if inverted {
                Text("🔄").font(.system(size: 16))
            } else {
                Circle().fill(Color.white.opacity(0.18)).frame(width: 12, height: 12)
            }
        }
        .frame(width: 156, height: 156)
    }
}

private struct ArrowKeyCap: View {
    let symbol: String
    let active: Bool

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: 20, weight: .heavy))
            .foregroundColor(active ? Color(red: 0.05, green: 0.16, blue: 0.28) : .white.opacity(0.88))
            .frame(width: 46, height: 46)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(active ? Color.white.opacity(0.95) : Color.white.opacity(0.14)))
            .scaleEffect(active ? 1.07 : 1.0)
            .animation(.easeOut(duration: 0.06), value: active)
    }
}

private struct InkSplatOverlay: View {
    let opacity: Double

    var body: some View {
        GeometryReader { geo in
            ZStack {
                InkBlob(x: 0.24, y: 0.30, r: 105, size: geo.size)
                InkBlob(x: 0.52, y: 0.48, r: 135, size: geo.size)
                InkBlob(x: 0.76, y: 0.34, r: 95, size: geo.size)
                InkBlob(x: 0.38, y: 0.72, r: 90, size: geo.size)
                InkBlob(x: 0.66, y: 0.68, r: 100, size: geo.size)
            }
            .opacity(opacity * 0.92)
        }
        .ignoresSafeArea()
    }
}

private struct InkBlob: View {
    let x: CGFloat
    let y: CGFloat
    let r: CGFloat
    let size: CGSize

    var body: some View {
        ZStack {
            Circle().fill(Color(red: 0.04, green: 0.02, blue: 0.10)).frame(width: r * 1.6, height: r * 1.4)
            Capsule().fill(Color(red: 0.04, green: 0.02, blue: 0.10)).frame(width: r * 0.22, height: r * 1.2).offset(x: -r * 0.25, y: r * 0.65)
            Capsule().fill(Color(red: 0.04, green: 0.02, blue: 0.10)).frame(width: r * 0.16, height: r * 0.95).offset(x: r * 0.30, y: r * 0.55)
        }
        .position(x: size.width * x, y: size.height * y)
    }
}

// MARK: - Round Over Glass Card (Shows Honest Score + Eaten Fish Count!)

private struct RoundOverOverlayView: View {
    @ObservedObject var game: GameCoordinator
    let result: RoundResult

    var body: some View {
        let isGuest = (game.multipeer.role == .guest)
        let headline: String = {
            if result.winnerIndex == -1 { return "Ничья!" }
            if isGuest {
                return result.winnerIndex == 1 ? "Победа!" : "Победил партнёр!"
            } else {
                if result.winnerIndex == 0 { return "Победа!" }
                return game.selectedMode == .solo ? "Победил бот" : "Победил партнёр!"
            }
        }()

        VStack(spacing: 13) {
            Text(headline)
                .font(.system(size: 27, weight: .black, design: .rounded))
                .foregroundColor(.white)

            HStack(spacing: 14) {
                ResultPlayerColumn(
                    name: isGuest ? "Партнёр" : "Ты",
                    color: Color(red: 1.0, green: 0.84, blue: 0.28),
                    score: result.scoreP1,
                    bites: result.bitesP1,
                    level: result.levelP1,
                    title: result.titleP1,
                    won: result.winnerIndex == 0
                )
                ResultPlayerColumn(
                    name: isGuest ? "Ты" : (game.selectedMode == .solo ? "Бот" : "Партнёр"),
                    color: Color(red: 1.0, green: 0.42, blue: 0.70),
                    score: result.scoreP2,
                    bites: result.bitesP2,
                    level: result.levelP2,
                    title: result.titleP2,
                    won: result.winnerIndex == 1
                )
            }

            HStack(spacing: 16) {
                Text("Серия: \(result.seriesP1) : \(result.seriesP2)")
                if result.ruleMode == .survival {
                    Text("•  Время: \(result.durationSeconds / 60):\(String(format: "%02d", result.durationSeconds % 60))")
                }
            }
            .font(.system(size: 13, weight: .bold, design: .rounded))
            .foregroundColor(.white.opacity(0.84))

            HStack(spacing: 12) {
                Button {
                    game.exitToMenu()
                } label: {
                    Text("Меню")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(Color.white.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
                }

                if !isGuest {
                    Button {
                        game.launchMatchWithAudioSync()
                    } label: {
                        Text("Ещё раунд")
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 11)
                            .background(
                                LinearGradient(
                                    colors: [game.selectedMap.accentColor, Color(red: 0.10, green: 0.42, blue: 0.94)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                in: RoundedRectangle(cornerRadius: 14)
                            )
                    }
                }
            }
        }
        .padding(22)
        .frame(width: 416)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.28), lineWidth: 1.2))
        .shadow(color: .black.opacity(0.36), radius: 26, y: 12)
    }
}

private struct ResultPlayerColumn: View {
    let name: String
    let color: Color
    let score: Int
    let bites: Int
    let level: Int
    let title: String
    let won: Bool

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                if won { Text("👑") }
                Text(name)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(color)
            }
            Text("\(score) очк.")
                .font(.system(size: 23, weight: .black, design: .rounded))
                .foregroundColor(.white)
            Text("Рыбок: \(bites) • Ур.\(level)")
                .font(.system(size: 11.5, weight: .bold, design: .rounded))
                .foregroundColor(.white.opacity(0.86))
            Text(title)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundColor(.white.opacity(0.72))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .padding(.horizontal, 8)
        .background(Color.black.opacity(0.24), in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(won ? color.opacity(0.75) : Color.white.opacity(0.12), lineWidth: won ? 1.6 : 1)
        )
    }
}
