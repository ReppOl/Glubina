import Foundation
import CoreHaptics
import QuartzCore
import UIKit

final class HapticManager {
    static let shared = HapticManager()

    var isEnabled: Bool = true
    private var engine: CHHapticEngine?
    private var supportsHaptics: Bool = false
    private var lastHeartbeatTime: TimeInterval = 0
    private var lastClickTime: TimeInterval = 0

    private let lightImpact = UIImpactFeedbackGenerator(style: .light)
    private let mediumImpact = UIImpactFeedbackGenerator(style: .medium)
    private let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)

    private init() {
        supportsHaptics = CHHapticEngine.capabilitiesForHardware().supportsHaptics
        prepare()
    }

    func prepare() {
        lightImpact.prepare()
        mediumImpact.prepare()
        heavyImpact.prepare()

        guard supportsHaptics else { return }
        do {
            let newEngine = try CHHapticEngine()
            newEngine.isAutoShutdownEnabled = true
            newEngine.stoppedHandler = { [weak self] _ in
                self?.restartEngineIfNeeded()
            }
            newEngine.resetHandler = { [weak self] in
                self?.restartEngineIfNeeded()
            }
            try newEngine.start()
            engine = newEngine
        } catch {
            engine = nil
        }
    }

    private func restartEngineIfNeeded() {
        guard supportsHaptics else { return }
        DispatchQueue.main.async { [weak self] in
            do {
                try self?.engine?.start()
            } catch {
                self?.prepare()
            }
        }
    }

    private func playPattern(_ events: [CHHapticEvent], curves: [CHHapticParameterCurve] = []) {
        guard isEnabled, supportsHaptics else { return }
        if engine == nil { prepare() }
        guard let engine = engine else { return }

        do {
            try engine.start()
            let pattern = try CHHapticPattern(events: events, parameterCurves: curves)
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: CHHapticTimeImmediate)
        } catch {
            // Safe ignore during background transitions
        }
    }

    /// Subtle crisp keyboard-like click when eating small fish
    func playBite() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.45)
            return
        }
        let event = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.44),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.90)
            ],
            relativeTime: 0
        )
        playPattern([event])
    }

    /// Richer double-crunch when eating a bigger fish (Angelfish / Barracuda / Shark)
    func playBigBite() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.72)
            return
        }
        let e1 = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.65),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.78)
        ], relativeTime: 0)
        let e2 = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.48),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.55)
        ], relativeTime: 0.055)
        playPattern([e1, e2])
    }

    /// Distant low rumble swelling and fading when a shark or leviathan appears on the horizon
    func playSharkWarning() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.55)
            return
        }
        let rumble = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.58),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.14)
            ],
            relativeTime: 0,
            duration: 0.78
        )
        let curve = CHHapticParameterCurve(
            parameterID: .hapticIntensityControl,
            controlPoints: [
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.0, value: 0.10),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.36, value: 0.82),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.78, value: 0.04)
            ],
            relativeTime: 0
        )
        playPattern([rumble], curves: [curve])
    }

    /// Subtle underwater heartbeat (lub-dub) as a major threat gets close
    func playSharkHeartbeat(proximity: Float) {
        guard isEnabled, proximity > 0.12 else { return }
        let now = CACurrentMediaTime()
        let interval = Double(max(0.48, 1.05 - proximity * 0.55))
        guard now - lastHeartbeatTime >= interval else { return }
        lastHeartbeatTime = now

        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: CGFloat(min(1.0, 0.25 + proximity * 0.5)))
            return
        }

        let level = min(0.70, 0.20 + proximity * 0.48)
        let beat1 = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: level),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.20)
        ], relativeTime: 0.0)
        let beat2 = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: level * 0.72),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.16)
        ], relativeTime: 0.15)
        playPattern([beat1, beat2])
    }

    /// Magnetic NameDrop-like shimmer pulse when two iPhones touch to connect!
    func playTouchConnect() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 0.9)
            return
        }
        let swell = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.70),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.42)
            ],
            relativeTime: 0.0,
            duration: 0.28
        )
        let lockClick = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.98),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.85)
            ],
            relativeTime: 0.26
        )
        let curve = CHHapticParameterCurve(
            parameterID: .hapticIntensityControl,
            controlPoints: [
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.0, value: 0.15),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.22, value: 0.85),
                CHHapticParameterCurve.ControlPoint(relativeTime: 0.28, value: 0.20)
            ],
            relativeTime: 0
        )
        playPattern([swell, lockClick], curves: [curve])
    }

    func playDash() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.75)
            return
        }
        let punch = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.75),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.65)
        ], relativeTime: 0.0)
        let tail = CHHapticEvent(eventType: .hapticContinuous, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.34),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.28)
        ], relativeTime: 0.04, duration: 0.14)
        playPattern([punch, tail])
    }

    func playLevelUp() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.8)
            return
        }
        let events = [
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.45),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.50)
            ], relativeTime: 0.0),
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.68),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.72)
            ], relativeTime: 0.09),
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.92),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.92)
            ], relativeTime: 0.18)
        ]
        playPattern(events)
    }

    func playPrankSent() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.7)
            return
        }
        var events: [CHHapticEvent] = []
        for i in 0..<4 {
            events.append(CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.52 + Float(i) * 0.08),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.80)
            ], relativeTime: TimeInterval(i) * 0.055))
        }
        playPattern(events)
    }

    func playPrankReceived() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 0.85)
            return
        }
        let buzz1 = CHHapticEvent(eventType: .hapticContinuous, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.75),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.42)
        ], relativeTime: 0.0, duration: 0.12)
        let buzz2 = CHHapticEvent(eventType: .hapticContinuous, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.85),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.35)
        ], relativeTime: 0.17, duration: 0.16)
        playPattern([buzz1, buzz2])
    }

    func playBubblePop() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.65)
            return
        }
        playPattern([CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.62),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.98)
        ], relativeTime: 0.0)])
    }

    /// Electric crackle when touching a bioluminescent jellyfish
    func playJellyZap() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 0.9)
            return
        }
        var events: [CHHapticEvent] = []
        for i in 0..<5 {
            events.append(CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.88 - Float(i) * 0.12),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.96)
            ], relativeTime: TimeInterval(i) * 0.038))
        }
        playPattern(events)
    }

    /// Elastic inflation thump when pufferfish expands nearby
    func playPufferPuff() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.6)
            return
        }
        playPattern([CHHapticEvent(eventType: .hapticContinuous, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.50),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.35)
        ], relativeTime: 0.0, duration: 0.14)])
    }

    func playPlayerBump() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            mediumImpact.impactOccurred(intensity: 0.65)
            return
        }
        playPattern([CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.72),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.40)
        ], relativeTime: 0.0)])
    }

    func playHurt() {
        guard isEnabled else { return }
        guard supportsHaptics else {
            heavyImpact.impactOccurred(intensity: 1.0)
            return
        }
        let hit = CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.25)
        ], relativeTime: 0.0)
        let shake = CHHapticEvent(eventType: .hapticContinuous, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.80),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.14)
        ], relativeTime: 0.02, duration: 0.24)
        playPattern([hit, shake])
    }

    func playUIClick() {
        guard isEnabled else { return }
        let now = CACurrentMediaTime()
        guard now - lastClickTime > 0.045 else { return }
        lastClickTime = now

        guard supportsHaptics else {
            lightImpact.impactOccurred(intensity: 0.3)
            return
        }
        playPattern([CHHapticEvent(eventType: .hapticTransient, parameters: [
            CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.28),
            CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.85)
        ], relativeTime: 0)])
    }
}
