import Foundation
import SpriteKit
import UIKit

// MARK: - Texture & FX Cache

private final class AssetTextureCache {
    static let shared = AssetTextureCache()
    private var cache: [String: SKTexture] = [:]

    func texture(named name: String) -> SKTexture {
        if let t = cache[name] { return t }
        let tex = SKTexture(imageNamed: name)
        tex.filteringMode = .linear
        cache[name] = tex
        return tex
    }

    func softGlowTexture(color: UIColor, size: CGFloat = 128) -> SKTexture {
        let key = "glow_\(color.description)_\(Int(size))"
        if let t = cache[key] { return t }
        let s = CGSize(width: size, height: size)
        let renderer = UIGraphicsImageRenderer(size: s)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let colors = [
                color.withAlphaComponent(0.75).cgColor,
                color.withAlphaComponent(0.24).cgColor,
                color.withAlphaComponent(0.0).cgColor
            ] as CFArray
            let space = CGColorSpaceCreateDeviceRGB()
            if let grad = CGGradient(colorsSpace: space, colors: colors, locations: [0.0, 0.48, 1.0]) {
                let c = CGPoint(x: size * 0.5, y: size * 0.5)
                cg.drawRadialGradient(grad, startCenter: c, startRadius: 2, endCenter: c, endRadius: size * 0.5, options: [])
            }
        }
        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func prankOrbTexture(prank: PrankType) -> SKTexture {
        let key = "orb_v2_\(prank.rawValue)"
        if let t = cache[key] { return t }
        let size = CGSize(width: 78, height: 78)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            let rect = CGRect(x: 13, y: 13, width: 52, height: 52)
            cg.saveGState()
            cg.setShadow(offset: .zero, blur: 13, color: UIColor(red: 0.72, green: 0.36, blue: 1.0, alpha: 0.85).cgColor)
            UIColor(red: 0.44, green: 0.18, blue: 0.86, alpha: 0.82).setFill()
            UIBezierPath(ovalIn: rect).fill()
            cg.restoreGState()

            UIColor(red: 0.92, green: 0.82, blue: 1.0, alpha: 0.92).setStroke()
            let ring = UIBezierPath(ovalIn: rect)
            ring.lineWidth = 2.2
            ring.stroke()

            let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 25)]
            let text = NSString(string: prank.emoji)
            let tSize = text.size(withAttributes: attrs)
            text.draw(at: CGPoint(x: (size.width - tSize.width) * 0.5, y: (size.height - tSize.height) * 0.5), withAttributes: attrs)
        }
        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }

    func bubbleTrapTexture() -> SKTexture {
        let key = "bubble_trap_v2"
        if let t = cache[key] { return t }
        let size = CGSize(width: 120, height: 120)
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { _ in
            let rect = CGRect(x: 8, y: 8, width: 104, height: 104)
            UIColor(red: 0.62, green: 0.94, blue: 1.0, alpha: 0.22).setFill()
            UIBezierPath(ovalIn: rect).fill()

            UIColor(red: 0.88, green: 0.98, blue: 1.0, alpha: 0.85).setStroke()
            let stroke = UIBezierPath(ovalIn: rect)
            stroke.lineWidth = 2.6
            stroke.stroke()

            UIColor.white.withAlphaComponent(0.70).setFill()
            UIBezierPath(ovalIn: CGRect(x: 26, y: 22, width: 26, height: 14)).fill()
        }
        let tex = SKTexture(image: img)
        cache[key] = tex
        return tex
    }
}

// MARK: - Simulation Entities

private struct SimPlayer {
    var x: Float
    var y: Float
    var vx: Float = 0
    var vy: Float = 0
    var facingRight: Bool = true
    var score: Int = 0
    var level: Int = 1
    var lives: Int = 3
    var dashCooldown: Float = 0
    var dashTimer: Float = 0
    var invuln: Float = 0
    var inkTimer: Float = 0
    var invertTimer: Float = 0
    var bubbleTimer: Float = 0
    var pranksUsed: Int = 0
    var bites: Int = 0

    var radius: Float {
        16.0 + Float(level - 1) * 4.8
    }

    static func levelForScore(_ s: Int) -> Int {
        if s >= 55 { return 5 }
        if s >= 34 { return 4 }
        if s >= 18 { return 3 }
        if s >= 7 { return 2 }
        return 1
    }

    func toSync() -> PlayerSyncState {
        PlayerSyncState(
            x: x, y: y, facingRight: facingRight,
            score: score, level: level, lives: lives,
            dashCooldown: dashCooldown, invuln: invuln,
            inkTimer: inkTimer, invertTimer: invertTimer,
            bubbleTimer: bubbleTimer, isDashing: dashTimer > 0,
            pranksUsed: pranksUsed, bites: bites
        )
    }

    mutating func apply(_ s: PlayerSyncState, lerp: Float) {
        x += (s.x - x) * lerp
        y += (s.y - y) * lerp
        facingRight = s.facingRight
        score = s.score
        level = s.level
        lives = s.lives
        dashCooldown = s.dashCooldown
        invuln = s.invuln
        inkTimer = s.inkTimer
        invertTimer = s.invertTimer
        bubbleTimer = s.bubbleTimer
        dashTimer = s.isDashing ? 0.15 : 0
        pranksUsed = s.pranksUsed
        bites = s.bites
    }
}

private struct SimFish {
    var id: Int
    var x: Float
    var y: Float
    var baseY: Float
    var vx: Float
    var vy: Float
    var radius: Float
    var species: FishSpecies
    var bobPhase: Float
    var bobAmp: Float
    var chaseTarget: Int?
    var chaseTimer: Float
    var puffTimer: Float        // >0 when pufferfish is inflated & spiky
    var puffWarnTimer: Float    // brief 0.45s anticipation before expanding

    var isPuffed: Bool { puffTimer > 0 }

    func toSync() -> FishSyncState {
        FishSyncState(
            id: id, x: x, y: y, vx: vx, vy: vy,
            radius: radius, species: species,
            isPuffed: puffTimer > 0,
            isWarningPuff: puffWarnTimer > 0,
            isChasing: chaseTarget != nil && chaseTimer > 0
        )
    }
}

private struct SimOrb {
    var id: Int
    var x: Float
    var y: Float
    var baseY: Float
    var phase: Float
    var prank: PrankType
    var life: Float

    func toSync() -> OrbSyncState {
        OrbSyncState(id: id, x: x, y: y, prank: prank)
    }
}

private struct SimWarning {
    var y: Float
    var fromLeft: Bool
    var isLeviathan: Bool
    var timer: Float
    var duration: Float
    var chaseTarget: Int?
}

// MARK: - SpriteKit Ocean Scene v2.0

final class OceanScene: SKScene {
    static let worldWidth: CGFloat = 1200
    static let worldHeight: CGFloat = 600
    static let safeMinX: Float = 82
    static let safeMaxX: Float = 1118
    static let safeMinY: Float = 54
    static let safeMaxY: Float = 546

    var onHudUpdate: ((HudState) -> Void)?
    var onRoundOver: ((RoundResult) -> Void)?
    var onSendSnapshot: ((WorldSnapshot) -> Void)?
    var onSendEvent: ((GameEventPacket) -> Void)?
    var onSendGuestInput: ((PlayerInputPacket) -> Void)?

    private(set) var currentMap: MapTheme = .abyss
    private var gamePhase: GamePhase = .menu
    private var gameMode: GameMode = .solo
    private var ruleMode: GameRuleMode = .timed
    private var isGuestClient: Bool = false
    private var seriesP1: Int = 0
    private var seriesP2: Int = 0

    // Inputs
    private var localInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)
    private var remoteGuestInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)

    // Simulation state
    private var p1 = SimPlayer(x: 340, y: 300, facingRight: true)
    private var p2 = SimPlayer(x: 860, y: 300, facingRight: false)
    private var fishes: [SimFish] = []
    private var orbs: [SimOrb] = []
    private var warnings: [SimWarning] = []
    private var nextEntityID: Int = 1

    // Timers
    private var lastUpdateTime: TimeInterval = 0
    private var simTime: Float = 0
    private var matchElapsed: Float = 0
    private var timeValue: Float = 90.0
    private var sharkSpawnTimer: Float = 10.5
    private var leviathanSpawnTimer: Float = 55.0
    private var jellyfishSpawnTimer: Float = 18.0
    private var pufferSpawnTimer: Float = 15.0
    private var orbSpawnTimer: Float = 8.5
    private var snapshotTimer: Float = 0
    private var guestInputTimer: Float = 0
    private var hudTimer: Float = 0
    private var bubbleEmitTimer: Float = 0
    private var playerBumpCooldown: Float = 0

    // Calm AI bot state
    private var botRetargetTimer: Float = 0
    private var botPauseTimer: Float = 0
    private var botTargetID: Int? = nil
    private var botWanderAngle: Float = 0

    // Banner toast
    private var bannerText: String? = nil
    private var bannerEmoji: String? = nil
    private var bannerTimer: Float = 0

    // Scene depth layers
    private let bgNode = SKSpriteNode()
    private let causticsLayer = SKNode()
    private let bokehLayer = SKNode()
    private let worldLayer = SKNode()
    private let fxLayer = SKNode()
    private let foregroundBlurLayer = SKNode()
    private let warningLayer = SKNode()

    private var bokehParticles: [(SKSpriteNode, CGFloat, CGFloat, CGFloat)] = []
    private var causticBeams: [(SKShapeNode, CGFloat, CGFloat)] = []
    private var foregroundBlades: [(SKShapeNode, CGFloat, CGFloat, CGFloat)] = []

    // Player nodes
    private let p1Container = SKNode()
    private let p1Glow = SKSpriteNode()
    private let p1Sprite = SKSpriteNode()
    private let p1Tag = SKLabelNode(fontNamed: "AvenirNext-DemiBold")
    private let p1Crown = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p1Bubble = SKSpriteNode()

    private let p2Container = SKNode()
    private let p2Glow = SKSpriteNode()
    private let p2Sprite = SKSpriteNode()
    private let p2Tag = SKLabelNode(fontNamed: "AvenirNext-DemiBold")
    private let p2Crown = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let p2Bubble = SKSpriteNode()

    // Entity pools (container holds main sprite + subtle threat glint)
    private var fishContainers: [Int: (container: SKNode, sprite: SKSpriteNode, threatAura: SKSpriteNode)] = [:]
    private var orbNodes: [Int: SKSpriteNode] = [:]
    private var warningNodes: [SKNode] = []

    private var latestSnapshot: WorldSnapshot? = nil

    override init(size: CGSize) {
        super.init(size: CGSize(width: Self.worldWidth, height: Self.worldHeight))
        scaleMode = .aspectFill
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.02, green: 0.08, blue: 0.16, alpha: 1.0)
        setupLayers()
        applyMapVisuals(.abyss, animated: false)
        setupMenuAmbientFish()
    }

    private func setupLayers() {
        bgNode.position = CGPoint(x: Self.worldWidth * 0.5, y: Self.worldHeight * 0.5)
        bgNode.size = CGSize(width: Self.worldWidth, height: Self.worldHeight)
        bgNode.zPosition = -30
        addChild(bgNode)

        causticsLayer.zPosition = -22
        addChild(causticsLayer)

        bokehLayer.zPosition = -15
        addChild(bokehLayer)

        worldLayer.zPosition = 5
        addChild(worldLayer)

        fxLayer.zPosition = 16
        addChild(fxLayer)

        // Soft out-of-focus foreground silhouettes at very bottom corners for f/1.4 photographic depth
        foregroundBlurLayer.zPosition = 20
        addChild(foregroundBlurLayer)

        warningLayer.zPosition = 28
        addChild(warningLayer)

        // Setup subtle shimmering top caustic rays
        let beamXs: [CGFloat] = [210, 470, 740, 980]
        for (i, bx) in beamXs.enumerated() {
            let path = UIBezierPath()
            path.move(to: CGPoint(x: -45, y: 0))
            path.addLine(to: CGPoint(x: 45, y: 0))
            path.addLine(to: CGPoint(x: 130, y: -420))
            path.addLine(to: CGPoint(x: -90, y: -420))
            path.close()
            let beam = SKShapeNode(path: path.cgPath)
            beam.position = CGPoint(x: bx, y: Self.worldHeight + 10)
            beam.fillColor = UIColor.white.withAlphaComponent(0.055)
            beam.strokeColor = .clear
            beam.blendMode = .add
            causticsLayer.addChild(beam)
            causticBeams.append((beam, CGFloat(i) * 1.4, CGFloat.random(in: 0.45...0.75)))
        }

        // Setup Player 1 (Warm luminous golden fancy fish)
        p1Glow.texture = AssetTextureCache.shared.softGlowTexture(color: UIColor(red: 1.0, green: 0.80, blue: 0.25, alpha: 1.0))
        p1Glow.size = CGSize(width: 96, height: 74)
        p1Glow.blendMode = .add
        p1Glow.alpha = 0.42
        p1Container.addChild(p1Glow)

        p1Sprite.texture = AssetTextureCache.shared.texture(named: "fish_p1_gold")
        p1Sprite.size = CGSize(width: 68, height: 49)
        p1Container.addChild(p1Sprite)

        p1Tag.fontSize = 11.5
        p1Tag.fontColor = UIColor(red: 1.0, green: 0.92, blue: 0.58, alpha: 0.92)
        p1Container.addChild(p1Tag)

        p1Crown.text = "👑"
        p1Crown.fontSize = 17
        p1Crown.isHidden = true
        p1Container.addChild(p1Crown)

        p1Bubble.texture = AssetTextureCache.shared.bubbleTrapTexture()
        p1Bubble.size = CGSize(width: 82, height: 82)
        p1Bubble.isHidden = true
        p1Bubble.zPosition = 4
        p1Container.addChild(p1Bubble)
        p1Container.zPosition = 12
        p1Container.isHidden = true
        worldLayer.addChild(p1Container)

        // Setup Player 2 (Radiant coral-pink betta)
        p2Glow.texture = AssetTextureCache.shared.softGlowTexture(color: UIColor(red: 1.0, green: 0.34, blue: 0.64, alpha: 1.0))
        p2Glow.size = CGSize(width: 96, height: 74)
        p2Glow.blendMode = .add
        p2Glow.alpha = 0.42
        p2Container.addChild(p2Glow)

        p2Sprite.texture = AssetTextureCache.shared.texture(named: "fish_p2_coral")
        p2Sprite.size = CGSize(width: 68, height: 52)
        p2Container.addChild(p2Sprite)

        p2Tag.fontSize = 11.5
        p2Tag.fontColor = UIColor(red: 1.0, green: 0.68, blue: 0.86, alpha: 0.92)
        p2Container.addChild(p2Tag)

        p2Crown.text = "👑"
        p2Crown.fontSize = 17
        p2Crown.isHidden = true
        p2Container.addChild(p2Crown)

        p2Bubble.texture = AssetTextureCache.shared.bubbleTrapTexture()
        p2Bubble.size = CGSize(width: 82, height: 82)
        p2Bubble.isHidden = true
        p2Bubble.zPosition = 4
        p2Container.addChild(p2Bubble)
        p2Container.zPosition = 11
        p2Container.isHidden = true
        worldLayer.addChild(p2Container)
    }

    // MARK: - Map Switching & Photographic Atmospheric Layers

    func setMap(_ map: MapTheme) {
        guard map != currentMap else { return }
        applyMapVisuals(map, animated: true)
    }

    private func applyMapVisuals(_ map: MapTheme, animated: Bool) {
        currentMap = map
        AtmosphericAudioEngine.shared.setMap(map)

        let tex = AssetTextureCache.shared.texture(named: map.backgroundImageName)
        if animated && bgNode.texture != nil {
            let old = SKSpriteNode(texture: bgNode.texture)
            old.position = bgNode.position
            old.size = bgNode.size
            old.zPosition = -29
            addChild(old)
            bgNode.texture = tex
            old.run(SKAction.sequence([SKAction.fadeOut(withDuration: 0.55), SKAction.removeFromParent()]))
        } else {
            bgNode.texture = tex
        }

        // Adjust player halo intensity cleanly per map (brighter neon bloom on Abyss & Ocean 35mm, gentler on Reef)
        let glowAlpha: CGFloat = (map == .reef) ? 0.28 : 0.48
        p1Glow.alpha = glowAlpha
        p2Glow.alpha = glowAlpha

        // Adjust caustics tint
        let beamColor: UIColor
        switch map {
        case .abyss: beamColor = UIColor(red: 0.42, green: 0.78, blue: 1.0, alpha: 0.045)
        case .reef: beamColor = UIColor(red: 1.0, green: 0.94, blue: 0.72, alpha: 0.065)
        case .ocean35: beamColor = UIColor(red: 1.0, green: 0.86, blue: 0.64, alpha: 0.055)
        }
        for (beam, _, _) in causticBeams {
            beam.fillColor = beamColor
        }

        rebuildBokeh(for: map)
        rebuildForegroundDepthBlades(for: map)
    }

    private func rebuildBokeh(for map: MapTheme) {
        bokehLayer.removeAllChildren()
        bokehParticles.removeAll()

        let colors: [UIColor]
        switch map {
        case .abyss:
            colors = [
                UIColor(red: 0.35, green: 0.88, blue: 1.0, alpha: 1.0),
                UIColor(red: 0.58, green: 0.45, blue: 1.0, alpha: 1.0),
                UIColor(red: 0.72, green: 0.95, blue: 1.0, alpha: 1.0)
            ]
        case .reef:
            colors = [
                UIColor(red: 1.0, green: 0.96, blue: 0.78, alpha: 1.0),
                UIColor(red: 0.76, green: 0.98, blue: 0.96, alpha: 1.0)
            ]
        case .ocean35:
            colors = [
                UIColor(red: 1.0, green: 0.84, blue: 0.56, alpha: 1.0),
                UIColor(red: 0.55, green: 0.90, blue: 0.92, alpha: 1.0)
            ]
        }

        let count = (map == .abyss) ? 26 : 18
        for _ in 0..<count {
            let col = colors.randomElement() ?? .white
            let tex = AssetTextureCache.shared.softGlowTexture(color: col, size: 64)
            let node = SKSpriteNode(texture: tex)
            let d = CGFloat.random(in: 8...24)
            node.size = CGSize(width: d, height: d)
            node.position = CGPoint(x: CGFloat.random(in: 40...1160), y: CGFloat.random(in: 20...580))
            node.blendMode = .add
            node.alpha = CGFloat.random(in: map == .abyss ? 0.22...0.52 : 0.14...0.34)
            bokehLayer.addChild(node)
            bokehParticles.append((node, CGFloat.random(in: 10...24), CGFloat.random(in: 0...6.28), node.alpha))
        }
    }

    private func rebuildForegroundDepthBlades(for map: MapTheme) {
        foregroundBlurLayer.removeAllChildren()
        foregroundBlades.removeAll()

        // Tucked strictly in far bottom-left & bottom-right margins so center stays 100% clear
        let positions: [CGFloat] = [38, 72, 118, 1085, 1132, 1166]
        let bladeColor: UIColor
        switch map {
        case .abyss: bladeColor = UIColor(red: 0.03, green: 0.08, blue: 0.16, alpha: 0.52)
        case .reef: bladeColor = UIColor(red: 0.08, green: 0.36, blue: 0.28, alpha: 0.34)
        case .ocean35: bladeColor = UIColor(red: 0.03, green: 0.14, blue: 0.12, alpha: 0.48)
        }

        for x in positions {
            let blade = SKShapeNode()
            blade.position = CGPoint(x: x, y: -8)
            blade.strokeColor = bladeColor
            blade.lineWidth = CGFloat.random(in: 9...15)
            blade.lineCap = .round
            blade.glowWidth = 4.5 // Soft lens-defocus feathering!
            foregroundBlurLayer.addChild(blade)
            foregroundBlades.append((blade, CGFloat.random(in: 68...125), CGFloat.random(in: 0...6.28), CGFloat.random(in: 0.8...1.3)))
        }
    }

    // MARK: - Public Controls & Network Sync

    func updateLocalInput(dx: Float, dy: Float, dashPressed: Bool) {
        localInput.dx = dx
        localInput.dy = dy
        if dashPressed { localInput.dashPressed = true }
    }

    func receiveGuestInput(_ packet: PlayerInputPacket) {
        remoteGuestInput.dx = packet.dx
        remoteGuestInput.dy = packet.dy
        if packet.dashPressed { remoteGuestInput.dashPressed = true }
    }

    func receiveSnapshot(_ snapshot: WorldSnapshot) {
        guard isGuestClient else { return }
        if snapshot.map != currentMap {
            applyMapVisuals(snapshot.map, animated: false)
        }
        ruleMode = snapshot.ruleMode
        latestSnapshot = snapshot
    }

    func receiveNetworkEvent(_ event: GameEventPacket) {
        let localIdx = isGuestClient ? 1 : 0
        triggerLocalFeedback(for: event, localIdx: localIdx)
    }

    func returnToMenu() {
        gamePhase = .menu
        isGuestClient = false
        AtmosphericAudioEngine.shared.setThreatLevel(0)
        AtmosphericAudioEngine.shared.setDuetRole(.solo)
        clearGameplayEntities()
        p1Container.isHidden = true
        p2Container.isHidden = true
        setupMenuAmbientFish()
    }

    func startMatch(mode: GameMode, rule: GameRuleMode, map: MapTheme, isGuest: Bool, seriesP1: Int, seriesP2: Int) {
        self.gameMode = mode
        self.ruleMode = rule
        self.isGuestClient = isGuest
        self.seriesP1 = seriesP1
        self.seriesP2 = seriesP2
        self.gamePhase = .playing
        self.latestSnapshot = nil

        if map != currentMap {
            applyMapVisuals(map, animated: true)
        }

        clearGameplayEntities()

        p1 = SimPlayer(x: 340, y: 300, facingRight: true)
        p2 = SimPlayer(x: 860, y: 300, facingRight: false)
        localInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)
        remoteGuestInput = PlayerInputPacket(dx: 0, dy: 0, dashPressed: false)

        matchElapsed = 0
        timeValue = (rule == .timed) ? 90.0 : 0.0
        sharkSpawnTimer = 11.0
        leviathanSpawnTimer = 55.0
        jellyfishSpawnTimer = 17.0
        pufferSpawnTimer = 14.0
        orbSpawnTimer = 8.0
        playerBumpCooldown = 0
        botRetargetTimer = 0.6
        botPauseTimer = 0
        bannerText = nil
        bannerEmoji = nil
        bannerTimer = 0

        if isGuest {
            p1Tag.text = "▼ ПАРТНЁР"
            p2Tag.text = "▼ ТЫ"
        } else {
            p1Tag.text = "▼ ТЫ"
            p2Tag.text = (mode == .solo) ? "▼ БОТ" : "▼ ПАРТНЁР"
        }

        p1Container.isHidden = false
        p2Container.isHidden = false
        p1Container.position = CGPoint(x: CGFloat(p1.x), y: CGFloat(p1.y))
        p2Container.position = CGPoint(x: CGFloat(p2.x), y: CGFloat(p2.y))

        if !isGuest {
            // Seed balanced initial ocean (mostly Tier 1 minnows + 2 medium Tier 2 angelfish so food chain starts immediately!)
            for _ in 0..<11 { spawnTierFish(.minnow, randomX: true) }
            for _ in 0..<2 { spawnTierFish(.angelfish, randomX: true) }
        }

        emitHud()
    }

    private func clearGameplayEntities() {
        fishes.removeAll()
        orbs.removeAll()
        warnings.removeAll()
        for (_, pair) in fishContainers { pair.container.removeFromParent() }
        fishContainers.removeAll()
        for (_, node) in orbNodes { node.removeFromParent() }
        orbNodes.removeAll()
        for node in warningNodes { node.removeFromParent() }
        warningNodes.removeAll()
    }

    private func setupMenuAmbientFish() {
        clearGameplayEntities()
        for _ in 0..<7 { spawnTierFish(.minnow, randomX: true) }
        for _ in 0..<3 { spawnTierFish(.angelfish, randomX: true) }
        spawnTierFish(.barracuda, randomX: true)
    }

    // MARK: - Main Loop (Strict dt for identical 60Hz & 120Hz pace)

    override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime == 0 { lastUpdateTime = currentTime }
        let rawDt = Float(currentTime - lastUpdateTime)
        lastUpdateTime = currentTime
        let dt = min(max(rawDt, 0.001), 0.05)
        simTime += dt

        animateAtmosphere(dt: dt)

        if gamePhase == .menu {
            updateMenuFish(dt: dt)
            syncEntityNodes(localPlayerLevel: 99)
            return
        }

        guard gamePhase == .playing else { return }

        if bannerTimer > 0 {
            bannerTimer -= dt
            if bannerTimer <= 0 {
                bannerText = nil
                bannerEmoji = nil
            }
        }

        if isGuestClient {
            updateGuestClient(dt: dt)
        } else {
            updateHostSimulation(dt: dt)
        }

        let localPlayer = isGuestClient ? p2 : p1
        let threatProx = computeDangerProximity(for: localPlayer)
        AtmosphericAudioEngine.shared.setThreatLevel(threatProx)
        if threatProx > 0.16 {
            HapticManager.shared.playSharkHeartbeat(proximity: threatProx)
        }

        syncPlayerVisuals()
        syncEntityNodes(localPlayerLevel: localPlayer.level)
        syncWarningVisuals()

        hudTimer += dt
        if hudTimer >= 0.06 {
            hudTimer = 0
            emitHud(dangerProx: threatProx)
        }
    }

    private func animateAtmosphere(dt: Float) {
        for (beam, phase, speed) in causticBeams {
            let shimmer = 0.65 + 0.35 * sin(CGFloat(simTime) * speed + phase)
            beam.alpha = shimmer
            beam.zRotation = sin(CGFloat(simTime) * 0.25 + phase) * 0.04
        }

        for (p, speed, phase, baseAlpha) in bokehParticles {
            p.position.y += speed * CGFloat(dt)
            p.position.x += sin(CGFloat(simTime) * 0.9 + phase) * 7.0 * CGFloat(dt)
            p.alpha = baseAlpha * (0.72 + 0.28 * sin(CGFloat(simTime) * 1.6 + phase))
            if p.position.y > Self.worldHeight + 20 {
                p.position.y = -20
                p.position.x = CGFloat.random(in: 40...1160)
            }
        }

        for (blade, h, phase, speed) in foregroundBlades {
            let sway = sin(CGFloat(simTime) * speed + phase) * 12.0
            let path = UIBezierPath()
            path.move(to: .zero)
            path.addQuadCurve(to: CGPoint(x: sway, y: h), controlPoint: CGPoint(x: sway * 0.4 + 6, y: h * 0.52))
            blade.path = path.cgPath
        }
    }

    private func updateMenuFish(dt: Float) {
        for i in fishes.indices {
            fishes[i].x += fishes[i].vx * dt
            fishes[i].bobPhase += dt * 1.5
            fishes[i].y = fishes[i].baseY + sin(fishes[i].bobPhase) * fishes[i].bobAmp
            if fishes[i].vx > 0 && fishes[i].x > Float(Self.worldWidth) + 90 {
                fishes[i].x = -90
            } else if fishes[i].vx < 0 && fishes[i].x < -90 {
                fishes[i].x = Float(Self.worldWidth) + 90
            }
        }
    }

    // MARK: - Guest Client Loop

    private func updateGuestClient(dt: Float) {
        guestInputTimer += dt
        if guestInputTimer >= 0.033 || localInput.dashPressed {
            guestInputTimer = 0
            onSendGuestInput?(localInput)
            localInput.dashPressed = false
        }

        guard let snap = latestSnapshot else { return }
        let lerp = min(1.0, 1.0 - exp(-18.0 * dt))
        p1.apply(snap.p1, lerp: lerp)
        p2.apply(snap.p2, lerp: lerp)
        timeValue = snap.timeValue

        var updated: [SimFish] = []
        updated.reserveCapacity(snap.fish.count)
        for sf in snap.fish {
            if let existing = fishes.first(where: { $0.id == sf.id }) {
                var f = existing
                f.x += (sf.x - f.x) * lerp
                f.y += (sf.y - f.y) * lerp
                f.vx = sf.vx
                f.vy = sf.vy
                f.radius = sf.radius
                f.species = sf.species
                f.puffTimer = sf.isPuffed ? 1.0 : 0.0
                f.puffWarnTimer = sf.isWarningPuff ? 0.3 : 0.0
                updated.append(f)
            } else {
                updated.append(SimFish(
                    id: sf.id, x: sf.x, y: sf.y, baseY: sf.y,
                    vx: sf.vx, vy: sf.vy, radius: sf.radius,
                    species: sf.species, bobPhase: 0, bobAmp: 0,
                    chaseTarget: sf.isChasing ? 1 : nil, chaseTimer: sf.isChasing ? 1 : 0,
                    puffTimer: sf.isPuffed ? 1.0 : 0.0, puffWarnTimer: sf.isWarningPuff ? 0.3 : 0.0
                ))
            }
        }
        fishes = updated

        orbs = snap.orbs.map {
            SimOrb(id: $0.id, x: $0.x, y: $0.y, baseY: $0.y, phase: 0, prank: $0.prank, life: 10)
        }
        warnings = snap.warnings.map {
            SimWarning(y: $0.y, fromLeft: $0.fromLeft, isLeviathan: $0.isLeviathan, timer: (1.0 - $0.progress) * 1.4, duration: 1.4, chaseTarget: nil)
        }
    }

    // MARK: - Host Authoritative Simulation

    private func updateHostSimulation(dt: Float) {
        matchElapsed += dt
        if ruleMode == .timed {
            timeValue = max(0, timeValue - dt)
        } else {
            timeValue = matchElapsed
        }
        if playerBumpCooldown > 0 { playerBumpCooldown = max(0, playerBumpCooldown - dt) }

        // 1. Update Players
        let p1Dash = localInput.dashPressed
        localInput.dashPressed = false
        updatePlayer(&p1, dx: localInput.dx, dy: localInput.dy, dashPressed: p1Dash, playerIdx: 0, speedScale: 1.0, dt: dt)

        if gameMode == .solo {
            let (bdx, bdy) = computeCalmBotInput(dt: dt)
            updatePlayer(&p2, dx: bdx, dy: bdy, dashPressed: false, playerIdx: 1, speedScale: 0.72, dt: dt)
        } else {
            let p2Dash = remoteGuestInput.dashPressed
            remoteGuestInput.dashPressed = false
            updatePlayer(&p2, dx: remoteGuestInput.dx, dy: remoteGuestInput.dy, dashPressed: p2Dash, playerIdx: 1, speedScale: 1.0, dt: dt)
        }

        // 2. Dynamic 5-Tier Ocean Ecosystem Spawning (scales naturally with highest player level!)
        let maxPlayerLevel = max(p1.level, p2.level)
        let normalFishCount = fishes.filter { !$0.species.isApexPredator && $0.species != .jellyfish && $0.species != .puffer }.count
        if normalFishCount < 15 {
            spawnBalancedTierFish(maxLevel: maxPlayerLevel)
        }

        // 3. Rare Reef Shark (Tier 4 — enters with edge ⚠️ warning)
        sharkSpawnTimer -= dt
        let activeSharks = fishes.filter { $0.species == .shark }.count + warnings.filter { !$0.isLeviathan }.count
        let maxSharks = (ruleMode == .survival && matchElapsed > 70) ? 2 : 1
        if sharkSpawnTimer <= 0 {
            if activeSharks < maxSharks {
                let yLane = Float.random(in: 105...495)
                let fromLeft = Bool.random()
                warnings.append(SimWarning(y: yLane, fromLeft: fromLeft, isLeviathan: false, timer: 1.45, duration: 1.45, chaseTarget: nil))
                dispatchEvent(GameEventPacket(type: .sharkWarning, targetPlayer: 2))
            }
            sharkSpawnTimer = (ruleMode == .survival)
                ? max(7.5, Float.random(in: 10.5...14.0) - matchElapsed * 0.03)
                : Float.random(in: 10.5...14.5)
        }

        // 4. Tier 5 Abyssal Leviathan (late-game apex threat in Survival OR when someone hits Level 5!)
        if ruleMode == .survival || maxPlayerLevel >= 5 {
            leviathanSpawnTimer -= dt
            let activeLev = fishes.filter { $0.species == .leviathan }.count + warnings.filter { $0.isLeviathan }.count
            if leviathanSpawnTimer <= 0 && activeLev == 0 {
                let yLane = Float.random(in: 120...480)
                let fromLeft = Bool.random()
                warnings.append(SimWarning(y: yLane, fromLeft: fromLeft, isLeviathan: true, timer: 1.75, duration: 1.75, chaseTarget: nil))
                dispatchEvent(GameEventPacket(type: .sharkWarning, targetPlayer: 2))
                leviathanSpawnTimer = Float.random(in: 22.0...28.0)
            }
        }

        // 5. Rare Bioluminescent Jellyfish (max 1 on screen, unobtrusive & peaceful drift)
        jellyfishSpawnTimer -= dt
        let activeJellies = fishes.filter { $0.species == .jellyfish }.count
        if jellyfishSpawnTimer <= 0 {
            if activeJellies == 0 {
                spawnJellyfish()
            }
            jellyfishSpawnTimer = Float.random(in: 20.0...27.0)
        }

        // 6. Rare Spiky Pufferfish (max 1 on screen; calm until approached!)
        pufferSpawnTimer -= dt
        let activePuffers = fishes.filter { $0.species == .puffer }.count
        if pufferSpawnTimer <= 0 {
            if activePuffers == 0 {
                spawnPufferfish()
            }
            pufferSpawnTimer = Float.random(in: 18.0...25.0)
        }

        // 7. Prank purple orbs
        orbSpawnTimer -= dt
        if orbSpawnTimer <= 0 {
            if orbs.count < 2 { spawnPrankOrb() }
            orbSpawnTimer = Float.random(in: 9.5...13.5)
        }

        // Process warnings
        for i in stride(from: warnings.count - 1, through: 0, by: -1) {
            warnings[i].timer -= dt
            if warnings[i].timer <= 0 {
                let w = warnings.remove(at: i)
                spawnApex(species: w.isLeviathan ? .leviathan : .shark, y: w.y, fromLeft: w.fromLeft, chaseTarget: w.chaseTarget)
            }
        }

        // Update all creatures
        for i in stride(from: fishes.count - 1, through: 0, by: -1) {
            updateCreature(&fishes[i], dt: dt)
            let f = fishes[i]
            if f.species == .jellyfish {
                if f.y > Float(Self.worldHeight) + 95 || f.x < -120 || f.x > Float(Self.worldWidth) + 120 {
                    fishes.remove(at: i)
                }
            } else if f.x < -170 || f.x > Float(Self.worldWidth) + 170 {
                fishes.remove(at: i)
            }
        }

        // Update prank orbs
        for i in stride(from: orbs.count - 1, through: 0, by: -1) {
            orbs[i].life -= dt
            orbs[i].phase += dt * 2.4
            orbs[i].y = orbs[i].baseY + sin(orbs[i].phase) * 10.0
            if orbs[i].life <= 0 { orbs.remove(at: i) }
        }

        // Collisions
        checkPlayerCollisions(player: &p1, opponent: &p2, playerIdx: 0)
        checkPlayerCollisions(player: &p2, opponent: &p1, playerIdx: 1)
        checkPlayerVsPlayerInteraction()

        // Trail bubbles
        bubbleEmitTimer += dt
        if bubbleEmitTimer >= 0.24 {
            bubbleEmitTimer = 0
            emitTinyBubble(at: CGPoint(x: CGFloat(p1.x), y: CGFloat(p1.y)))
            emitTinyBubble(at: CGPoint(x: CGFloat(p2.x), y: CGFloat(p2.y)))
        }

        // Broadcast snapshot at 25Hz in multiplayer
        if gameMode == .multiplayer {
            snapshotTimer += dt
            if snapshotTimer >= 0.04 {
                snapshotTimer = 0
                let snap = WorldSnapshot(
                    p1: p1.toSync(),
                    p2: p2.toSync(),
                    fish: fishes.map { $0.toSync() },
                    orbs: orbs.map { $0.toSync() },
                    warnings: warnings.map {
                        WarningSyncState(y: $0.y, fromLeft: $0.fromLeft, isLeviathan: $0.isLeviathan, progress: 1.0 - max(0, $0.timer / $0.duration))
                    },
                    timeValue: timeValue,
                    ruleMode: ruleMode,
                    map: currentMap
                )
                onSendSnapshot?(snap)
            }
        }

        // End condition: Survival ends strictly when first player hits 0 lives; Timed ends at 0s or 0 lives
        let timeExpired = (ruleMode == .timed && timeValue <= 0)
        if timeExpired || p1.lives <= 0 || p2.lives <= 0 {
            finishRound()
        }
    }

    private func updatePlayer(_ p: inout SimPlayer, dx: Float, dy: Float, dashPressed: Bool, playerIdx: Int, speedScale: Float, dt: Float) {
        if p.dashCooldown > 0 { p.dashCooldown = max(0, p.dashCooldown - dt) }
        if p.dashTimer > 0 { p.dashTimer = max(0, p.dashTimer - dt) }
        if p.invuln > 0 { p.invuln = max(0, p.invuln - dt) }
        if p.inkTimer > 0 { p.inkTimer = max(0, p.inkTimer - dt) }
        if p.invertTimer > 0 { p.invertTimer = max(0, p.invertTimer - dt) }

        if p.bubbleTimer > 0 {
            p.bubbleTimer -= dt
            p.vx *= exp(-6.0 * dt)
            p.vy = 60.0
            p.x += p.vx * dt
            p.y += p.vy * dt
            clampPlayer(&p)
            if p.bubbleTimer <= 0 {
                p.bubbleTimer = 0
                dispatchEvent(GameEventPacket(type: .bubblePop, targetPlayer: playerIdx))
                spawnWaterRipple(at: CGPoint(x: CGFloat(p.x), y: CGFloat(p.y)), color: UIColor(red: 0.72, green: 0.96, blue: 1.0, alpha: 0.85))
            }
            return
        }

        if dashPressed && p.dashCooldown <= 0 {
            p.dashTimer = 0.25
            p.dashCooldown = 2.5
            dispatchEvent(GameEventPacket(type: .dash, targetPlayer: playerIdx))
        }

        var inX = dx
        var inY = dy
        if p.invertTimer > 0 {
            inX = -inX
            inY = -inY
        }

        let mag = hypot(inX, inY)
        if mag > 1.0 { inX /= mag; inY /= mag }

        // Smaller fish are nimbler, larger fish have slightly weightier glide
        let baseSpeed: Float = (262.0 - Float(p.level - 1) * 11.0) * speedScale
        let boost: Float = p.dashTimer > 0 ? 1.88 : 1.0
        let targetVX = inX * baseSpeed * boost
        let targetVY = inY * baseSpeed * boost

        let accelRate: Float = (mag > 0.05) ? 14.0 : 11.5
        let factor = 1.0 - exp(-accelRate * dt)
        p.vx += (targetVX - p.vx) * factor
        p.vy += (targetVY - p.vy) * factor

        p.x += p.vx * dt
        p.y += p.vy * dt

        if abs(inX) > 0.08 { p.facingRight = inX > 0 }
        clampPlayer(&p)
    }

    private func clampPlayer(_ p: inout SimPlayer) {
        p.x = min(max(p.x, Self.safeMinX), Self.safeMaxX)
        p.y = min(max(p.y, Self.safeMinY), Self.safeMaxY)
    }

    // MARK: - Spawners & Creature Behaviors

    private func spawnBalancedTierFish(maxLevel: Int) {
        let roll = Float.random(in: 0...1)
        let species: FishSpecies
        switch maxLevel {
        case 1:
            // Mostly edible minnows + occasional Tier 2 angelfish so player already has to dodge!
            species = (roll < 0.76) ? .minnow : .angelfish
        case 2:
            if roll < 0.48 { species = .minnow }
            else if roll < 0.84 { species = .angelfish }
            else { species = .barracuda }
        case 3:
            if roll < 0.34 { species = .minnow }
            else if roll < 0.70 { species = .angelfish }
            else { species = .barracuda }
        default:
            if roll < 0.25 { species = .minnow }
            else if roll < 0.58 { species = .angelfish }
            else { species = .barracuda }
        }
        spawnTierFish(species, randomX: false)
    }

    private func spawnTierFish(_ species: FishSpecies, randomX: Bool) {
        let fromLeft = Bool.random()
        let x: Float = randomX
            ? Float.random(in: 120...1080)
            : (fromLeft ? -70 : Float(Self.worldWidth) + 70)
        let y = Float.random(in: 75...525)

        let speed: Float
        let radius: Float
        let amp: Float
        switch species {
        case .minnow:
            speed = Float.random(in: 52...86)
            radius = Float.random(in: 10.5...13.0)
            amp = Float.random(in: 5...12)
        case .angelfish:
            speed = Float.random(in: 42...68)
            radius = Float.random(in: 19.0...22.0)
            amp = Float.random(in: 8...15)
        case .barracuda:
            speed = Float.random(in: 86...124)
            radius = 27.0
            amp = Float.random(in: 4...9)
        default:
            speed = 65
            radius = 16
            amp = 8
        }

        let fish = SimFish(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            radius: radius,
            species: species,
            bobPhase: Float.random(in: 0...6.28),
            bobAmp: amp,
            chaseTarget: nil,
            chaseTimer: 0,
            puffTimer: 0,
            puffWarnTimer: 0
        )
        nextEntityID += 1
        fishes.append(fish)
    }

    private func spawnApex(species: FishSpecies, y: Float, fromLeft: Bool, chaseTarget: Int?) {
        let isLev = (species == .leviathan)
        let speed: Float = isLev ? Float.random(in: 118...145) : Float.random(in: 132...166)
        let x: Float = fromLeft ? -115 : Float(Self.worldWidth) + 115
        let fish = SimFish(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            radius: isLev ? 48.0 : 37.0,
            species: species,
            bobPhase: 0,
            bobAmp: 6,
            chaseTarget: chaseTarget,
            chaseTimer: chaseTarget != nil ? 3.8 : 0,
            puffTimer: 0,
            puffWarnTimer: 0
        )
        nextEntityID += 1
        fishes.append(fish)
    }

    private func spawnJellyfish() {
        let x = Float.random(in: 180...1020)
        let driftX = Float.random(in: -14...14)
        let jelly = SimFish(
            id: nextEntityID,
            x: x, y: -60, baseY: -60,
            vx: driftX,
            vy: Float.random(in: 24...36),
            radius: 22.0,
            species: .jellyfish,
            bobPhase: Float.random(in: 0...6.28),
            bobAmp: 18.0,
            chaseTarget: nil,
            chaseTimer: 0,
            puffTimer: 0,
            puffWarnTimer: 0
        )
        nextEntityID += 1
        fishes.append(jelly)
    }

    private func spawnPufferfish() {
        let fromLeft = Bool.random()
        let x: Float = fromLeft ? -60 : Float(Self.worldWidth) + 60
        let y = Float.random(in: 110...490)
        let speed = Float.random(in: 42...60)
        let puffer = SimFish(
            id: nextEntityID,
            x: x, y: y, baseY: y,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            radius: 17.0,
            species: .puffer,
            bobPhase: Float.random(in: 0...6.28),
            bobAmp: 10.0,
            chaseTarget: nil,
            chaseTimer: 0,
            puffTimer: 0,
            puffWarnTimer: 0
        )
        nextEntityID += 1
        fishes.append(puffer)
    }

    private func updateCreature(_ f: inout SimFish, dt: Float) {
        switch f.species {
        case .shark, .leviathan:
            if let targetIdx = f.chaseTarget, f.chaseTimer > 0 {
                f.chaseTimer -= dt
                let target = (targetIdx == 0) ? p1 : p2
                let dx = target.x - f.x
                let dy = target.y - f.y
                let dist = max(1, hypot(dx, dy))
                let k = 1.0 - exp(-3.0 * dt)
                f.vx += ((dx / dist) * 165.0 - f.vx) * k
                f.vy += ((dy / dist) * 145.0 - f.vy) * k
                if f.chaseTimer <= 0 {
                    f.vx = f.vx >= 0 ? 155 : -155
                    f.vy = 0
                    f.chaseTarget = nil
                }
            }
            f.x += f.vx * dt
            f.y += f.vy * dt
            f.y = min(max(f.y, 70), 530)

        case .jellyfish:
            // Graceful rhythmic bell-pulse drift upward
            f.bobPhase += dt * 2.2
            let pulseBoost: Float = 0.65 + 0.55 * max(0, sin(f.bobPhase))
            f.y += f.vy * pulseBoost * dt
            f.x += (f.vx + cos(f.bobPhase * 0.6) * 14.0) * dt

        case .puffer:
            f.x += f.vx * (f.isPuffed ? 0.45 : 1.0) * dt
            f.bobPhase += dt * 1.8
            f.y = f.baseY + sin(f.bobPhase) * f.bobAmp

            if f.puffTimer > 0 {
                f.puffTimer = max(0, f.puffTimer - dt)
                f.radius = 28.0
            } else if f.puffWarnTimer > 0 {
                f.puffWarnTimer -= dt
                if f.puffWarnTimer <= 0 {
                    f.puffTimer = 3.2
                    f.radius = 28.0
                    dispatchEvent(GameEventPacket(type: .pufferPuff, targetPlayer: 2))
                }
            } else {
                f.radius = 17.0
                // If any player gets within ~125pt, puffer anticipates and swells up!
                let d1 = hypot(p1.x - f.x, p1.y - f.y)
                let d2 = hypot(p2.x - f.x, p2.y - f.y)
                if min(d1, d2) < 125 {
                    f.puffWarnTimer = 0.45
                }
            }

        default:
            f.x += f.vx * dt
            f.bobPhase += dt * 1.85
            f.y = f.baseY + sin(f.bobPhase) * f.bobAmp
        }
    }

    private func spawnPrankOrb() {
        let prank = PrankType.allCases.randomElement() ?? .ink
        let x = Float.random(in: 220...980)
        let y = Float.random(in: 120...480)
        orbs.append(SimOrb(
            id: nextEntityID, x: x, y: y, baseY: y,
            phase: Float.random(in: 0...6.28),
            prank: prank, life: 12.0
        ))
        nextEntityID += 1
    }

    // MARK: - Collisions & Food Chain Logic

    private func isDangerous(_ f: SimFish, forPlayerLevel level: Int) -> Bool {
        switch f.species {
        case .jellyfish: return true
        case .puffer: return f.isPuffed || level < 2
        case .leviathan: return true
        default: return f.species.tier > level
        }
    }

    private func pointsForEating(_ species: FishSpecies) -> Int {
        switch species {
        case .minnow: return 1
        case .angelfish: return 2
        case .puffer: return 3
        case .barracuda: return 4
        case .shark: return 8
        default: return 1
        }
    }

    private func checkPlayerCollisions(player: inout SimPlayer, opponent: inout SimPlayer, playerIdx: Int) {
        let oppIdx = (playerIdx == 0) ? 1 : 0

        for i in stride(from: fishes.count - 1, through: 0, by: -1) {
            let f = fishes[i]
            let dist = hypot(player.x - f.x, player.y - f.y)
            let hitDist = player.radius + f.radius * 0.76
            guard dist < hitDist else { continue }

            if isDangerous(f, forPlayerLevel: player.level) {
                if player.invuln <= 0 {
                    player.lives = max(0, player.lives - 1)
                    player.invuln = 2.3
                    if ruleMode == .timed {
                        player.score = max(0, player.score - 3)
                    }
                    let evType: GameEventType = (f.species == .jellyfish) ? .jellyZap : .hurt
                    dispatchEvent(GameEventPacket(type: evType, targetPlayer: playerIdx))
                    let fxColor: UIColor = (f.species == .jellyfish)
                        ? UIColor(red: 0.45, green: 0.90, blue: 1.0, alpha: 0.9)
                        : UIColor.systemRed.withAlphaComponent(0.85)
                    spawnWaterRipple(at: CGPoint(x: CGFloat(player.x), y: CGFloat(player.y)), color: fxColor)
                }
            } else {
                // Edible!
                let pts = pointsForEating(f.species)
                player.score += pts
                player.bites += 1
                let eatenPos = CGPoint(x: CGFloat(f.x), y: CGFloat(f.y))
                let wasBig = f.species.tier >= 2
                fishes.remove(at: i)

                if playerIdx == 1 && gameMode == .solo {
                    botPauseTimer = Float.random(in: 0.45...0.65)
                    botTargetID = nil
                }

                let rippleColor = (playerIdx == 0)
                    ? UIColor(red: 1.0, green: 0.85, blue: 0.35, alpha: 0.82)
                    : UIColor(red: 1.0, green: 0.46, blue: 0.76, alpha: 0.82)
                spawnWaterRipple(at: eatenPos, color: rippleColor)
                dispatchEvent(GameEventPacket(type: wasBig ? .bigBite : .bite, targetPlayer: playerIdx))

                let newLevel = SimPlayer.levelForScore(player.score)
                if newLevel > player.level {
                    player.level = newLevel
                    dispatchEvent(GameEventPacket(type: .levelUp, targetPlayer: playerIdx))
                }
            }
        }

        // Prank orbs
        for i in stride(from: orbs.count - 1, through: 0, by: -1) {
            let orb = orbs[i]
            if hypot(player.x - orb.x, player.y - orb.y) < player.radius + 25 {
                let prank = orb.prank
                orbs.remove(at: i)
                player.pranksUsed += 1
                applyPrank(prank, fromPlayer: playerIdx, toOpponent: &opponent, opponentIdx: oppIdx)
            }
        }
    }

    private func checkPlayerVsPlayerInteraction() {
        guard playerBumpCooldown <= 0 else { return }
        let dx = p2.x - p1.x
        let dy = p2.y - p1.y
        let dist = hypot(dx, dy)
        let touchDist = p1.radius + p2.radius * 0.85
        guard dist < touchDist && dist > 1 else { return }

        let nx = dx / dist
        let ny = dy / dist

        // If one player is 2+ levels ahead, they can nip the smaller rival!
        if p1.level >= p2.level + 2 && p2.invuln <= 0 {
            p2.lives = max(0, p2.lives - 1)
            p2.invuln = 2.4
            p2.vx = nx * 280
            p2.vy = ny * 220
            playerBumpCooldown = 0.6
            dispatchEvent(GameEventPacket(type: .hurt, targetPlayer: 1))
            dispatchEvent(GameEventPacket(type: .bigBite, targetPlayer: 0))
            return
        } else if p2.level >= p1.level + 2 && p1.invuln <= 0 {
            p1.lives = max(0, p1.lives - 1)
            p1.invuln = 2.4
            p1.vx = -nx * 280
            p1.vy = -ny * 220
            playerBumpCooldown = 0.6
            dispatchEvent(GameEventPacket(type: .hurt, targetPlayer: 0))
            dispatchEvent(GameEventPacket(type: .bigBite, targetPlayer: 1))
            return
        }

        // Playful Dash Bump! Dash into partner to gently shove them toward hazards
        if p1.dashTimer > 0 && p2.dashTimer <= 0 {
            p2.vx += nx * 310
            p2.vy += ny * 260
            playerBumpCooldown = 0.45
            dispatchEvent(GameEventPacket(type: .playerBump, targetPlayer: 2))
            spawnWaterRipple(at: CGPoint(x: CGFloat((p1.x + p2.x) * 0.5), y: CGFloat((p1.y + p2.y) * 0.5)), color: .white)
        } else if p2.dashTimer > 0 && p1.dashTimer <= 0 {
            p1.vx -= nx * 310
            p1.vy -= ny * 260
            playerBumpCooldown = 0.45
            dispatchEvent(GameEventPacket(type: .playerBump, targetPlayer: 2))
            spawnWaterRipple(at: CGPoint(x: CGFloat((p1.x + p2.x) * 0.5), y: CGFloat((p1.y + p2.y) * 0.5)), color: .white)
        }
    }

    private func computeCalmBotInput(dt: Float) -> (Float, Float) {
        if botPauseTimer > 0 {
            botPauseTimer -= dt
            return (0, 0)
        }

        // Dodge any dangerous creature calmly
        for f in fishes where isDangerous(f, forPlayerLevel: p2.level) {
            let dx = p2.x - f.x
            let dy = p2.y - f.y
            let dist = hypot(dx, dy)
            let safeRange: Float = f.species.isApexPredator ? 190 : 120
            if dist < safeRange && dist > 1 {
                return (dx / dist, dy / dist)
            }
        }

        if p2.inkTimer > 0 {
            botWanderAngle += dt * 3.2
            return (cos(botWanderAngle) * 0.5, sin(botWanderAngle) * 0.5)
        }

        botRetargetTimer -= dt
        if botRetargetTimer <= 0 || botTargetID == nil {
            botRetargetTimer = Float.random(in: 0.9...1.5)
            botTargetID = nil
            var bestDist: Float = 270.0
            for f in fishes where !isDangerous(f, forPlayerLevel: p2.level) {
                let d = hypot(f.x - p2.x, f.y - p2.y)
                if d < bestDist {
                    bestDist = d
                    botTargetID = f.id
                }
            }
        }

        if let tid = botTargetID, let target = fishes.first(where: { $0.id == tid }) {
            let dx = target.x - p2.x
            let dy = target.y - p2.y
            let d = hypot(dx, dy)
            if d > 6 { return (dx / d, dy / d) }
        }

        botWanderAngle += dt * 0.65
        return (cos(botWanderAngle) * 0.42, sin(botWanderAngle * 1.3) * 0.34)
    }

    private func applyPrank(_ prank: PrankType, fromPlayer: Int, toOpponent: inout SimPlayer, opponentIdx: Int) {
        switch prank {
        case .ink:
            toOpponent.inkTimer = 4.5
            dispatchEvent(GameEventPacket(type: .prankInk, targetPlayer: opponentIdx))
        case .invert:
            toOpponent.invertTimer = 4.8
            dispatchEvent(GameEventPacket(type: .prankInvert, targetPlayer: opponentIdx))
        case .shark:
            let fromLeft = toOpponent.x > Float(Self.worldWidth) * 0.5
            warnings.append(SimWarning(y: toOpponent.y, fromLeft: fromLeft, isLeviathan: false, timer: 1.0, duration: 1.0, chaseTarget: opponentIdx))
            dispatchEvent(GameEventPacket(type: .prankShark, targetPlayer: opponentIdx))
        case .bubble:
            toOpponent.bubbleTimer = 3.5
            dispatchEvent(GameEventPacket(type: .prankBubble, targetPlayer: opponentIdx))
        }
        if fromPlayer == 0 {
            HapticManager.shared.playPrankSent()
        }
    }

    private func dispatchEvent(_ event: GameEventPacket) {
        let localIdx = isGuestClient ? 1 : 0
        triggerLocalFeedback(for: event, localIdx: localIdx)
        if gameMode == .multiplayer && !isGuestClient {
            onSendEvent?(event)
        }
    }

    private func triggerLocalFeedback(for event: GameEventPacket, localIdx: Int) {
        let isForMe = (event.targetPlayer == localIdx || event.targetPlayer == 2)
        switch event.type {
        case .bite:
            if isForMe {
                HapticManager.shared.playBite()
                AtmosphericAudioEngine.shared.playSFX(.bite)
            }
        case .bigBite:
            if isForMe {
                HapticManager.shared.playBigBite()
                AtmosphericAudioEngine.shared.playSFX(.bigBite)
            }
        case .dash:
            if isForMe {
                HapticManager.shared.playDash()
                AtmosphericAudioEngine.shared.playSFX(.dash)
            }
        case .sharkWarning:
            HapticManager.shared.playSharkWarning()
            AtmosphericAudioEngine.shared.playSFX(.sharkWarning)
        case .levelUp:
            if isForMe {
                HapticManager.shared.playLevelUp()
                AtmosphericAudioEngine.shared.playSFX(.levelUp)
                showBanner(emoji: "✨", text: "Новый уровень!")
            }
        case .prankInk:
            AtmosphericAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🐙", text: "Чернила осьминога!")
            } else {
                showBanner(emoji: "🐙", text: "Чернила отправлены!")
            }
        case .prankInvert:
            AtmosphericAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🔄", text: "Управление перевёрнуто!")
            } else {
                showBanner(emoji: "🔄", text: "Перевёртыш отправлен!")
            }
        case .prankShark:
            AtmosphericAudioEngine.shared.playSFX(.sharkWarning)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🦈", text: "На тебя натравили акулу!")
            } else {
                showBanner(emoji: "🦈", text: "Акула пошла за соперником!")
            }
        case .prankBubble:
            AtmosphericAudioEngine.shared.playSFX(.prank)
            if isForMe {
                HapticManager.shared.playPrankReceived()
                showBanner(emoji: "🫧", text: "Ты в мыльном пузыре!")
            } else {
                showBanner(emoji: "🫧", text: "Соперник в пузыре!")
            }
        case .bubblePop:
            AtmosphericAudioEngine.shared.playSFX(.bubblePop)
            if isForMe { HapticManager.shared.playBubblePop() }
        case .pufferPuff:
            AtmosphericAudioEngine.shared.playSFX(.pufferPuff)
            HapticManager.shared.playPufferPuff()
        case .jellyZap:
            AtmosphericAudioEngine.shared.playSFX(.jellyZap)
            if isForMe {
                HapticManager.shared.playJellyZap()
                showBanner(emoji: "⚡", text: "Удар медузы!")
            }
        case .playerBump:
            AtmosphericAudioEngine.shared.playSFX(.playerBump)
            HapticManager.shared.playPlayerBump()
        case .hurt:
            AtmosphericAudioEngine.shared.playSFX(.hurt)
            if isForMe { HapticManager.shared.playHurt() }
        }
    }

    private func showBanner(emoji: String, text: String) {
        bannerEmoji = emoji
        bannerText = text
        bannerTimer = 2.2
    }

    private func computeDangerProximity(for player: SimPlayer) -> Float {
        var maxProx: Float = 0
        for f in fishes where f.species.isApexPredator && isDangerous(f, forPlayerLevel: player.level) {
            let d = hypot(player.x - f.x, player.y - f.y)
            if d < 340 {
                let p = max(0, 1.0 - d / 340.0)
                if p > maxProx { maxProx = p }
            }
        }
        return maxProx
    }

    private func finishRound() {
        gamePhase = .roundOver
        AtmosphericAudioEngine.shared.setThreatLevel(0)

        let winner: Int
        if p1.lives == 0 && p2.lives > 0 { winner = 1 }
        else if p2.lives == 0 && p1.lives > 0 { winner = 0 }
        else if p1.score > p2.score { winner = 0 }
        else if p2.score > p1.score { winner = 1 }
        else { winner = -1 }

        if winner == 0 { seriesP1 += 1 }
        if winner == 1 { seriesP2 += 1 }

        let result = RoundResult(
            scoreP1: p1.score,
            scoreP2: p2.score,
            levelP1: p1.level,
            levelP2: p2.level,
            titleP1: TitleGenerator.pickTitle(score: p1.score, level: p1.level, lives: p1.lives, pranks: p1.pranksUsed, won: winner == 0),
            titleP2: TitleGenerator.pickTitle(score: p2.score, level: p2.level, lives: p2.lives, pranks: p2.pranksUsed, won: winner == 1),
            winnerIndex: winner,
            seriesP1: seriesP1,
            seriesP2: seriesP2,
            ruleMode: ruleMode,
            durationSeconds: Int(matchElapsed)
        )
        onRoundOver?(result)
    }

    // MARK: - Visual Sync

    private func syncPlayerVisuals() {
        updatePlayerNode(
            p: p1, container: p1Container, glow: p1Glow, sprite: p1Sprite,
            tag: p1Tag, crown: p1Crown, bubble: p1Bubble,
            isLeading: p1.score > p2.score && p1.score > 0
        )
        updatePlayerNode(
            p: p2, container: p2Container, glow: p2Glow, sprite: p2Sprite,
            tag: p2Tag, crown: p2Crown, bubble: p2Bubble,
            isLeading: p2.score > p1.score && p2.score > 0
        )
    }

    private func updatePlayerNode(
        p: SimPlayer, container: SKNode, glow: SKSpriteNode, sprite: SKSpriteNode,
        tag: SKLabelNode, crown: SKLabelNode, bubble: SKSpriteNode, isLeading: Bool
    ) {
        container.position = CGPoint(x: CGFloat(p.x), y: CGFloat(p.y))
        let scale = CGFloat(p.radius / 18.0)
        let dirSign: CGFloat = p.facingRight ? 1.0 : -1.0

        // Organic gentle swimming undulation
        let swimWiggle = 1.0 + 0.03 * sin(CGFloat(simTime) * 7.5 + (p.facingRight ? 0 : 1.5))
        sprite.xScale = scale * dirSign * swimWiggle
        sprite.yScale = scale / swimWiggle
        glow.setScale(scale * (p.dashTimer > 0 ? 1.32 : 1.05))

        sprite.alpha = (p.invuln > 0) ? ((Int(simTime * 16) % 2 == 0) ? 0.35 : 0.96) : 1.0

        let speedRatio = CGFloat(min(1, max(-1, p.vy / 250.0)))
        sprite.zRotation = speedRatio * 0.22 * dirSign

        tag.position = CGPoint(x: 0, y: CGFloat(p.radius) + 18)
        crown.position = CGPoint(x: 0, y: CGFloat(p.radius) + 34)
        crown.isHidden = !isLeading

        bubble.isHidden = p.bubbleTimer <= 0
        if !bubble.isHidden {
            let bScale = CGFloat(p.radius / 16.5) * (1.0 + 0.05 * sin(CGFloat(simTime) * 6.0))
            bubble.setScale(bScale)
        }
    }

    private func baseDisplaySize(for species: FishSpecies) -> CGSize {
        switch species {
        case .minnow: return CGSize(width: 44, height: 22)
        case .angelfish: return CGSize(width: 62, height: 58)
        case .barracuda: return CGSize(width: 118, height: 32)
        case .shark: return CGSize(width: 168, height: 54)
        case .leviathan: return CGSize(width: 224, height: 72)
        case .puffer: return CGSize(width: 48, height: 38)
        case .jellyfish: return CGSize(width: 52, height: 114)
        }
    }

    private func syncEntityNodes(localPlayerLevel: Int) {
        var activeIDs = Set<Int>()
        let redGlowTex = AssetTextureCache.shared.softGlowTexture(color: UIColor(red: 1.0, green: 0.22, blue: 0.26, alpha: 1.0), size: 96)

        for f in fishes {
            activeIDs.insert(f.id)
            let pair: (container: SKNode, sprite: SKSpriteNode, threatAura: SKSpriteNode)
            if let existing = fishContainers[f.id] {
                pair = existing
            } else {
                let container = SKNode()
                let aura = SKSpriteNode(texture: redGlowTex)
                aura.blendMode = .add
                aura.zPosition = -1
                aura.isHidden = true
                container.addChild(aura)

                let sprite = SKSpriteNode(texture: AssetTextureCache.shared.texture(named: f.species.textureName))
                sprite.size = baseDisplaySize(for: f.species)
                if f.species == .jellyfish {
                    sprite.blendMode = .alpha
                }
                container.addChild(sprite)

                container.zPosition = f.species.isApexPredator ? 10 : (f.species == .jellyfish ? 9 : 6)
                worldLayer.addChild(container)
                pair = (container, sprite, aura)
                fishContainers[f.id] = pair
            }

            pair.container.position = CGPoint(x: CGFloat(f.x), y: CGFloat(f.y))

            if f.species == .jellyfish {
                let pulse = 1.0 + 0.08 * sin(CGFloat(f.bobPhase))
                pair.sprite.xScale = pulse
                pair.sprite.yScale = 1.0 / pulse
                pair.threatAura.isHidden = true
            } else if f.species == .puffer {
                let dir: CGFloat = f.vx >= 0 ? 1.0 : -1.0
                let puffScale: CGFloat = f.isPuffed ? 1.62 : (f.puffWarnTimer > 0 ? 1.24 : 0.92)
                pair.sprite.xScale = dir * puffScale
                pair.sprite.yScale = puffScale
                let showDanger = (f.isPuffed || f.puffWarnTimer > 0) && gamePhase == .playing
                pair.threatAura.isHidden = !showDanger
                if showDanger {
                    pair.threatAura.size = CGSize(width: 92, height: 92)
                    pair.threatAura.alpha = 0.28 + 0.20 * sin(CGFloat(simTime) * 14.0)
                }
            } else {
                let dir: CGFloat = f.vx >= 0 ? 1.0 : -1.0
                let swim = 1.0 + 0.025 * sin(CGFloat(simTime) * 6.0 + CGFloat(f.id))
                pair.sprite.xScale = dir * swim
                pair.sprite.yScale = 1.0 / swim

                // Subtle, classy crimson aura ONLY on fish currently strictly higher tier than local player
                let danger = (gamePhase == .playing) && isDangerous(f, forPlayerLevel: localPlayerLevel)
                pair.threatAura.isHidden = !danger
                if danger {
                    let s = baseDisplaySize(for: f.species)
                    pair.threatAura.size = CGSize(width: s.width * 0.95, height: s.height * 1.45)
                    pair.threatAura.alpha = 0.20 + 0.14 * sin(CGFloat(simTime) * 5.0 + CGFloat(f.id))
                }
            }
        }

        for (id, pair) in fishContainers where !activeIDs.contains(id) {
            pair.container.removeFromParent()
            fishContainers.removeValue(forKey: id)
        }

        var activeOrbIDs = Set<Int>()
        for orb in orbs {
            activeOrbIDs.insert(orb.id)
            let node: SKSpriteNode
            if let existing = orbNodes[orb.id] {
                node = existing
            } else {
                node = SKSpriteNode(texture: AssetTextureCache.shared.prankOrbTexture(prank: orb.prank))
                node.size = CGSize(width: 56, height: 56)
                node.zPosition = 9
                worldLayer.addChild(node)
                orbNodes[orb.id] = node
            }
            node.position = CGPoint(x: CGFloat(orb.x), y: CGFloat(orb.y))
            let pulse = 1.0 + 0.08 * sin(CGFloat(simTime) * 4.5 + CGFloat(orb.phase))
            node.setScale(pulse)
        }

        for (id, node) in orbNodes where !activeOrbIDs.contains(id) {
            node.removeFromParent()
            orbNodes.removeValue(forKey: id)
        }
    }

    private func syncWarningVisuals() {
        for n in warningNodes { n.removeFromParent() }
        warningNodes.removeAll()

        for w in warnings {
            let xPos: CGFloat = w.fromLeft ? 88 : Self.worldWidth - 88
            let container = SKNode()
            container.position = CGPoint(x: xPos, y: CGFloat(w.y))

            let pulse = 0.55 + 0.45 * sin(CGFloat(simTime) * 16.0)
            let badge = SKShapeNode(circleOfRadius: w.isLeviathan ? 28 : 24)
            badge.fillColor = w.isLeviathan
                ? UIColor(red: 0.62, green: 0.12, blue: 0.95, alpha: 0.35 + 0.35 * pulse)
                : UIColor(red: 0.95, green: 0.14, blue: 0.18, alpha: 0.32 + 0.35 * pulse)
            badge.strokeColor = w.isLeviathan
                ? UIColor(red: 0.80, green: 0.48, blue: 1.0, alpha: 0.95)
                : UIColor(red: 1.0, green: 0.32, blue: 0.32, alpha: 0.95)
            badge.lineWidth = 2.5
            container.addChild(badge)

            let label = SKLabelNode(text: w.isLeviathan ? "☠️" : "⚠️")
            label.fontSize = 22
            label.verticalAlignmentMode = .center
            container.addChild(label)

            warningLayer.addChild(container)
            warningNodes.append(container)
        }
    }

    private func spawnWaterRipple(at pos: CGPoint, color: UIColor) {
        let ring = SKShapeNode(circleOfRadius: 11)
        ring.position = pos
        ring.fillColor = .clear
        ring.strokeColor = color
        ring.lineWidth = 2.4
        fxLayer.addChild(ring)

        ring.run(SKAction.sequence([
            SKAction.group([SKAction.scale(to: 3.1, duration: 0.36), SKAction.fadeOut(withDuration: 0.36)]),
            SKAction.removeFromParent()
        ]))
    }

    private func emitTinyBubble(at pos: CGPoint) {
        let b = SKShapeNode(circleOfRadius: CGFloat.random(in: 2.0...4.0))
        b.position = pos
        b.fillColor = UIColor.white.withAlphaComponent(0.26)
        b.strokeColor = .clear
        fxLayer.addChild(b)

        b.run(SKAction.sequence([
            SKAction.group([SKAction.moveBy(x: CGFloat.random(in: -10...10), y: 28, duration: 0.68), SKAction.fadeOut(withDuration: 0.68)]),
            SKAction.removeFromParent()
        ]))
    }

    private func emitHud(dangerProx: Float = 0) {
        let localPlayer = isGuestClient ? p2 : p1
        let hud = HudState(
            scoreP1: p1.score,
            scoreP2: p2.score,
            levelP1: p1.level,
            levelP2: p2.level,
            livesP1: p1.lives,
            livesP2: p2.lives,
            dashCooldownLocal: localPlayer.dashCooldown,
            timeValue: timeValue,
            ruleMode: ruleMode,
            inkTimerLocal: localPlayer.inkTimer,
            invertTimerLocal: localPlayer.invertTimer,
            bubbleTimerLocal: localPlayer.bubbleTimer,
            dangerProximityLocal: dangerProx,
            bannerText: bannerText,
            bannerEmoji: bannerEmoji
        )
        onHudUpdate?(hud)
    }
}
