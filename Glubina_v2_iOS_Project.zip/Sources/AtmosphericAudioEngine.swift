import Foundation
import AVFoundation
import os

enum OceanSFXKind: Int {
    case bite = 0
    case bigBite = 1
    case dash = 2
    case sharkWarning = 3
    case levelUp = 4
    case prank = 5
    case bubblePop = 6
    case pufferPuff = 7
    case jellyZap = 8
    case playerBump = 9
    case hurt = 10
    case touchConnect = 11
    case uiClick = 12
}

enum StereoDuetRole: Int {
    case solo = 0
    case hostDuet = 1
    case guestDuet = 2
}

private struct SFXVoice {
    var active: Bool = false
    var kind: OceanSFXKind = .bite
    var time: Double = 0
    var duration: Double = 0.2
    var phase: Double = 0
    var phase2: Double = 0
}

private struct PluckVoice {
    var active: Bool = false
    var freq: Double = 440
    var phase: Double = 0
    var modPhase: Double = 0
    var env: Double = 0
    var decayRate: Double = 0.9999
    var pan: Double = 0.5
    var timbre: Int = 0 // 0=glass, 1=harp, 2=warm bell
}

/// Lush cinematic ambient underwater soundtrack + crisp spatial SFX engine.
/// Uses two render paths:
///   1) Music -> AVAudioUnitReverb (large aquatic hall) -> MainMixer
///   2) SFX   -> MainMixer (dry & tactile)
/// Supports 3 distinct map soundscapes, hydrophone ocean wash, dynamic predator tension,
/// and synchronized Stereo Duet between two iPhones!
final class AtmosphericAudioEngine {
    static let shared = AtmosphericAudioEngine()

    private let engine = AVAudioEngine()
    private let reverb = AVAudioUnitReverb()
    private var musicSourceNode: AVAudioSourceNode?
    private var sfxSourceNode: AVAudioSourceNode?
    private let sampleRate: Double = 44100.0
    private var isStarted: Bool = false

    private let lockPtr: UnsafeMutablePointer<os_unfair_lock>

    // Shared control parameters (read once per buffer)
    private var musicEnabledState: Bool = true
    private var sfxEnabledState: Bool = true
    private var currentMapRaw: Int = 0 // 0=abyss, 1=reef, 2=ocean35
    private var duetRoleState: StereoDuetRole = .solo
    private var threatLevelTarget: Double = 0.0
    private var resetMusicFlag: Bool = false
    private var musicStartCountdownSamples: Int = 0

    // Music DSP state (owned exclusively by audio thread)
    private var musicTime: Double = 0
    private var stepTimer: Double = 0
    private var chordTimer: Double = 0
    private var stepIndex: Int = 0
    private var chordIndex: Int = 0
    private var smoothedThreat: Double = 0

    // Warm 4-voice lush pad oscillators (root + detuned pair)
    private var padPhaseA: [Double] = [0, 0, 0, 0]
    private var padPhaseB: [Double] = [0, 0, 0, 0]
    private var subPhase: Double = 0
    private var threatPulsePhase: Double = 0

    // 6-voice polyphonic melodic harp / glass-bell / piano-shimmer pool
    private var pluckVoices: [PluckVoice] = Array(repeating: PluckVoice(), count: 6)
    private var nextPluckSlot: Int = 0

    // Hydrophone soft ocean ambience (pink/brown filtered water wash)
    private var oceanRng: UInt32 = 0x51A7BEEF
    private var oceanLP1: Double = 0
    private var oceanLP2: Double = 0

    // Master musical lowpass for silky warmth & predator filter sweep
    private var masterLPL: Double = 0
    private var masterLPR: Double = 0

    // Stereo ping-pong shimmer delay (~0.48s L, ~0.64s R)
    private let delayLenL = 21168
    private let delayLenR = 28224
    private var delayBufL: [Float]
    private var delayBufR: [Float]
    private var delayIdxL: Int = 0
    private var delayIdxR: Int = 0

    // SFX DSP state (owned exclusively by SFX audio thread)
    private var sfxVoices: [SFXVoice] = Array(repeating: SFXVoice(), count: 10)
    private var pendingSFXQueue: [OceanSFXKind] = []
    private var sfxRng: UInt32 = 0x99887766

    // Three atmospheric harmonic worlds (Hz)
    // 0: Abyss — Deep mysterious D Minor 9 / Fmaj7 / Bbmaj7 / Am7
    private let abyssChords: [[Double]] = [
        [146.83, 174.61, 220.00, 329.63],
        [174.61, 220.00, 261.63, 329.63],
        [116.54, 174.61, 220.00, 293.66],
        [130.81, 196.00, 246.94, 329.63]
    ]
    private let abyssMelodies: [[Double]] = [
        [293.66, 440.00, 523.25, 659.25, 587.33, 440.00, 349.23, 523.25],
        [349.23, 523.25, 659.25, 783.99, 659.25, 523.25, 440.00, 587.33],
        [293.66, 349.23, 440.00, 587.33, 523.25, 440.00, 349.23, 293.66],
        [329.63, 493.88, 587.33, 659.25, 523.25, 440.00, 392.00, 329.63]
    ]

    // 1: Watercolor Reef — Sunlit warm G Lydian / Cmaj9 / Em9 / D6
    private let reefChords: [[Double]] = [
        [196.00, 246.94, 293.66, 369.99],
        [130.81, 196.00, 246.94, 293.66],
        [164.81, 246.94, 293.66, 369.99],
        [146.83, 220.00, 246.94, 329.63]
    ]
    private let reefMelodies: [[Double]] = [
        [392.00, 493.88, 587.33, 739.99, 659.25, 587.33, 493.88, 392.00],
        [329.63, 392.00, 493.88, 587.33, 659.25, 493.88, 392.00, 440.00],
        [392.00, 493.88, 659.25, 739.99, 587.33, 493.88, 392.00, 329.63],
        [440.00, 587.33, 659.25, 739.99, 587.33, 493.88, 440.00, 392.00]
    ]

    // 2: Ocean 35mm — Nostalgic cinematic Fmaj9 / Dm9 / Cmaj7 / G6sus4
    private let filmChords: [[Double]] = [
        [174.61, 220.00, 261.63, 329.63],
        [146.83, 174.61, 220.00, 329.63],
        [130.81, 196.00, 246.94, 329.63],
        [196.00, 246.94, 261.63, 329.63]
    ]
    private let filmMelodies: [[Double]] = [
        [349.23, 440.00, 523.25, 659.25, 587.33, 523.25, 440.00, 329.63],
        [293.66, 349.23, 440.00, 587.33, 659.25, 523.25, 440.00, 349.23],
        [329.63, 392.00, 493.88, 659.25, 587.33, 493.88, 392.00, 329.63],
        [392.00, 440.00, 523.25, 659.25, 587.33, 523.25, 440.00, 392.00]
    ]

    var isMusicEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = musicEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            musicEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    var isSFXEnabled: Bool {
        get {
            os_unfair_lock_lock(lockPtr)
            let v = sfxEnabledState
            os_unfair_lock_unlock(lockPtr)
            return v
        }
        set {
            os_unfair_lock_lock(lockPtr)
            sfxEnabledState = newValue
            os_unfair_lock_unlock(lockPtr)
        }
    }

    private init() {
        lockPtr = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1)
        lockPtr.initialize(to: os_unfair_lock())
        delayBufL = Array(repeating: 0, count: delayLenL)
        delayBufR = Array(repeating: 0, count: delayLenR)
    }

    deinit {
        engine.stop()
        lockPtr.deinitialize(count: 1)
        lockPtr.deallocate()
    }

    func setMap(_ map: MapTheme) {
        os_unfair_lock_lock(lockPtr)
        switch map {
        case .abyss: currentMapRaw = 0
        case .reef: currentMapRaw = 1
        case .ocean35: currentMapRaw = 2
        }
        os_unfair_lock_unlock(lockPtr)
    }

    func setThreatLevel(_ value: Float) {
        os_unfair_lock_lock(lockPtr)
        threatLevelTarget = Double(min(max(value, 0), 1))
        os_unfair_lock_unlock(lockPtr)
    }

    func setDuetRole(_ role: StereoDuetRole) {
        os_unfair_lock_lock(lockPtr)
        duetRoleState = role
        os_unfair_lock_unlock(lockPtr)
    }

    /// Synchronizes musical bar phase across two iPhones with an exact sample countdown!
    func scheduleSynchronizedStart(delaySeconds: Double, role: StereoDuetRole, map: MapTheme) {
        start()
        let samples = max(0, Int(delaySeconds * sampleRate))
        os_unfair_lock_lock(lockPtr)
        duetRoleState = role
        switch map {
        case .abyss: currentMapRaw = 0
        case .reef: currentMapRaw = 1
        case .ocean35: currentMapRaw = 2
        }
        resetMusicFlag = true
        musicStartCountdownSamples = samples
        os_unfair_lock_unlock(lockPtr)
    }

    func start() {
        if isStarted {
            if !engine.isRunning {
                try? engine.start()
            }
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {
            // Safe fallback
        }

        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2) else { return }

        reverb.loadFactoryPreset(.largeHall2)
        reverb.wetDryMix = 44

        let mNode = AVAudioSourceNode(format: format) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            self.renderMusic(abl: UnsafeMutableAudioBufferListPointer(audioBufferList), frames: Int(frameCount))
            return noErr
        }

        let sNode = AVAudioSourceNode(format: format) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            self.renderSFX(abl: UnsafeMutableAudioBufferListPointer(audioBufferList), frames: Int(frameCount))
            return noErr
        }

        musicSourceNode = mNode
        sfxSourceNode = sNode

        engine.attach(mNode)
        engine.attach(reverb)
        engine.attach(sNode)

        engine.connect(mNode, to: reverb, format: format)
        engine.connect(reverb, to: engine.mainMixerNode, format: format)
        engine.connect(sNode, to: engine.mainMixerNode, format: format)
        engine.mainMixerNode.outputVolume = 0.88

        do {
            try engine.start()
            isStarted = true
        } catch {
            isStarted = false
        }
    }

    func playSFX(_ kind: OceanSFXKind) {
        if !isStarted { start() }
        os_unfair_lock_lock(lockPtr)
        if sfxEnabledState && pendingSFXQueue.count < 8 {
            pendingSFXQueue.append(kind)
        }
        os_unfair_lock_unlock(lockPtr)
    }

    @inline(__always)
    private func nextNoise(_ state: inout UInt32) -> Double {
        state = state &* 1664525 &+ 1013904223
        return Double(state & 0xFFFF) / 32768.0 - 1.0
    }

    // MARK: - Lush Atmospheric Underwater Music Render (Real-Time Safe)

    private func renderMusic(abl: UnsafeMutableAudioBufferListPointer, frames: Int) {
        guard abl.count >= 1 else { return }
        let leftBuf = abl[0].mData?.assumingMemoryBound(to: Float.self)
        let rightBuf = abl.count > 1 ? abl[1].mData?.assumingMemoryBound(to: Float.self) : nil

        os_unfair_lock_lock(lockPtr)
        let playMusic = musicEnabledState
        let mapIdx = currentMapRaw
        let role = duetRoleState
        let threatTarget = threatLevelTarget
        let shouldReset = resetMusicFlag
        let countdown = musicStartCountdownSamples
        if shouldReset {
            resetMusicFlag = false
        }
        os_unfair_lock_unlock(lockPtr)

        if shouldReset {
            musicTime = 0
            stepTimer = 0
            chordTimer = 0
            stepIndex = 0
            chordIndex = 0
            for i in 0..<pluckVoices.count { pluckVoices[i].active = false }
            for i in 0..<delayLenL { delayBufL[i] = 0 }
            for i in 0..<delayLenR { delayBufR[i] = 0 }
        }

        if !playMusic {
            for i in 0..<frames {
                leftBuf?[i] = 0
                rightBuf?[i] = 0
            }
            return
        }

        var localCountdown = countdown
        let dt = 1.0 / sampleRate
        let twoPi = Double.pi * 2.0

        let stepDur: Double = (mapIdx == 0) ? 0.46 : (mapIdx == 1 ? 0.38 : 0.42)
        let chordDur: Double = stepDur * 16.0

        let chordList = (mapIdx == 0) ? abyssChords : (mapIdx == 1 ? reefChords : filmChords)
        let melodyList = (mapIdx == 0) ? abyssMelodies : (mapIdx == 1 ? reefMelodies : filmMelodies)

        // Spatial Stereo Duet balance (each phone still sounds complete, yet they call & answer!)
        let bassGain: Double = (role == .guestDuet) ? 0.42 : (role == .hostDuet ? 1.15 : 0.90)
        let padGain: Double = (role == .guestDuet) ? 0.65 : (role == .hostDuet ? 1.05 : 0.88)
        let upperPadOctave: Double = (role == .guestDuet) ? 2.0 : 1.0

        for i in 0..<frames {
            if localCountdown > 0 {
                localCountdown -= 1
                leftBuf?[i] = 0
                rightBuf?[i] = 0
                continue
            }

            musicTime += dt
            stepTimer += dt
            chordTimer += dt
            smoothedThreat += (threatTarget - smoothedThreat) * 0.00025

            if chordTimer >= chordDur {
                chordTimer -= chordDur
                chordIndex = (chordIndex + 1) % chordList.count
            }

            if stepTimer >= stepDur {
                stepTimer -= stepDur
                let pattern = melodyList[chordIndex]
                let nIdx = stepIndex % pattern.count

                // Determine whether THIS phone plays this melodic note (Spatial Call-and-Answer Duet!)
                let isRest = (stepIndex % 8 == 7) || (mapIdx == 0 && stepIndex % 6 == 4)
                if !isRest {
                    let shouldPlayHere: Bool
                    switch role {
                    case .solo: shouldPlayHere = true
                    case .hostDuet: shouldPlayHere = (stepIndex % 2 == 0)
                    case .guestDuet: shouldPlayHere = (stepIndex % 2 == 1)
                    }

                    if shouldPlayHere {
                        var v = PluckVoice()
                        v.active = true
                        let octShift = (role == .guestDuet && stepIndex % 4 == 3) ? 2.0 : 1.0
                        v.freq = pattern[nIdx] * octShift
                        v.phase = 0
                        v.modPhase = 0
                        v.env = 1.0
                        v.decayRate = (mapIdx == 0) ? 0.999935 : (mapIdx == 1 ? 0.99988 : 0.99991)
                        v.pan = 0.5 + 0.38 * sin(Double(stepIndex) * 0.9)
                        v.timbre = mapIdx
                        pluckVoices[nextPluckSlot] = v
                        nextPluckSlot = (nextPluckSlot + 1) % pluckVoices.count
                    }
                }
                stepIndex = (stepIndex + 1) % 16
            }

            // 1. Gentle hydrophone underwater ambience (breathing ocean currents)
            let wNoise = nextNoise(&oceanRng)
            oceanLP1 += (wNoise - oceanLP1) * 0.012
            oceanLP2 += (oceanLP1 - oceanLP2) * 0.008
            let tideSwell = 0.65 + 0.35 * sin(musicTime * 0.22)
            let hydrophone = oceanLP2 * 0.055 * tideSwell

            // 2. Lush warm cinematic pad (with subtle analog tape flutter on Ocean 35mm)
            let chord = chordList[chordIndex]
            let tapeWow = (mapIdx == 2) ? (1.0 + 0.0022 * sin(musicTime * 1.15)) : 1.0
            let breath = 0.68 + 0.32 * sin(musicTime * 0.31)
            var padL: Double = 0
            var padR: Double = 0

            for v in 0..<4 {
                let mult = (v >= 2) ? upperPadOctave : 1.0
                let f = chord[v] * mult * tapeWow
                padPhaseA[v] += twoPi * f * dt
                if padPhaseA[v] > twoPi { padPhaseA[v] -= twoPi }
                padPhaseB[v] += twoPi * (f * 1.0042) * dt
                if padPhaseB[v] > twoPi { padPhaseB[v] -= twoPi }

                let sA = sin(padPhaseA[v]) * 0.78 + sin(padPhaseA[v] * 2.0) * 0.14 + sin(padPhaseA[v] * 3.0) * 0.04
                let sB = sin(padPhaseB[v]) * 0.78
                if v % 2 == 0 {
                    padL += sA * 0.68 + sB * 0.32
                    padR += sB * 0.68 + sA * 0.32
                } else {
                    padL += sB * 0.68 + sA * 0.32
                    padR += sA * 0.68 + sB * 0.32
                }
            }
            padL *= 0.046 * breath * padGain
            padR *= 0.046 * breath * padGain

            // 3. Deep velvet sub-bass + subtle predator tension pulse
            let rootSub = chord[0] * 0.5
            subPhase += twoPi * rootSub * dt
            if subPhase > twoPi { subPhase -= twoPi }
            let subWave = sin(subPhase) * 0.105 * bassGain

            threatPulsePhase += twoPi * 1.65 * dt
            if threatPulsePhase > twoPi { threatPulsePhase -= twoPi }
            let threatPulse = sin(subPhase * 0.75) * (0.5 + 0.5 * sin(threatPulsePhase)) * smoothedThreat * 0.12

            // 4. Polyphonic melodic voices (glassy harmonics / warm harp / cinematic electric piano bell)
            var melL: Double = 0
            var melR: Double = 0
            for idx in 0..<pluckVoices.count {
                guard pluckVoices[idx].active else { continue }
                var pv = pluckVoices[idx]
                pv.env *= pv.decayRate
                if pv.env < 0.002 {
                    pv.active = false
                    pluckVoices[idx] = pv
                    continue
                }
                pv.phase += twoPi * pv.freq * dt
                if pv.phase > twoPi { pv.phase -= twoPi }
                pv.modPhase += twoPi * (pv.freq * (pv.timbre == 0 ? 3.0 : 2.0)) * dt
                if pv.modPhase > twoPi { pv.modPhase -= twoPi }

                let sample: Double
                switch pv.timbre {
                case 0: // Abyss: crystalline aquatic glass harmonic
                    sample = sin(pv.phase + sin(pv.modPhase) * 0.55 * pv.env) * pv.env * 0.092
                case 1: // Reef: warm organic harp / marimba pluck
                    sample = (sin(pv.phase) * 0.72 + sin(pv.phase * 2.0) * 0.22 * pv.env + sin(pv.phase * 3.0) * 0.06 * pv.env) * pv.env * 0.105
                default: // Ocean 35mm: nostalgic warm Rhodes / film bell
                    sample = (sin(pv.phase + sin(pv.modPhase) * 0.35 * pv.env) * 0.8 + sin(pv.phase * 2.0) * 0.16) * pv.env * 0.098
                }
                melL += sample * pv.pan
                melR += sample * (1.0 - pv.pan)
                pluckVoices[idx] = pv
            }

            // 5. Lush ping-pong echo delay on melodies
            let dL = Double(delayBufL[delayIdxL])
            let dR = Double(delayBufR[delayIdxR])
            delayBufL[delayIdxL] = Float(melL + dR * 0.48)
            delayBufR[delayIdxR] = Float(melR + dL * 0.48)
            delayIdxL = (delayIdxL + 1) % delayLenL
            delayIdxR = (delayIdxR + 1) % delayLenR

            let rawL = hydrophone + padL + subWave + threatPulse + melL + dL * 0.58
            let rawR = hydrophone + padR + subWave + threatPulse + melR + dR * 0.58

            // Smooth resonant filter (closes down slightly during nearby shark danger for cinematic immersion!)
            let baseCut = (mapIdx == 1) ? 0.28 : (mapIdx == 2 ? 0.21 : 0.17)
            let cutoff = max(0.06, baseCut - smoothedThreat * 0.09 + 0.04 * sin(musicTime * 0.26))
            masterLPL += (rawL - masterLPL) * cutoff
            masterLPR += (rawR - masterLPR) * cutoff

            leftBuf?[i] = Float(tanh(masterLPL))
            rightBuf?[i] = Float(tanh(masterLPR))
        }

        if localCountdown != countdown {
            os_unfair_lock_lock(lockPtr)
            musicStartCountdownSamples = localCountdown
            os_unfair_lock_unlock(lockPtr)
        }
    }

    // MARK: - Crisp Tactile SFX Render (Dry Channel, Lock-Free Loop)

    private func triggerSFXOnAudioThread(_ kind: OceanSFXKind) {
        var slot = 0
        var oldest: Double = -1
        for i in 0..<sfxVoices.count {
            if !sfxVoices[i].active { slot = i; break }
            if sfxVoices[i].time > oldest { oldest = sfxVoices[i].time; slot = i }
        }
        var v = SFXVoice()
        v.active = true
        v.kind = kind
        v.time = 0
        switch kind {
        case .bite: v.duration = 0.11
        case .bigBite: v.duration = 0.18
        case .dash: v.duration = 0.24
        case .sharkWarning: v.duration = 0.95
        case .levelUp: v.duration = 0.62
        case .prank: v.duration = 0.40
        case .bubblePop: v.duration = 0.13
        case .pufferPuff: v.duration = 0.22
        case .jellyZap: v.duration = 0.30
        case .playerBump: v.duration = 0.16
        case .hurt: v.duration = 0.34
        case .touchConnect: v.duration = 0.55
        case .uiClick: v.duration = 0.055
        }
        sfxVoices[slot] = v
    }

    private func renderSFX(abl: UnsafeMutableAudioBufferListPointer, frames: Int) {
        guard abl.count >= 1 else { return }
        let leftBuf = abl[0].mData?.assumingMemoryBound(to: Float.self)
        let rightBuf = abl.count > 1 ? abl[1].mData?.assumingMemoryBound(to: Float.self) : nil

        os_unfair_lock_lock(lockPtr)
        let playSfx = sfxEnabledState
        var q0: OceanSFXKind? = nil
        var q1: OceanSFXKind? = nil
        var q2: OceanSFXKind? = nil
        var q3: OceanSFXKind? = nil
        if !pendingSFXQueue.isEmpty {
            if pendingSFXQueue.count >= 1 { q0 = pendingSFXQueue[0] }
            if pendingSFXQueue.count >= 2 { q1 = pendingSFXQueue[1] }
            if pendingSFXQueue.count >= 3 { q2 = pendingSFXQueue[2] }
            if pendingSFXQueue.count >= 4 { q3 = pendingSFXQueue[3] }
            pendingSFXQueue.removeAll(keepingCapacity: true)
        }
        os_unfair_lock_unlock(lockPtr)

        if playSfx {
            if let k = q0 { triggerSFXOnAudioThread(k) }
            if let k = q1 { triggerSFXOnAudioThread(k) }
            if let k = q2 { triggerSFXOnAudioThread(k) }
            if let k = q3 { triggerSFXOnAudioThread(k) }
        }

        if !playSfx {
            for i in 0..<frames { leftBuf?[i] = 0; rightBuf?[i] = 0 }
            return
        }

        let dt = 1.0 / sampleRate
        let twoPi = Double.pi * 2.0

        for i in 0..<frames {
            var mix: Double = 0
            for idx in 0..<sfxVoices.count {
                guard sfxVoices[idx].active else { continue }
                var v = sfxVoices[idx]
                let t = v.time
                let p = t / v.duration
                if p >= 1.0 {
                    v.active = false
                    sfxVoices[idx] = v
                    continue
                }

                var s: Double = 0
                switch v.kind {
                case .bite:
                    // Clean aquatic water-drop pop
                    let freq = 480.0 + p * 620.0
                    v.phase += twoPi * freq * dt
                    let env = (1.0 - p) * (1.0 - p)
                    s = sin(v.phase) * env * 0.25

                case .bigBite:
                    // Deeper, juicier gulp + harmonic chime
                    let freq = 260.0 + p * 540.0
                    v.phase += twoPi * freq * dt
                    v.phase2 += twoPi * (freq * 1.5) * dt
                    let env = (1.0 - p) * (1.0 - p * 0.6)
                    s = (sin(v.phase) * 0.72 + sin(v.phase2) * 0.28) * env * 0.30

                case .dash:
                    // Smooth hydrodynamic rush
                    let freq = 220.0 + (1.0 - p) * 280.0
                    v.phase += twoPi * freq * dt
                    let env = sin(p * Double.pi)
                    s = (nextNoise(&sfxRng) * 0.42 + sin(v.phase) * 0.30) * env * 0.22

                case .sharkWarning:
                    // Deep resonant submarine sonar ping
                    let freq = 185.0 - p * 12.0
                    v.phase += twoPi * freq * dt
                    v.phase2 += twoPi * (freq * 2.005) * dt
                    let env = exp(-p * 3.4)
                    s = (sin(v.phase) * 0.82 + sin(v.phase2) * 0.22) * env * 0.28

                case .levelUp:
                    // Lush crystalline harmonic triad swell
                    let notes: [Double] = [523.25, 659.25, 783.99, 1046.50]
                    let n = min(3, Int(p * 4.0))
                    let lp = p * 4.0 - Double(n)
                    v.phase += twoPi * notes[n] * dt
                    let env = exp(-lp * 2.2) * (1.0 - p * 0.15)
                    s = (sin(v.phase) * 0.78 + sin(v.phase * 2.0) * 0.22) * env * 0.24

                case .prank:
                    // Playful underwater liquid warble
                    let freq = 580.0 - p * 220.0 + sin(t * 38.0) * 85.0
                    v.phase += twoPi * max(90, freq) * dt
                    s = sin(v.phase) * (1.0 - p) * 0.23

                case .bubblePop:
                    let freq = 340.0 + p * p * 1400.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * sin(p * Double.pi) * 0.27

                case .pufferPuff:
                    // Elastic balloon-like underwater swell
                    let freq = 140.0 + p * 260.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * sin(p * Double.pi) * 0.25

                case .jellyZap:
                    // Crisp bioluminescent electric crackle
                    let freq = 950.0 + sin(t * 95.0) * 420.0
                    v.phase += twoPi * freq * dt
                    let env = (1.0 - p)
                    s = (sin(v.phase) * 0.55 + nextNoise(&sfxRng) * 0.45) * env * 0.26

                case .playerBump:
                    let freq = 210.0 - p * 85.0
                    v.phase += twoPi * freq * dt
                    s = sin(v.phase) * (1.0 - p) * 0.26

                case .hurt:
                    let freq = 155.0 - p * 95.0
                    v.phase += twoPi * max(40, freq) * dt
                    let env = (1.0 - p)
                    s = (sin(v.phase) * 0.65 + nextNoise(&sfxRng) * 0.35) * env * 0.32

                case .touchConnect:
                    // Shimmering NameDrop-inspired harmonic chime
                    let f1 = 587.33 + p * 15.0
                    let f2 = 880.00
                    v.phase += twoPi * f1 * dt
                    v.phase2 += twoPi * f2 * dt
                    let env = sin(min(1.0, p * 3.0) * Double.pi * 0.5) * exp(-p * 2.6)
                    s = (sin(v.phase) * 0.6 + sin(v.phase2) * 0.4) * env * 0.30

                case .uiClick:
                    v.phase += twoPi * 720.0 * dt
                    s = sin(v.phase) * (1.0 - p) * (1.0 - p) * 0.13
                }

                mix += s
                v.time += dt
                sfxVoices[idx] = v
            }

            let clamped = Float(tanh(mix))
            leftBuf?[i] = clamped
            rightBuf?[i] = clamped
        }
    }
}
