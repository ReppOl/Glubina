import Foundation
import SwiftUI

enum MapTheme: String, Codable, CaseIterable, Identifiable {
    case abyss
    case reef
    case ocean35

    var id: String { rawValue }

    var title: String {
        switch self {
        case .abyss: return "Бездна"
        case .reef: return "Риф"
        case .ocean35: return "Океан 35mm"
        }
    }

    var icon: String {
        switch self {
        case .abyss: return "sparkles"
        case .reef: return "paintbrush.fill"
        case .ocean35: return "camera.aperture"
        }
    }

    var backgroundImageName: String {
        switch self {
        case .abyss: return "bg_abyss"
        case .reef: return "bg_reef"
        case .ocean35: return "bg_ocean35"
        }
    }

    var accentColor: Color {
        switch self {
        case .abyss: return Color(red: 0.42, green: 0.62, blue: 1.0)
        case .reef: return Color(red: 0.20, green: 0.86, blue: 0.84)
        case .ocean35: return Color(red: 0.94, green: 0.72, blue: 0.36)
        }
    }
}

enum GameMode: String, Codable, CaseIterable, Identifiable {
    case solo
    case multiplayer

    var id: String { rawValue }

    var title: String {
        switch self {
        case .solo: return "1 Игрок"
        case .multiplayer: return "Вдвоём"
        }
    }
}

enum GameRuleMode: String, Codable, CaseIterable, Identifiable {
    case timed
    case survival

    var id: String { rawValue }

    var title: String {
        switch self {
        case .timed: return "На время"
        case .survival: return "Выживание"
        }
    }

    var icon: String {
        switch self {
        case .timed: return "timer"
        case .survival: return "heart.fill"
        }
    }
}

enum FishSpecies: UInt8, Codable {
    case minnow = 0      // Tier 1: edible from Lvl 1 (+1)
    case angelfish = 1   // Tier 2: threat at Lvl 1, edible at Lvl 2+ (+2)
    case barracuda = 2   // Tier 3: threat at Lvl 1-2, edible at Lvl 3+ (+4)
    case shark = 3       // Tier 4: threat at Lvl 1-4, edible at Lvl 5 (+8)
    case leviathan = 4   // Tier 5: survival late apex threat (always dangerous)
    case puffer = 5      // Special: edible at Lvl 2+ when calm, spiky hazard when puffed!
    case jellyfish = 6   // Special: luminous drifter, stings at any level

    var tier: Int {
        switch self {
        case .minnow: return 1
        case .angelfish: return 2
        case .barracuda: return 3
        case .shark: return 4
        case .leviathan: return 6
        case .puffer: return 2
        case .jellyfish: return 99
        }
    }

    var textureName: String {
        switch self {
        case .minnow: return "fish_minnow"
        case .angelfish: return "fish_angelfish"
        case .barracuda: return "fish_barracuda"
        case .shark: return "fish_shark"
        case .leviathan: return "fish_leviathan"
        case .puffer: return "fish_puffer"
        case .jellyfish: return "hazard_jelly"
        }
    }

    var isApexPredator: Bool {
        self == .shark || self == .leviathan
    }
}

enum PrankType: String, Codable, CaseIterable {
    case ink
    case invert
    case shark
    case bubble

    var emoji: String {
        switch self {
        case .ink: return "🐙"
        case .invert: return "🔄"
        case .shark: return "🦈"
        case .bubble: return "🫧"
        }
    }
}

enum GamePhase: Equatable {
    case menu
    case playing
    case roundOver
}

enum GameEventType: String, Codable {
    case bite
    case bigBite
    case sharkWarning
    case dash
    case levelUp
    case prankInk
    case prankInvert
    case prankShark
    case prankBubble
    case bubblePop
    case pufferPuff
    case jellyZap
    case playerBump
    case hurt
}

struct GameEventPacket: Codable {
    let type: GameEventType
    /// 0 = P1 (Host), 1 = P2 (Guest / Bot), 2 = Both
    let targetPlayer: Int
}

struct PlayerInputPacket: Codable {
    var dx: Float
    var dy: Float
    var dashPressed: Bool
}

struct PlayerSyncState: Codable {
    var x: Float
    var y: Float
    var facingRight: Bool
    var score: Int
    var level: Int
    var lives: Int
    var dashCooldown: Float
    var invuln: Float
    var inkTimer: Float
    var invertTimer: Float
    var bubbleTimer: Float
    var isDashing: Bool
    var pranksUsed: Int
    var bites: Int
}

struct FishSyncState: Codable {
    var id: Int
    var x: Float
    var y: Float
    var vx: Float
    var vy: Float
    var radius: Float
    var species: FishSpecies
    var isPuffed: Bool
    var isWarningPuff: Bool
    var isChasing: Bool
}

struct OrbSyncState: Codable {
    var id: Int
    var x: Float
    var y: Float
    var prank: PrankType
}

struct WarningSyncState: Codable {
    var y: Float
    var fromLeft: Bool
    var isLeviathan: Bool
    var progress: Float
}

struct WorldSnapshot: Codable {
    var p1: PlayerSyncState
    var p2: PlayerSyncState
    var fish: [FishSyncState]
    var orbs: [OrbSyncState]
    var warnings: [WarningSyncState]
    var timeValue: Float
    var ruleMode: GameRuleMode
    var map: MapTheme
}

struct RoundResult: Codable, Equatable {
    let scoreP1: Int
    let scoreP2: Int
    let levelP1: Int
    let levelP2: Int
    let titleP1: String
    let titleP2: String
    /// 0 = P1 wins, 1 = P2 wins, -1 = Draw
    let winnerIndex: Int
    let seriesP1: Int
    let seriesP2: Int
    let ruleMode: GameRuleMode
    let durationSeconds: Int
}

enum NetworkMessage: Codable {
    case discoveryToken(Data)
    case touchConnectTrigger
    case syncPing(Double)
    case syncPong(Double)
    case startMatch(map: MapTheme, ruleMode: GameRuleMode, stereoDuet: Bool, seriesP1: Int, seriesP2: Int, musicDelay: Double)
    case input(PlayerInputPacket)
    case snapshot(WorldSnapshot)
    case event(GameEventPacket)
    case roundOver(RoundResult)
    case returnToMenu
}

struct HudState {
    var scoreP1: Int = 0
    var scoreP2: Int = 0
    var levelP1: Int = 1
    var levelP2: Int = 1
    var livesP1: Int = 3
    var livesP2: Int = 3
    var dashCooldownLocal: Float = 0
    var timeValue: Float = 90
    var ruleMode: GameRuleMode = .timed
    var inkTimerLocal: Float = 0
    var invertTimerLocal: Float = 0
    var bubbleTimerLocal: Float = 0
    var dangerProximityLocal: Float = 0
    var bannerText: String? = nil
    var bannerEmoji: String? = nil
}

struct TitleGenerator {
    static func pickTitle(score: Int, level: Int, lives: Int, pranks: Int, won: Bool) -> String {
        if pranks >= 3 { return "Король пакостей" }
        if lives == 0 { return "Ужин океана" }
        if won && level >= 5 { return "Хозяин глубины" }
        if won && score >= 50 { return "Пылесос океана" }
        if won { return "Гроза рифа" }
        if pranks >= 2 { return "Морской хитрец" }
        if level >= 4 { return "Смелый охотник" }
        return "Созерцатель волн"
    }
}
