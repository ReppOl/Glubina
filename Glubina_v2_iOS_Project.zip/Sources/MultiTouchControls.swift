import SwiftUI
import UIKit

struct DPadVisualState: Equatable {
    var up: Bool = false
    var down: Bool = false
    var left: Bool = false
    var right: Bool = false
    var dashPressed: Bool = false
}

struct MultiTouchControlsOverlay: UIViewRepresentable {
    var onInputChanged: (_ dx: Float, _ dy: Float, _ dashTriggered: Bool, _ visual: DPadVisualState) -> Void

    func makeUIView(context: Context) -> MultiTouchPadView {
        let view = MultiTouchPadView()
        view.onInputChanged = onInputChanged
        return view
    }

    func updateUIView(_ uiView: MultiTouchPadView, context: Context) {
        uiView.onInputChanged = onInputChanged
    }
}

final class MultiTouchPadView: UIView {
    var onInputChanged: ((_ dx: Float, _ dy: Float, _ dashTriggered: Bool, _ visual: DPadVisualState) -> Void)?

    private var dpadTouch: UITouch?
    private var dashTouch: UITouch?
    private var lastVisual = DPadVisualState()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isMultipleTouchEnabled = true
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func dashCenter() -> CGPoint {
        let insetL = max(safeAreaInsets.left, 20)
        let insetB = max(safeAreaInsets.bottom, 16)
        return CGPoint(x: insetL + 54, y: bounds.height - insetB - 54)
    }

    private func dpadCenter() -> CGPoint {
        let insetR = max(safeAreaInsets.right, 20)
        let insetB = max(safeAreaInsets.bottom, 16)
        return CGPoint(x: bounds.width - insetR - 86, y: bounds.height - insetB - 86)
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        let dCenter = dashCenter()
        let pCenter = dpadCenter()
        let inDash = hypot(point.x - dCenter.x, point.y - dCenter.y) <= 68
        let inDpad = hypot(point.x - pCenter.x, point.y - pCenter.y) <= 108
        return inDash || inDpad
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let dCenter = dashCenter()
        let pCenter = dpadCenter()
        var dashFire = false

        for t in touches {
            let pt = t.location(in: self)
            if dashTouch == nil && hypot(pt.x - dCenter.x, pt.y - dCenter.y) <= 68 {
                dashTouch = t
                dashFire = true
                HapticManager.shared.playUIClick()
            } else if dpadTouch == nil && hypot(pt.x - pCenter.x, pt.y - pCenter.y) <= 108 {
                dpadTouch = t
                HapticManager.shared.playUIClick()
            }
        }
        emitState(dashTriggered: dashFire)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let dt = dpadTouch, touches.contains(dt) else { return }
        emitState(dashTriggered: false)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if t == dpadTouch { dpadTouch = nil }
            if t == dashTouch { dashTouch = nil }
        }
        emitState(dashTriggered: false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchesEnded(touches, with: event)
    }

    private func emitState(dashTriggered: Bool) {
        var dx: Float = 0
        var dy: Float = 0
        var vis = DPadVisualState(dashPressed: dashTouch != nil)

        if let t = dpadTouch {
            let pt = t.location(in: self)
            let c = dpadCenter()
            let ox = pt.x - c.x
            let oy = -(pt.y - c.y)
            let dist = hypot(ox, oy)

            if dist > 14 {
                let angle = atan2(oy, ox)
                let cosA = cos(angle)
                let sinA = sin(angle)

                if cosA > 0.36 { dx = 1; vis.right = true }
                else if cosA < -0.36 { dx = -1; vis.left = true }

                if sinA > 0.36 { dy = 1; vis.up = true }
                else if sinA < -0.36 { dy = -1; vis.down = true }
            }
        }

        if vis.up != lastVisual.up || vis.down != lastVisual.down ||
            vis.left != lastVisual.left || vis.right != lastVisual.right {
            if vis.up || vis.down || vis.left || vis.right {
                HapticManager.shared.playUIClick()
            }
        }
        lastVisual = vis
        onInputChanged?(dx, dy, dashTriggered, vis)
    }
}
